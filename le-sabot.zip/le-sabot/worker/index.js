// Worker du Sabot : sert le jeu (dossier public/), relaie les messages du JcJ
// et tient le classement du défi du jour.
// Chaque salon est un Durable Object : il accueille jusqu'à MAX_PLAYERS WebSockets,
// tient la liste des joueurs et retransmet à tous ce que l'un envoie, en y ajoutant
// l'identifiant de l'expéditeur (impossible de parler au nom d'un autre).
// Le premier joueur de la liste est l'hôte : lui seul lance la partie ou rouvre le salon.
import { DurableObject } from "cloudflare:workers";

const MAX_PLAYERS = 8;

export default {
  async fetch(request, env){
    const url = new URL(request.url);
    if(url.pathname === "/relay/ping") return new Response("ok", {headers: {"cache-control": "no-store"}});
    const m = url.pathname.match(/^\/relay\/([A-Z]{5})$/);
    if(m){
      if(request.headers.get("Upgrade") !== "websocket") return new Response("WebSocket attendu", {status: 426});
      return env.ROOMS.get(env.ROOMS.idFromName(m[1])).fetch(request);
    }
    // Classement du défi du jour : un Durable Object par date
    const d = url.pathname.match(/^\/api\/daily\/(\d{4}-\d{2}-\d{2})$/);
    if(d) return env.BOARD.get(env.BOARD.idFromName(d[1])).fetch(request);
    return env.ASSETS.fetch(request);
  },
};

// Tableau des scores d'une journée : les 50 meilleurs, un seul score par pseudo (le meilleur).
export class Leaderboard extends DurableObject {
  async fetch(request){
    let top = (await this.ctx.storage.get("top")) || [];
    if(request.method === "POST"){
      let b; try{ b = await request.json(); }catch(e){ return new Response("JSON attendu", {status: 400}); }
      const name = String(b && b.name || "").trim().slice(0, 20);
      const tables = Math.floor(Number(b && b.tables)), dmg = Math.floor(Number(b && b.dmg));
      if(!name || !(tables >= 0 && tables <= 9) || !(dmg >= 0 && dmg < 1e13)) return new Response("Score invalide", {status: 400});
      const entry = {name, tables, dmg, deck: String(b.deck || "").slice(0, 20), at: Date.now()};
      const better = (a, c) => a.tables > c.tables || (a.tables === c.tables && a.dmg > c.dmg);
      const i = top.findIndex(e => e.name === name);
      if(i === -1) top.push(entry); else if(better(entry, top[i])) top[i] = entry;
      top.sort((a, c) => c.tables - a.tables || c.dmg - a.dmg);
      top = top.slice(0, 50);
      await this.ctx.storage.put("top", top);
    }
    return Response.json({top: top.slice(0, 20)}, {headers: {"cache-control": "no-store"}});
  }
}

export class Room extends DurableObject {
  players(except = null){
    return this.ctx.getWebSockets()
      .filter(ws => ws !== except && ws.deserializeAttachment())
      .map(ws => ({ws, ...ws.deserializeAttachment()}))
      .sort((a, b) => a.seq - b.seq);
  }
  roster(except = null){ return this.players(except).map(({id, name}) => ({id, name})); }
  broadcast(obj, except = null){
    const text = JSON.stringify(obj);
    for(const p of this.players(except)) try{ p.ws.send(text); }catch(e){}
  }
  // Refus : on ouvre la socket le temps d'envoyer un code de fermeture lisible par le jeu.
  reject(code, reason){
    const [client, server] = Object.values(new WebSocketPair());
    server.accept(); server.close(code, reason);
    return new Response(null, {status: 101, webSocket: client});
  }
  async fetch(request){
    const params = new URL(request.url).searchParams;
    const role = params.get("role") === "host" ? "host" : "guest";
    const name = (params.get("name") || "Joueur").slice(0, 20);
    const present = this.players();
    const started = await this.ctx.storage.get("started");
    // Codes lus par le jeu : 4001 code pris, 4003 salon plein, 4004 introuvable, 4005 partie en cours
    if(role === "host" && present.length) return this.reject(4001, "Code déjà pris");
    if(role === "guest" && !present.length) return this.reject(4004, "Aucun salon avec ce code");
    if(role === "guest" && started) return this.reject(4005, "Partie déjà en cours");
    if(present.length >= MAX_PLAYERS) return this.reject(4003, "Salon complet");
    if(role === "host") await this.ctx.storage.put("started", false);

    const seq = ((await this.ctx.storage.get("seq")) || 0) + 1;
    await this.ctx.storage.put("seq", seq);
    const id = crypto.randomUUID().slice(0, 8);
    const [client, server] = Object.values(new WebSocketPair());
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({id, name, seq});
    server.send(JSON.stringify({type: "_welcome", id}));
    this.broadcast({type: "_roster", players: this.roster()});
    return new Response(null, {status: 101, webSocket: client});
  }
  async webSocketMessage(ws, message){
    if(typeof message !== "string" || message.length > 65536) return;
    const me = ws.deserializeAttachment(); if(!me) return;
    let msg; try{ msg = JSON.parse(message); }catch(e){ return; }
    if(!msg || typeof msg.type !== "string") return;
    const isHost = this.players()[0]?.id === me.id;
    if(msg.type === "_start"){
      if(!isHost || this.players().length < 2) return;
      await this.ctx.storage.put("started", true);
      this.broadcast({type: "_start", players: this.roster()});
      return;
    }
    if(msg.type === "_lobby"){
      if(!isHost) return;
      await this.ctx.storage.put("started", false);
      this.broadcast({type: "_lobby", players: this.roster()});
      return;
    }
    if(msg.type.startsWith("_")) return; // messages de contrôle réservés
    msg.from = me.id;
    this.broadcast(msg, ws);
  }
  async webSocketClose(ws){ await this.leave(ws); }
  async webSocketError(ws){ await this.leave(ws); }
  async leave(ws){
    const me = ws.deserializeAttachment();
    try{ ws.close(1000, "fin"); }catch(e){}
    const rest = this.roster(ws);
    if(!rest.length){ await this.ctx.storage.deleteAll(); return; }
    this.broadcast({type: "_roster", players: rest, left: me && me.id}, ws);
  }
}
