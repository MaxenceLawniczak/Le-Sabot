# Le Sabot

Un blackjack roguelike dans l'esprit de Balatro et de Dungeons & Degenerate Gamblers. Chaque main gagnée inflige **jetons × mult** à ton adversaire. Entre deux tables, tu améliores ton deck et tu achètes des charmes.

Le jeu tourne entièrement dans le navigateur : pas de build, pas de dépendance à installer, pas d'API. Toutes les cartes sont dessinées en SVG par le jeu lui-même.

## L'écran de menu

Au lancement, un écran de menu propose : **Continuer la partie** (si une partie solo est en cours), **Jouer en solo** (qui ouvre le choix du deck), **Défi du jour**, **JcJ en ligne**, **Codex**, **Succès**, **Règles** et **Options**.

**Sauvegarde.** La partie solo est enregistrée dans le navigateur au début de chaque table, après chaque main et en boutique. Recharger la page ou fermer l'appli ne fait plus rien perdre : « Continuer la partie » la reprend, avec le deck, l'ante et les PV rappelés sur le bouton.

**Défi du jour.** Tout le monde joue la même partie ce jour-là : même deck (tiré d'après la date), mêmes cartes, mêmes patrons. Le classement, tenu par le Worker, compte les tables gagnées puis les dégâts infligés. Chaque joueur n'y apparaît qu'une fois, avec son meilleur score.

**Succès et statistiques.** 18 succès à débloquer (premier blackjack, 10 000 dégâts en une main, battre les 21 patrons, gagner avec 5 decks…) et des statistiques : parties, victoires, plus gros coup, patrons battus, charmes obtenus. Un bandeau s'affiche quand un succès se débloque.

**Son.** Des bruitages synthétisés par le navigateur, sans aucun fichier : cartes distribuées, jetons et mult qui montent, coups portés, dégâts subis, pièces, succès. Le volume se règle dans les Options. En bas, le deck choisi est rappelé avec son dos de carte ; on peut en changer d'un clic. Le deck et les options sont mémorisés dans le navigateur.

**Les decks.** Il y en a 17. Chacun a son propre dos de carte, que tes adversaires voient aussi en JcJ, et un bonus pour toute la partie, sauf le classique :

| Deck | Bonus |
| --- | --- |
| Classique | Aucun |
| Rouge | +1 brûlage à chaque table |
| D'or | +10 or au départ, +2 or par table gagnée |
| Azur | +10 jetons sur chaque main gagnée |
| Braise | +2 mult sur chaque main gagnée, mais 10 PV de moins |
| Émeraude | +1 place dans la manche, rayon de boutique moins cher |
| Du néant | Les 13 Nothing en plus, et le charme Zen au départ |
| Abyssal | +1 emplacement de charme, mais pas de charme de départ |
| Prisme | 8 cartes commencent foil, holo ou poly |
| Chiffré | Tes As à 10 sont tous des enseignes de valeur (cœur de 4…), qui donnent du mult |
| Double | Les 52 cartes classiques et les 40 enseignes de valeur, soit 92 cartes |
| Marchand | Tous les charmes coûtent 2 or de moins |
| Banquier | Intérêts jusqu'à 20 or au lieu de 10, mais 2 or de moins par table |
| Verrerie | 10 cartes commencent en verre |
| Inversé | Tous les 2, 3, 4 et 5 sont négatifs |
| Spectral | 3 cartes spéciales et un clou du cercueil au départ |
| Colosse | 20 PV de plus, mais un emplacement de charme de moins |

**Les options.** *Cartes à contraste élevé* donne une couleur franche à chaque enseigne (♠ marine, ♥ rouge, ♦ orange, ♣ bleu). *Animations réduites* coupe flammes, tremblements et flottements.

**Sur PC**, les charmes s'affichent dans une colonne à droite de la table. **Sur mobile**, l'en-tête est compacté, les actions sont regroupées en bas de l'écran, les charmes défilent horizontalement, et un **menu burger** (☰) donne accès à ce qui a du sens selon la situation : tes charmes en détail, ton deck, le Codex, les règles, les options, et le retour au menu. En JcJ, il affiche aussi la liste des joueurs.

## Lancer le jeu

### En ligne sur Cloudflare (recommandé, indispensable pour le JcJ)

Le projet est un Worker Cloudflare : il sert le jeu et fait office de relais entre les joueurs en JcJ. Depuis le dossier du projet :

```bash
npm install
npx wrangler deploy
```

Wrangler affiche l'adresse du jeu, du type `https://le-sabot.<ton-sous-domaine>.workers.dev`. Envoie ce lien à tes amis pour jouer ensemble.

### En local avec le relais

```bash
npm install
npx wrangler dev
```

Puis ouvre http://localhost:8787. C'est exactement la version en ligne, relais compris.

### Sans rien installer

Double-clique sur `public/index.html`. Le solo fonctionne, même hors ligne. Le JcJ, lui, a besoin du Worker.

## Installer le jeu sur un téléphone

Ouvre la version en ligne, puis :

- **iPhone (Safari)** : bouton Partager, puis « Sur l'écran d'accueil ».
- **Android (Chrome)** : menu ⋮, puis « Ajouter à l'écran d'accueil » ou « Installer l'application ».

Le jeu apparaît alors avec son icône (deux cartes en éventail, un As de pique doré devant) et s'ouvre en plein écran, sans barre d'adresse. Les icônes sont dans `public/icons/`, et `public/manifest.webmanifest` décrit l'application (nom, couleurs, icônes). Pour changer l'icône, modifie `icon.svg` et régénère les PNG aux mêmes tailles (180, 192 et 512 pixels, plus la version « maskable » dont le motif reste dans la zone centrale).

## Ce dont le jeu a besoin

| Service | Utilisation | Si indisponible |
| --- | --- | --- |
| Google Fonts | Polices Alfa Slab One et Barlow Semi Condensed | Polices système de remplacement |
| Le Worker (relais `/relay/…`) | Salons et échanges du JcJ | JcJ indisponible, le solo fonctionne |

## Jouer en ligne (JcJ, de 2 à 8 joueurs)

1. Un joueur choisit « JcJ en ligne », entre un pseudo puis clique sur « Créer un salon ».
2. Il partage le code à 5 lettres. Les autres entrent ce code et cliquent sur « Rejoindre ».
3. Quand tout le monde est dans le salon, l'hôte clique sur « Lancer la partie ».

À chaque manche, tout le monde joue en même temps. Chaque main est comparée à la meilleure main de **chaque** adversaire : si elle la bat, elle lui inflige ses jetons × mult. Un joueur qui a sauté est battu par toutes les mains encore en vie. Boutique toutes les 3 manches ; un joueur à 0 PV est éliminé, et le dernier debout gagne. En fin de partie, l'hôte peut ramener tout le monde au salon : de nouveaux joueurs peuvent alors le rejoindre avant la partie suivante. Si l'hôte s'en va, le joueur arrivé juste après lui devient hôte.

Les messages passent par un **relais WebSocket** : chaque salon est un Durable Object qui tient la liste des joueurs et retransmet à tous ce que l'un envoie, sans rien stocker. Comme c'est du HTTPS classique, ça passe à travers les proxys et les pare-feux. Le JcJ nécessite donc le Worker : en ligne, ou en local avec `npx wrangler dev`.

## Le Codex

Le bouton **Codex**, dans le menu principal comme en cours de partie, ouvre une vitrine de tout le contenu du jeu : les 13 rangs et les 4 couleurs, les cartes négatives, les améliorations et éditions (survole les cartes pour voir les reflets), les cartes spéciales et les Clous du cercueil, tous les charmes avec leur rareté, leur prix et leur effet (filtrables par rareté), et tous les patrons avec leur règle. On peut y attraper les cartes et les charmes pour les réorganiser comme on veut. Il se ferme avec le bouton « Fermer » ou la touche Échap.

Le Codex lit directement `public/js/content.js` : un charme, une carte spéciale ou un patron que tu ajoutes y apparaît tout seul.

## Les cartes

| Type | Apparence | Effet |
| --- | --- | --- |
| Classiques | Fond crème, valeurs rouges ou noires | Valeur habituelle du blackjack |
| Nothing | Fond crème, enseignes en simples points noirs, de l'As au Roi | Valeur habituelle ; sans couleur, donc ignorés par les charmes de couleur et jamais désactivés |
| Enseignes de valeur | Un seul grand symbole formé du chiffre répété, cadre et étiquette « MULT » : le **cœur de 4** est un grand cœur fait de 4, à ne pas confondre avec le **4 de cœur**, qui porte quatre cœurs | Leur valeur compte dans le total, mais part dans le **mult** au lieu des jetons : le cœur de 4 donne +4 mult (de l'As au 10 seulement) |
| Négatives | Fond de couleur (♥ rouge, ♦ orange, ♠ noir, ♣ vert, Nothing gris), valeurs en blanc | Retirent leur valeur au total : un −2 de cœur retire 2, un As négatif retire 1 |
| Spéciales | Illustrées, fond sombre | Caméléon, Fantôme, Miroir, Pétard, Pie, Sangsue, Dé (1 à 6, tiré quand il sort), Bourse (+1 or par carte gagnante), Phénix (+7 mult, renaît dans la manche quand on le brûle), Aimant (+10 jetons par carte), Horloge (vaut 12, ×2 mult), Clous du cercueil I à V |

Le jeu a donc les deux : les **valeurs d'enseigne** (le 4 de cœur, qui donne ses points en jetons) et les **enseignes de valeur** (le cœur de 4, qui les donne en mult). Les secondes s'obtiennent surtout avec le **paquet chiffré** (5 or, 3 au choix) et les decks chiffré et double.

Elles s'obtiennent à la boutique : le paquet standard et le paquet éclat contiennent aussi des négatives (environ une carte sur quatre et une sur cinq), le paquet occulte contient les spéciales et les Nothing, qu'on croise aussi parfois dans le paquet standard.

Les améliorations se voient sur la carte elle-même : **acier gravé** (plaque argentée striée, rivets), **dorée** (carte en or avec un reflet qui passe), **rubis** (rubis sertis tout autour du cadre) et **verre** (carte translucide qui laisse voir le tapis, avec une fêlure). Les éditions ont un reflet animé en permanence : bandes argentées pour le foil, arc-en-ciel pour le holographique, couleurs tournantes pour le polychrome.

Pendant le calcul d'une main gagnante, chaque carte tressaute à son tour en faisant jaillir ses points, puis ses améliorations et les charmes s'enchaînent. Les jetons et le mult s'embrasent quand ils montent (shader de feu en WebGL, avec des flammes CSS en secours si WebGL n'est pas disponible), les dégâts défilent, et l'écran tremble sur les gros coups.

## Les patrons

La troisième table de chaque ante est tenue par un patron qui change une règle, et le décor de la table avec lui : velours à cœurs pour Le Cardinal, facettes turquoise pour Le Joaillier, plumes noires pour Le Corbeau, trèfles pour Le Jardinier, fer riveté pour Le Baron, toile d'araignée pour La Veuve, brouillard qui dérive pour Monsieur Brume, fleurons dorés pour L'Archiduc et cuir cousu pour La Fouineuse. Il y en a 21. Quatre d'entre eux **désactivent une couleur** : Le Cardinal (♥), Le Joaillier (♦), Le Corbeau (♠) et Le Jardinier (♣). Une carte désactivée, barrée de rouge, compte toujours dans le total, mais ne rapporte ni jetons, ni amélioration, ni édition, et les charmes l'ignorent. Les cartes spéciales et le Nothing n'ont pas de couleur : ils ne sont jamais désactivés. D'autres désactivent les figures (La Comtesse), les cartes impaires (Madame Impaire), tout ce qui sort du jeu classique (L'Exorciste), les éditions (Le Glacier) ou les améliorations (Le Démolisseur). Le Rusé tire tant qu'il est sous ta meilleure main, Le Comte Carmin se soigne quand tu perds, Le Mime fait taire ton premier charme, La Faucheuse abaisse ta limite de saut à 20, Le Percepteur prend 2 or par main perdue, Le Radin ne paie rien, L'Empoisonneuse coûte 2 PV par main. Les autres : Le Baron (le croupier tire jusqu'à 18), La Veuve (dégâts subis doublés), Monsieur Brume (première carte cachée), L'Archiduc (ni brûler ni séparer) et La Fouineuse (manche interdite).

## Les charmes et leur rareté

Chaque charme a une rareté, affichée par un bandeau de couleur en haut de sa tuile. Elle règle sa fréquence d'apparition en boutique.

| Rareté | Couleur | Chance par emplacement | Exemples |
| --- | --- | --- | --- |
| Commun | Bleu | 60 % | Petites mains, Vampire, Tirelire, Paire, Damier |
| Peu commun | Vert | 28 % | Frime, Rapace, Boulier, Escalier, Pyromane |
| Rare | Rouge | 10 % | Pile poil, Jackpot, Numérologue, Prismatique |
| Légendaire | Violet | 2 % | Élastique, Ouroboros, Roi Midas, Mécène, Photocopieuse |

Il y a 72 charmes au total, tous illustrés, et le Codex les présente tous avec leur effet.

**Éditions de charme.** En boutique, un charme peut sortir foil (+25 jetons), holo (+6 mult), poly (×1,5 mult) ou négatif (il n'occupe aucun emplacement), pour quelques pièces de plus. Le bonus s'applique au passage du charme, même s'il ne se déclenche pas. Les éditions ont le même reflet que sur les cartes, et le négatif inverse les couleurs de la tuile.

Chaque charme a sa propre illustration, dessinée en SVG (`public/js/charmart.js`).

*Contrepoids* : une fois par table (par série de 3 manches en JcJ), quand tu sautes, il crée la carte négative qui te ramène pile à 21 et la joue aussitôt. Elle est de la couleur de la dernière carte classique de ta main, et elle rejoint ton deck.

## Les tickets

Des objets à usage unique, vendus 2 à 5 or en boutique (deux au choix à chaque visite). On en garde 2 au plus, affichés sous les charmes, et on les utilise entre deux mains ou en boutique.

| Ticket | Effet |
| --- | --- |
| Burin, Écrin, Feuille d'or, Soufflet | Grave, sertit de rubis, dore ou change en verre une carte au choix |
| Vernis | Donne une édition au hasard (foil, holo, poly) à une carte au choix |
| Duplicata | Copie une carte au choix, améliorations comprises |
| Scalpel | Retire une carte au choix du deck |
| Chiffrage | Change un As à 10 classique en enseigne de valeur |
| Inversion | Rend une carte négative, ou la rétablit |
| Remède | +20 PV |
| Placement | Double ton or (+20 au plus) |
| Recrue | Un charme commun au hasard |
| Pot-de-vin | Pendant une table, l'adversaire perd 25 % de ses PV maximum |

## L'or

| Source | Montant |
| --- | --- |
| Main gagnée | +1 or |
| Gain de table | 4, 5 ou 8 or selon la table (+2 avec le deck d'or) |
| Rapidité | +1 or par main jouée en dessous de 7 |
| Intérêts | 1 or par tranche de 5 or en poche en quittant la table, jusqu'à 10 (15 avec la Tirelire) |

Garder de l'or en poche rapporte donc : 50 or donnent 10 or d'intérêts à chaque table. Le récapitulatif de fin de table détaille chaque ligne. Les réglages sont en tête de `content.js` (`TABLE_GOLD`, `SPEED_PAR`, `INTEREST_CAP`).

## Commandes

| Touche | Action |
| --- | --- |
| Espace ou Entrée | Distribuer, main suivante |
| T | Tirer une carte |
| R | Rester |
| D | Doubler |
| S | Séparer une paire |
| B | Brûler la dernière carte |
| C | Cacher la carte sélectionnée dans ta manche |
| M | Ressortir la première carte de ta manche |
| Échap | Fermer la vue du deck ou le Codex |

## Structure du projet

```
wrangler.toml            Configuration du Worker : fichiers du jeu + Durable Object des salles
package.json             Scripts « dev » et « deploy » (Wrangler)
worker/index.js          Worker : sert public/, gère les salons JcJ (classe Room) et le classement du défi du jour (classe Leaderboard)
public/index.html        Page du jeu, charge le CSS et les scripts
public/manifest.webmanifest  Description de l'application installable (nom, couleurs, icônes)
public/icons/            Icône du site et de l'application, en SVG et en PNG
public/css/styles.css    Tous les styles (plateau, cartes 3D, éditions, boutique)
public/js/deck.js        Sabot : mélange et tirage des exemplaires de ton deck
public/js/content.js     Contenu : cartes spéciales, améliorations, éditions, charmes, adversaires
public/js/cards.js       Dessin SVG de toutes les cartes (classiques, négatives, Nothing, spéciales)
public/js/state.js       État de la partie et calcul de la valeur des mains
public/js/fire.js        Flammes WebGL des cases Jetons, Mult et Dégâts (portage d'un shader Godot)
public/js/charmart.js    Illustrations SVG des charmes
public/js/render.js      Affichage des cartes, du HUD, des mains, de la manche
public/js/play.js        Déroulé d'une main, déclencheurs de charmes, calcul du score
public/js/shop.js        Mode solo : tables, boutique, paquets, fin de partie
public/js/codex.js       Codex : vitrine des cartes, charmes et patrons avec leurs effets
public/js/sfx.js         Bruitages synthétisés (Web Audio)
public/js/save.js        Sauvegarde de la partie, statistiques et succès
public/js/tickets.js     Tickets à usage unique
public/js/daily.js       Défi du jour : hasard à graine fixe et classement
public/js/jcj.js         JcJ en ligne : salon, synchronisation des joueurs, résolution des manches
public/js/main.js        Écran de menu, choix du deck, options, règles, menu burger, raccourcis
```

Les scripts du jeu sont des scripts classiques qui partagent la même portée globale, et non des modules ES. C'est ce qui permet d'ouvrir `public/index.html` directement depuis le disque. En contrepartie, **l'ordre des balises `<script>` dans `index.html` compte** : `main.js` doit rester en dernier, car c'est lui qui lance le jeu.

## Régler les flammes

Les flammes sont un portage WebGL d'un shader Godot (`canvas_item`). Leurs réglages sont en haut de `public/js/fire.js`, avec le nom de l'uniform Godot correspondant :

- `PALETTES` : les trois couleurs de chaque case (`bottom_color`, `middle_color`, `top_color`). Le mult reprend exactement les couleurs du shader d'origine.
- `speed` (`fire_speed`), `apertureCold` / `apertureHot` (`fire_aperture` selon la chaleur), `alphaCold` / `alphaHot` (`fire_alpha`), `heightMin` / `heightMax` (hauteur en pixels).
- `contrast`, `tipSoftness` et `taper` sont trois retouches absentes de l'original : mets `contrast: 1`, `tipSoftness: 1` et `taper: false` pour retrouver son rendu exact.

La texture `noise_tex` du shader Godot est remplacée par un bruit procédural calculé dans le shader : aucune image à fournir.

## Ajouter du contenu

- **Un charme** : ajoute une entrée dans `CHARMS` (`public/js/content.js`), puis son identifiant dans une des listes de `RARITY_OF` (sinon il est commun). `score` agit pendant le calcul d'une main gagnante. `onBust`, `onDouble`, `onSplit`, `onLose`, `onPush` et `onHide` agissent au moment de l'action.
- **Une carte spéciale** : ajoute une entrée dans `SPECIALS` (`public/js/content.js`). `val` vaut un nombre, `"wild"` ou `"mirror"`. `score` s'applique dans une main gagnante et `draw` quand la carte sort. Pour son dessin, ajoute son illustration dans `SP_ART` et ses couleurs de fond dans `SP_BG` (`public/js/cards.js`), sur une grille de 100 × 100.
- **Un patron** : ajoute une entrée dans `BOSSES`, puis gère son `mod` là où la règle s'applique (voir `fer`, `gorge`, `brume`, `bavure` et `fouille`). Son décor se règle dans `styles.css` avec `body[data-theme="…"]`.
- **Un deck** : ajoute une entrée dans `DECKS` (`public/js/content.js`) et son dos dans `BACKS` (`public/js/cards.js`). Les bonus disponibles : `burns`, `gold`, `tableGold`, `chips`, `mult`, `hp`, `sleeve`, `reroll`, `slots`, `noStarter`, `nothings`, `charm`, `editions`.
- **L'illustration d'un charme** : ajoute-la dans `CHARM_ART` (`public/js/charmart.js`), sur une grille de 100 × 64. Sans illustration, l'emoji du charme s'affiche.
