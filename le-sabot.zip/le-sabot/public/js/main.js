"use strict";
// Écran de menu, choix du deck, options, règles, menu burger (mobile), raccourcis clavier.

/* ======================================================================
   Fenêtres
   ====================================================================== */
let modalKind = null;
function openModal(html, kind = null){
  modalKind = kind;
  $("sheet").classList.toggle("wide", kind === "codex" || kind === "decks");
  $("sheet").innerHTML = html; $("modal").hidden = false;
  closeBurger();
  const f = $("sheet").querySelector("input, button:not(:disabled)"); if(f) f.focus();
}
function closeModal(){ $("modal").hidden = true; modalKind = null; }

/* ======================================================================
   Écran de menu (plein écran) et écran de jeu
   ====================================================================== */
function showGame(){ $("menuScreen").hidden = true; $("game").hidden = false; document.body.classList.remove("in-menu"); renderBurger(); }
function showMenu(){ $("menuScreen").hidden = false; $("game").hidden = true; document.body.classList.add("in-menu"); setTheme(""); closeBurger(); }

// Éventail de 3 cartes tirées au hasard à chaque retour au menu : classiques, Nothing,
// négatives, améliorées, brillantes ou spéciales, pour montrer la variété du jeu.
function randomShowcaseCard(){
  const roll = Math.random();
  if(roll < .2) return {code:"X1", sp: pickOne(Object.keys(SPECIALS))};
  if(roll < .35) return {code: pickOne(NUM_RANKS) + pickOne(SUITS), num:true, ed: Math.random() < .3 ? pickOne(Object.keys(EDS)) : null};
  const c = {code: pickOne(Math.random() < .15 ? NOTHINGS : FULL)};
  if(Math.random() < .35) c.enh = pickOne(Object.keys(ENH));
  if(Math.random() < .4) c.ed = pickOne(Object.keys(EDS));
  if(Math.random() < .15) c.neg = true;
  return c;
}
function renderMenuFan(){
  const fan = $("menuFan"); fan.innerHTML = "";
  const cards = [];
  while(cards.length < 3){
    const c = randomShowcaseCard();
    if(!cards.some(x => x.code === c.code && x.sp === c.sp)) cards.push(c);
  }
  cards.forEach((c, i) => {
    const el = cardEl(c);
    const k = i - 1;
    el.style.setProperty("--i", k); el.style.setProperty("--dy", (Math.abs(k) * 12) + "px");
    fan.appendChild(el);
  });
  const d = DECKS[SETTINGS.deck];
  $("menuDeck").innerHTML = `<span class="mdback"></span><span><small>Deck choisi</small><b>${d.name}</b><em>${d.desc}</em></span><span class="mdchange">Changer</span>`;
  $("menuDeck").querySelector(".mdback").appendChild(cardEl({}, {hidden:true, back: SETTINGS.deck}));
}
function titleScreen(){
  stopDaily();
  netClose(); MODE = "solo"; O = null; newRun(); shoe = null;
  T = {foe:{name:"…", hp:1, maxHp:1, mod:null, text:""}, burns:0, wins:0, round:0, nails:new Set()};
  H = {hands:[], cur:0, d:[], phase:"over"};
  closeModal(); refreshAll(); setMsg(""); $("steps").textContent = ""; setBoxes(0, 0, 0);
  showMenu(); renderMenuFan();
  // Partie en cours sauvegardée : on propose de la reprendre
  const saved = loadRun();
  $("mContinue").hidden = !saved;
  if(saved){
    const s = saved.S;
    $("mContinue").innerHTML = `Continuer la partie<small>${saved.daily ? "Défi du jour · " : ""}${DECKS[s.deckId] ? DECKS[s.deckId].name : ""} · ante ${s.ante}, ${TABLE_NAME[s.table].toLowerCase()} · ${Math.max(0, s.hp)} PV</small>`;
  }
  (saved ? $("mContinue") : $("mPlay")).focus();
}
function startSolo(deckId = SETTINGS.deck, daily = false){
  if(!daily) stopDaily();
  clearRun(); stat("run");
  netClose(); MODE = "solo"; O = null; newRun(typeof deckId === "string" ? deckId : SETTINGS.deck); shoe = null;
  T = {foe:{name:"…", hp:1, maxHp:1, mod:null, text:""}, burns:0, wins:0, round:0, nails:new Set()};
  H = {hands:[], cur:0, d:[], phase:"over"};
  showGame(); refreshAll();
  if(deckDef().noStarter) startTable();
  else starterPick("Trois antes de trois tables, un patron au bout de chacune.", startTable);
}
function starterPick(intro, then){
  const picks = shuffled(STARTERS.filter(id => !has(id))).slice(0, 3);
  openModal(`<h2>Premier charme</h2><p>${intro}</p><div class="charms" id="starters"></div>`);
  const box = $("starters");
  picks.forEach(id => {
    const b = document.createElement("button"); b.className = "charm"; b.innerHTML = charmTile(id);
    b.onclick = () => { S.charms.push({id, n:0, ed:null}); stat("charm", {id}); renderCharms(); then(); };
    box.appendChild(b);
  });
  box.querySelector("button").focus();
}

/* ---------- choix du deck ---------- */
function deckSelect(then = null, back = titleScreen){
  let pick = SETTINGS.deck;
  const draw = () => {
    openModal(`<div class="chead"><h2>Choisis ton deck</h2><button class="btn" id="dkBack">Retour</button></div>
      <p>Chaque deck a son dos de cartes et un bonus pour toute la partie, sauf le classique qui n'en a aucun.</p>
      <div class="decks" id="deckGrid" role="radiogroup" aria-label="Decks"></div>
      <div class="bar"><button class="btn main" id="dkGo">${then ? "Jouer avec ce deck" : "Valider"}</button></div>`, "decks");
    const grid = $("deckGrid");
    for(const [id, d] of Object.entries(DECKS)){
      const b = document.createElement("button");
      b.className = "deckopt" + (id === pick ? " on" : ""); b.setAttribute("role", "radio"); b.setAttribute("aria-checked", id === pick);
      b.appendChild(cardEl({}, {hidden:true, back:id}));
      b.insertAdjacentHTML("beforeend", `<b>${d.name}</b><span>${d.desc}</span>`);
      b.onclick = () => { pick = id; draw(); $("deckGrid").querySelector(".on").focus(); };
      b.ondblclick = () => { pick = id; commit(); };
      grid.appendChild(b);
    }
    $("dkBack").onclick = back;
    $("dkGo").onclick = commit;
  };
  const commit = () => { SETTINGS.deck = pick; saveSettings(); if(then) then(); else back(); };
  draw();
}

/* ---------- options ---------- */
function openOptions(back = null){
  const row = (id, on, title, text) => `<label class="opt"><input type="checkbox" id="${id}" ${on ? "checked" : ""}><span><b>${title}</b><em>${text}</em></span></label>`;
  openModal(`<h2>Options</h2>
    ${row("optHC", SETTINGS.highContrast, "Cartes à contraste élevé", "Une couleur franche par enseigne : ♠ marine, ♥ rouge, ♦ orange, ♣ bleu.")}
    <div class="hcpreview" id="hcPreview"></div>
    ${row("optCalm", SETTINGS.calm, "Animations réduites", "Coupe les flammes animées, les tremblements et le flottement des cartes.")}
    <label class="opt vol"><span><b>Volume des bruitages</b><em>Cartes, jetons, coups, boutique. À zéro, le jeu est muet.</em></span>
      <input type="range" id="optVol" min="0" max="100" step="5" value="${Math.round((SETTINGS.volume ?? .6) * 100)}" aria-label="Volume"></label>
    <div class="bar"><button class="btn main" id="optOk">Fermer</button></div>`, "options");
  const preview = () => { const p = $("hcPreview"); p.innerHTML = ""; ["AS", "AH", "AD", "AC"].forEach(code => p.appendChild(cardEl({code}))); };
  preview();
  $("optHC").onchange = e => { SETTINGS.highContrast = e.target.checked; saveSettings(); preview(); if(!$("game").hidden) refreshAll(); };
  $("optCalm").onchange = e => { SETTINGS.calm = e.target.checked; saveSettings(); document.body.classList.toggle("calm", SETTINGS.calm); };
  $("optVol").oninput = e => { SETTINGS.volume = +e.target.value / 100; saveSettings(); };
  $("optVol").onchange = () => sfx("coin");
  $("optOk").onclick = () => { if(back) back(); else { closeModal(); if(!$("menuScreen").hidden) renderMenuFan(); } };
}

/* ---------- règles ---------- */
function openRules(back = null){
  openModal(`<h2>Règles</h2>
    <div class="rules">
      <p><b>Gagner une main</b> inflige <b>jetons × mult</b>. Les jetons partent du total de ta main, le mult de 1.</p>
      <p><b>Blackjack naturel</b> : ×2 mult. <b>21 pile</b> : +1 mult. <b>Doubler</b> : ×2, mais tu risques plus gros.</p>
      <p><b>Séparer</b> une paire donne deux mains jouées l'une après l'autre. <b>Brûler</b> défausse ta dernière carte.</p>
      <p><b>Ta manche</b> : cache une carte de ta main et ressors-la dans une main plus tard, une fois de chaque par main.</p>
      <p><b>Les charmes</b> se déclenchent dans l'ordre ; certains seulement quand tu sautes, doubles, sépares ou perds. Ils peuvent être foil, holo, poly ou négatifs.</p>
      <p><b>Tes cartes</b> peuvent être gravées, rubis, dorées ou en verre, et foil, holo ou poly. Les <b>négatives</b> retirent leur valeur, les <b>Nothing</b> n'ont pas de couleur, et les <b>enseignes de valeur</b> (le cœur de 4, un grand cœur fait de 4) donnent leur valeur en mult au lieu des jetons.</p>
      <p><b>L'or</b> : +1 par main gagnée, un gain à chaque table, une prime si tu gagnes vite (moins de 7 mains), et des intérêts (1 or par tranche de 5 or, jusqu'à 10).</p>
      <p><b>Les cartes spéciales</b> : Caméléon, Miroir, Pétard… et les cinq <b>Clous du cercueil</b>, qui enterrent ton adversaire.</p>
      <p><b>Les patrons</b> changent une règle à la troisième table de chaque ante, et même le décor.</p>
    </div>
    <div class="bar"><button class="btn main" id="rulesOk">Fermer</button></div>`, "rules");
  $("rulesOk").onclick = () => back ? back() : closeModal();
}

/* ======================================================================
   Menu burger (mobile) : ses entrées dépendent de ce qu'on est en train de faire
   ====================================================================== */
function burgerItems(){
  if(!$("menuScreen").hidden) return [];
  const items = [];
  if(MODE === "duel" && NET.inMatch) items.push(["Joueurs", () => openPlayers()]);
  items.push([`Mes charmes (${S.charms.length})`, () => openMyCharms()]);
  items.push(["Voir mon deck", () => showDeck("view")]);
  items.push(["Codex", () => openCodex()]);
  items.push(["Succès", () => openStats()]);
  items.push(["Règles", () => openRules()]);
  items.push(["Options", () => openOptions()]);
  items.push([MODE === "duel" ? "Quitter la partie en ligne" : "Retour au menu", () => leaveToMenu(), "danger"]);
  return items;
}
function renderBurger(){
  const nav = $("burgerNav"); if(!nav) return;
  nav.innerHTML = "";
  for(const [label, fn, cls] of burgerItems()){
    const b = document.createElement("button"); b.className = "bitem" + (cls ? " " + cls : ""); b.textContent = label;
    b.onclick = () => { closeBurger(); if($("modal").hidden || cls === "danger") fn(); };
    nav.appendChild(b);
  }
}
function openBurger(){ renderBurger(); $("drawer").hidden = false; $("burgerBtn").setAttribute("aria-expanded", "true"); const f = $("burgerNav").querySelector("button"); if(f) f.focus(); }
function closeBurger(){ const d = $("drawer"); if(d && !d.hidden){ d.hidden = true; $("burgerBtn").setAttribute("aria-expanded", "false"); } }
function openMyCharms(){
  openModal(`<h2>Mes charmes</h2><p>Ils s'appliquent dans cet ordre. On peut les réordonner à la boutique.</p>
    <div class="charms" id="myCharms"></div><div class="bar"><button class="btn main" id="mcOk">Fermer</button></div>`);
  const box = $("myCharms");
  if(!S.charms.length) box.innerHTML = `<p style="color:var(--dim)">Aucun charme pour l'instant.</p>`;
  S.charms.forEach(({id, ed}) => { const d = document.createElement("div"); d.className = charmClass(ed); d.innerHTML = charmTile(id, "", ed); box.appendChild(d); });
  $("mcOk").onclick = closeModal;
}
function openPlayers(){
  openModal(`<h2>Joueurs</h2><div class="foe multi" id="playersList"></div><div class="bar"><button class="btn main" id="plOk">Fermer</button></div>`);
  $("playersList").innerHTML = $("foe").innerHTML;
  $("plOk").onclick = closeModal;
}
function leaveToMenu(){
  if(MODE === "duel" && NET.ws && !confirm("Quitter la partie en ligne ?")) return;
  titleScreen();
}

/* ---------- boutons et raccourcis ---------- */
$("mPlay").onclick = () => deckSelect(() => startSolo());
$("mContinue").onclick = continueRun;
$("mDaily").onclick = openDaily;
$("mStats").onclick = () => openStats(titleScreen);
$("mJcj").onclick = () => duelLobby();
$("mCodex").onclick = () => openCodex(titleScreen);
$("mRules").onclick = () => openRules();
$("mOptions").onclick = () => openOptions();
$("menuDeck").onclick = () => deckSelect(null, () => { closeModal(); renderMenuFan(); });

$("dealBtn").onclick = deal;
$("hitBtn").onclick = hit;
$("standBtn").onclick = stand;
$("dblBtn").onclick = dbl;
$("splitBtn").onclick = split;
$("burnBtn").onclick = burn;
$("hideBtn").onclick = hide;
$("deckBtn").onclick = () => { if($("modal").hidden) showDeck("view"); };
$("codexBtn").onclick = () => { if($("modal").hidden) openCodex(); };
$("optBtn").onclick = () => { if($("modal").hidden) openOptions(); };
$("menuBtn").onclick = leaveToMenu;
$("burgerBtn").onclick = () => $("drawer").hidden ? openBurger() : closeBurger();
$("drawer").addEventListener("click", e => { if(e.target === $("drawer")) closeBurger(); });

document.addEventListener("keydown", e => {
  if(e.key === "Escape" && !$("drawer").hidden){ closeBurger(); $("burgerBtn").focus(); return; }
  if(e.key === "Escape" && ["deck", "options", "rules", "stats"].includes(modalKind)){ $("game").hidden ? titleScreen() : closeModal(); return; }
  if(e.key === "Escape" && modalKind === "codex"){ closeCodex(); return; }
  if(!$("modal").hidden || $("game").hidden || e.ctrlKey || e.metaKey || e.altKey || e.target.tagName === "INPUT") return;
  const k = e.key.toLowerCase();
  if(k === " " || k === "enter"){ if(!$("dealBtn").disabled && e.target.tagName !== "BUTTON"){ e.preventDefault(); deal(); } }
  else if(k === "t") hit(); else if(k === "r") stand(); else if(k === "d") dbl();
  else if(k === "s") split(); else if(k === "b") burn();
  else if(k === "c") hide(); else if(k === "m") resurface(0);
});
document.body.classList.toggle("calm", SETTINGS.calm);
titleScreen();
