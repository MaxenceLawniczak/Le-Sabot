"use strict";
// Défi du jour : même deck, mêmes cartes, mêmes patrons pour tout le monde, le temps d'une journée.
// Le hasard du jeu passe par un générateur à graine fixe (tirée de la date) ; le hasard purement
// décoratif (flottement des cartes, sons, flammes) garde le vrai hasard pour ne pas le décaler.
// Le classement est tenu par le Worker (/api/daily/AAAA-MM-JJ).

const DAILY = {active:false, date:null, state:0, orig:null};
const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
function hashStr(s){ let h = 1779033703 ^ s.length; for(let i = 0; i < s.length; i++){ h = Math.imul(h ^ s.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; } return h >>> 0; }
function seededRandom(){
  DAILY.state = (DAILY.state + 0x6D2B79F5) >>> 0;
  let t = DAILY.state;
  t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61);
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function startDailyRng(date, state = null){
  DAILY.active = true; DAILY.date = date; DAILY.state = state ?? hashStr("sabot-" + date);
  if(!DAILY.orig){ DAILY.orig = Math.random; Math.random = seededRandom; }
}
function stopDaily(){ if(DAILY.orig){ Math.random = DAILY.orig; DAILY.orig = null; } DAILY.active = false; }
function resumeDaily(d){ startDailyRng(d.date, d.rng); }
const dailyDeck = date => Object.keys(DECKS)[hashStr("deck-" + date) % Object.keys(DECKS).length];

async function fetchBoard(date){
  if(!location.protocol.startsWith("http")) return null;
  try{ const r = await fetch(`/api/daily/${date}`, {cache:"no-store"}); return r.ok ? (await r.json()).top : null; }catch(e){ return null; }
}
async function submitDaily(){
  if(!DAILY.active) return;
  const date = DAILY.date, entry = {name: NET.name || localName(), tables: S.tablesWon || 0, dmg: Math.round(S.dmgTotal || 0), deck: S.deckId};
  stat("daily");
  const key = "sabot:daily:" + date;
  let best = null; try{ best = JSON.parse(localStorage.getItem(key) || "null"); }catch(e){}
  const better = !best || entry.tables > best.tables || (entry.tables === best.tables && entry.dmg > best.dmg);
  if(better){ try{ localStorage.setItem(key, JSON.stringify(entry)); }catch(e){} }
  if(better && location.protocol.startsWith("http")){
    try{ await fetch(`/api/daily/${date}`, {method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify(entry)}); }catch(e){}
  }
  stopDaily();
}
function localName(){ try{ return localStorage.getItem("sabot:name") || "Joueur"; }catch(e){ return "Joueur"; } }

async function openDaily(){
  const date = todayStr(), deck = dailyDeck(date), d = DECKS[deck];
  let best = null; try{ best = JSON.parse(localStorage.getItem("sabot:daily:" + date) || "null"); }catch(e){}
  openModal(`<div class="chead"><h2>Défi du jour</h2><button class="btn" id="dyBack">Retour</button></div>
    <p>Le ${new Date().toLocaleDateString("fr-FR", {weekday:"long", day:"numeric", month:"long"})}, tout le monde joue la même partie : même deck, mêmes cartes, mêmes patrons. Le classement compte les tables gagnées, puis les dégâts infligés.</p>
    <div class="dailydeck"><span id="dyBack2"></span><span><small>Deck imposé</small><b>${d.name}</b><em>${d.desc}</em></span></div>
    <label class="field">Ton pseudo pour le classement<input id="dyName" maxlength="20" value="${esc(localName())}"></label>
    ${best ? `<p class="status">Ton meilleur score aujourd'hui : ${best.tables} table${best.tables > 1 ? "s" : ""}, ${best.dmg.toLocaleString("fr-FR")} dégâts.</p>` : ""}
    <div class="bar"><button class="btn main" id="dyPlay">Jouer le défi</button></div>
    <h3>Classement du jour</h3><ol class="lboard" id="dyBoard"><li class="muted">Chargement…</li></ol>`, "daily");
  $("dyBack2").appendChild(cardEl({}, {hidden:true, back:deck}));
  $("dyBack").onclick = titleScreen;
  $("dyPlay").onclick = () => {
    const n = $("dyName").value.trim().slice(0, 20) || "Joueur"; try{ localStorage.setItem("sabot:name", n); }catch(e){}
    startDailyRng(date); startSolo(deck, true);
  };
  const top = await fetchBoard(date), ol = $("dyBoard"); if(!ol) return;
  if(top === null) ol.innerHTML = `<li class="muted">Classement indisponible : il faut la version en ligne (ou « npx wrangler dev »).</li>`;
  else if(!top.length) ol.innerHTML = `<li class="muted">Personne n'a encore joué aujourd'hui. À toi l'honneur.</li>`;
  else ol.innerHTML = top.map(e => `<li><b>${esc(e.name)}</b><span>${e.tables} table${e.tables > 1 ? "s" : ""} · ${Number(e.dmg).toLocaleString("fr-FR")} dégâts</span></li>`).join("");
}
