"use strict";
// Mode solo : tables, boutique, paquets, services, deck, fin de partie.

/* ======================================================================
   Tables solo, boutique, fin de partie
   ====================================================================== */
async function startTable(){
  let foe;
  if(S.table === 2) foe = {...pickOne(BOSSES.filter(b => !S.usedFoes.includes(b.name)))};
  else foe = {name: pickOne(FOES.filter(n => !S.usedFoes.includes(n))), mod:null, text:""};
  S.usedFoes.push(foe.name);
  foe.maxHp = foe.hp = Math.round(TABLE_HP[S.table] * ANTE_X[S.ante - 1]);
  T = {foe, burns: foe.mod === "bavure" ? 0 : 1 + (has("allumette") ? 1 : 0) + (deckDef().burns || 0), netUsed:false, wins:0, round:0, nails:new Set(), coffin:false, cpUsed:false};
  H = {hands:[], cur:0, d:[], phase:"idle"};
  closeModal(); refreshAll();
  setBoxes(0, 0, 0); $("steps").textContent = "";
  setMsg("Mélange du sabot…");
  busy = true; renderActions();
  await openShoe();
  busy = false;
  setMsg(`${foe.name} t'attend. ${foe.maxHp} PV à faire tomber.`);
  renderHud(); renderActions();
  saveRun("table");
}
function tableWon(){
  if(S.ante === 3 && S.table === 2){ victory(); return; }
  const radin = T.foe.mod === "radin";
  const hands = T.hands || 0;
  // Les intérêts se calculent sur l'or que tu as en poche en quittant la table
  const reward = radin ? 0 : Math.max(0, TABLE_GOLD[S.table] + (deckDef().tableGold || 0));
  const speed = radin ? 0 : Math.max(0, SPEED_PAR - hands);
  const interest = radin ? 0 : interestFor(S.gold);
  const cap = interestCap();
  S.gold += reward + speed + interest;
  S.tablesWon = (S.tablesWon || 0) + 1;
  stat("table", {boss: S.table === 2 ? T.foe.name : null}); stat("gold", {gold: S.gold});
  sfx("win");
  // Roi Midas : une carte classique sans amélioration devient dorée
  let midas = "";
  if(has("midas")){
    const pool = S.deck.filter(c => !isSp(c) && !c.enh);
    if(pool.length){ const c = pickOne(pool); c.enh = "or"; midas = `<tr><td>Roi Midas : ${cardName(c)} devient dorée</td><td>✦</td></tr>`; }
  }
  renderHud();
  openModal(`<h2>${T.foe.name} est à sec</h2>
    <p>Tu remportes la ${TABLE_NAME[S.table].toLowerCase()} en ${hands} main${hands > 1 ? "s" : ""}.${radin ? " Le Radin ne lâche pas un sou." : ""}</p>
    <table class="ledger">
    <tr><td>Gain de la table</td><td>+${reward}</td></tr>
    <tr><td>Rapidité (+1 par main sous ${SPEED_PAR})</td><td>+${speed}</td></tr>
    <tr><td>Intérêts (1 par tranche de 5 or, max ${cap})</td><td>+${interest}</td></tr>
    ${midas}
    <tr><td>Total en poche</td><td>${S.gold} or</td></tr></table>
    <p class="status">Chaque main gagnée t'a aussi rapporté 1 or pendant la table.</p>
    <div class="bar"><button class="btn main" id="toShop">Entrer dans la boutique</button></div>`);
  $("toShop").onclick = () => openShop(true);
  saveRun("shop");
}

let shop = null;
// On tire d'abord une rareté selon son poids, puis un charme de cette rareté pas encore possédé.
function rollOffers(){
  const out = [];
  for(let guard = 0; out.length < 3 && guard < 60; guard++){
    let roll = Math.random() * Object.values(RARITY).reduce((a, r) => a + r.weight, 0), rar = "commun";
    for(const [k, r] of Object.entries(RARITY)){ if((roll -= r.weight) < 0){ rar = k; break; } }
    const pool = Object.keys(CHARMS).filter(id => CHARMS[id].rarity === rar && !has(id) && !out.includes(id));
    if(pool.length) out.push(pickOne(pool));
  }
  // Chaque offre peut sortir avec une édition (foil, holo, poly ou négative)
  return out.map(id => {
    let roll = Math.random(), ed = null;
    for(const [k, e] of Object.entries(CHARM_EDS)){ if((roll -= e.chance) < 0){ ed = k; break; } }
    return {id, ed};
  });
}
function randomEd(){ const r = Math.random(); return r < .5 ? "foil" : r < .85 ? "holo" : "poly"; }
// Les clous que tu n'as pas encore sortent plus souvent ; jamais deux fois la même carte dans un paquet.
// Paquet occulte : cartes spéciales et Nothing. Les clous qui te manquent sortent plus souvent,
// jamais deux fois la même carte dans un paquet.
function occultCards(){
  const owned = new Set([...S.deck, ...S.sleeve].filter(isSp).map(c => c.sp));
  const bag = [];
  for(const id of Object.keys(SPECIALS)){
    const w = SPECIALS[id].nail ? (owned.has(id) ? 1 : 4) : 3;
    for(let i = 0; i < w; i++) bag.push(id);
  }
  for(let i = 0; i < 14; i++) bag.push(NOTHING);
  const out = [];
  while(out.length < 3){
    const id = pickOne(bag);
    const ed = Math.random() < .12 ? randomEd() : null;
    if(id === NOTHING){ out.push(inst(pickOne(NOTHINGS), null, ed)); continue; }
    if(out.some(c => c.sp === id)) continue;
    out.push(spInst(id, ed));
  }
  return out;
}
// Carte au hasard : parfois Nothing, négative, ou à chiffres (jamais négative et à chiffres à la fois)
function randomCard(enhP, edP, negP = 0, nothingP = 0, numP = 0){
  const enhs = Object.keys(ENH);
  if(Math.random() < numP)
    return inst(pickOne(NUM_RANKS) + pickOne(SUITS), Math.random() < enhP ? pickOne(enhs) : null, Math.random() < edP ? randomEd() : null, null, false, true);
  return inst(pickOne(Math.random() < nothingP ? NOTHINGS : FULL), Math.random() < enhP ? pickOne(enhs) : null, Math.random() < edP ? randomEd() : null, null, Math.random() < negP);
}
function openShop(fresh){
  if(fresh) shop = {offers: rollOffers(), reroll: Math.max(0, 2 + (deckDef().reroll || 0)), healed:false, crafted:false, varnished:false, packs:{std:false, shine:false, occult:false, num:false}, tickets: shuffled(Object.keys(TICKETS)).slice(0, 2)};
  const full = slotsUsed() >= charmSlots();
  const offers = shop.offers.map(({id, ed}) => {
    const price = charmPrice(id, ed), blocked = full && ed !== "neg";
    return `<div class="${charmClass(ed)}">${charmTile(id, `<div class="price"><span class="gold">${price} or</span>
      <button data-buy="${id}" ${S.gold < price || blocked ? "disabled" : ""}>Acheter</button></div>`, ed)}</div>`;
  }).join("") || `<p>Plus rien en rayon.</p>`;
  const owned = S.charms.map(({id, ed}, i) => `<div class="${charmClass(ed)}">${charmTile(id, `<div class="price">
      <span class="move"><button data-left="${i}" ${i === 0 ? "disabled" : ""} aria-label="Déplacer à gauche">◀</button><button data-right="${i}" ${i === S.charms.length - 1 ? "disabled" : ""} aria-label="Déplacer à droite">▶</button></span>
      <button data-sell="${i}">Vendre ${Math.floor(charmPrice(id, ed) / 2)}</button></div>`, ed)}</div>`).join("") || `<p style="color:var(--dim)">Aucun charme pour l'instant.</p>`;
  const svc = (id, dis, title, text, price) => `<button class="svc" id="${id}" ${dis ? "disabled" : ""}><b>${title}</b><span>${text}</span><em>${price} or</em></button>`;
  openModal(`<h2>La boutique</h2>
    <p>Tu as <b class="gold">${S.gold} or</b>, ${Math.max(0, S.hp)}/${S.maxHp} PV et ${S.deck.length} cartes. ${MODE === "duel" ? "Les autres joueurs font leurs courses en même temps." : "Prochaine étape : " + nextLabel() + "."}</p>
    <h3>Charmes (${slotsUsed()}/${charmSlots()}) ${full ? "· emplacements pleins : vends-en un, sauf pour un charme négatif" : ""}</h3>
    <div class="charms">${offers}</div>
    <div class="bar"><button class="btn" id="reroll" ${S.gold < shop.reroll ? "disabled" : ""}>Renouveler le rayon (${shop.reroll} or)</button></div>
    <h3>Paquets de cartes : choisis une carte à ajouter à ton deck</h3>
    <div class="services">
      ${svc("packStd", S.gold < 4 || shop.packs.std, "Paquet standard", "4 cartes au choix, parfois améliorées, brillantes, négatives ou en enseigne de valeur. Une fois par visite.", 4)}
      ${svc("packShine", S.gold < 7 || shop.packs.shine, "Paquet éclat", "3 cartes au choix, toutes foil, holo ou poly, parfois négatives. Une fois par visite.", 7)}
      ${svc("packNum", S.gold < 5 || shop.packs.num, "Paquet chiffré", "3 enseignes de valeur au choix (cœur de 4, trèfle de 8…) : leur valeur va dans le mult. Une fois par visite.", 5)}
      ${svc("packOccult", S.gold < 6 || shop.packs.occult, "Paquet occulte", "3 cartes hors du jeu classique : spéciales, clous du cercueil ou Nothing. Une fois par visite.", 6)}
    </div>
    <h3>Tickets à usage unique (${(S.tickets || []).length}/${TICKET_SLOTS})</h3>
    <div class="tickets shoptickets">${shop.tickets.map(id => `<div class="ticket"><span class="tico" aria-hidden="true">${TICKETS[id].ico}</span><span class="ttxt"><b>${TICKETS[id].name}</b><em>${TICKETS[id].desc}</em></span>
      <button class="tuse" data-tbuy="${id}" ${S.gold < TICKETS[id].cost || S.tickets.length >= TICKET_SLOTS ? "disabled" : ""}>${TICKETS[id].cost} or</button></div>`).join("") || `<p class="tempty">Plus de tickets en rayon.</p>`}</div>
    ${S.tickets.length ? `<p class="status">Tes tickets :</p><div class="tickets" id="shopMyTickets"></div>` : ""}
    <h3>Services</h3>
    <div class="services">
      ${svc("svcHeal", S.gold < 3 || shop.healed || S.hp >= S.maxHp, "Remontant", "Récupère 15 PV. Une fois par visite.", 3)}
      ${svc("svcBurn", S.gold < 3 || S.deck.length <= 24, "Brûler une carte", "Retire définitivement une carte de ton deck (minimum 24).", 3)}
      ${svc("svcCraft", S.gold < 4 || shop.crafted, "Atelier", "Améliore une carte parmi 3 : gravée, rubis, dorée ou verre.", 4)}
      ${svc("svcVarnish", S.gold < 6 || shop.varnished, "Vernisseur", "Rends une carte parmi 3 foil, holographique ou polychrome.", 6)}
    </div>
    <h3>Tes charmes (ils s'appliquent de gauche à droite)</h3>
    <div class="charms">${owned}</div>
    <div class="bar"><button class="btn main" id="leave">${MODE === "duel" ? "Prêt pour la suite" : "Aller à la " + nextLabel()}</button></div>`);
  const again = () => { renderCharms(); renderHud(); openShop(false); };
  if(MODE === "solo") saveRun("shop");
  document.querySelectorAll("[data-tbuy]").forEach(b => b.onclick = () => {
    const id = b.dataset.tbuy; S.gold -= TICKETS[id].cost; S.tickets.push(id);
    shop.tickets.splice(shop.tickets.indexOf(id), 1); sfx("coin"); again();
  });
  const mine = $("shopMyTickets");
  if(mine) S.tickets.forEach((id, i) => { const el = ticketEl(id, i, true); el.querySelector("button").onclick = () => useTicket(i, () => openShop(false)); mine.appendChild(el); });
  document.querySelectorAll("[data-buy]").forEach(b => b.onclick = () => {
    const o = shop.offers.find(x => x.id === b.dataset.buy);
    S.gold -= charmPrice(o.id, o.ed); S.charms.push({id: o.id, n:0, ed: o.ed}); sfx("coin"); stat("charm", {id: o.id});
    shop.offers = shop.offers.filter(x => x !== o); again(); sendState();
  });
  document.querySelectorAll("[data-sell]").forEach(b => b.onclick = () => {
    const [st] = S.charms.splice(+b.dataset.sell, 1); S.gold += Math.floor(charmPrice(st.id, st.ed) / 2); again(); sendState();
  });
  document.querySelectorAll("[data-left]").forEach(b => b.onclick = () => { const i = +b.dataset.left; [S.charms[i-1], S.charms[i]] = [S.charms[i], S.charms[i-1]]; again(); });
  document.querySelectorAll("[data-right]").forEach(b => b.onclick = () => { const i = +b.dataset.right; [S.charms[i+1], S.charms[i]] = [S.charms[i], S.charms[i+1]]; again(); });
  $("reroll").onclick = () => { S.gold -= shop.reroll; shop.reroll++; shop.offers = rollOffers(); again(); };
  $("packStd").onclick = () => { S.gold -= 4; shop.packs.std = true; openPack("Paquet standard", Array.from({length:4}, () => randomCard(.3, .12, .2, .1, .15))); };
  $("packNum").onclick = () => { S.gold -= 5; shop.packs.num = true; openPack("Paquet chiffré", Array.from({length:3}, () => randomCard(.25, .15, 0, 0, 1))); };
  $("packOccult").onclick = () => { S.gold -= 6; shop.packs.occult = true; openPack("Paquet occulte", occultCards()); };
  $("packShine").onclick = () => { S.gold -= 7; shop.packs.shine = true; openPack("Paquet éclat", Array.from({length:3}, () => randomCard(.25, 1, .15, 0, .12))); };
  $("svcHeal").onclick = () => { S.gold -= 3; S.hp = Math.min(S.maxHp, S.hp + 15); shop.healed = true; again(); sendState(); };
  $("svcBurn").onclick = () => showDeck("burn");
  $("svcCraft").onclick = () => modifyCard("enh");
  $("svcVarnish").onclick = () => modifyCard("ed");
  $("leave").onclick = () => MODE === "duel" ? duelLeaveShop() : advance();
}
function describe(c){ if(isSp(c)) return SPECIALS[c.sp].desc + (c.ed ? ` ${EDS[c.ed].name} (${EDS[c.ed].desc}).` : ""); return [c.num && "À chiffres (sa valeur va dans le mult)", c.neg && `Négative (${pts(c)} au total)`, c.enh && `${ENH[c.enh].name} (${ENH[c.enh].desc})`, c.ed && `${EDS[c.ed].name} (${EDS[c.ed].desc})`].filter(Boolean).join(" et ") || "Carte simple"; }
function openPack(title, cards){
  renderHud(); sfx("pack");
  openModal(`<h2>${title}</h2><p>Survole les cartes, puis choisis celle qui rejoint ton deck.</p>
    <div class="pack" id="packRow"></div>
    <div class="bar"><button class="btn" id="skip">Ne rien prendre</button></div>`);
  const row = $("packRow");
  cards.forEach(c => {
    const b = document.createElement("button"); b.className = "opt";
    b.appendChild(cardEl(c));
    b.insertAdjacentHTML("beforeend", `<span>${cardName(c)} · ${describe(c)}</span>`);
    b.onclick = () => { S.deck.push(c); renderHud(); openShop(false); };
    row.appendChild(b);
  });
  $("skip").onclick = () => openShop(false);
}
function modifyCard(kind){
  const cost = kind === "enh" ? 4 : 6;
  const picks = shuffled(S.deck.filter(c => !inSleeve(c.uid) && (kind === "ed" || !isSp(c)))).slice(0, 3);
  const choices = picks.map(c => ({c, v: kind === "enh" ? pickOne(Object.keys(ENH)) : randomEd()}));
  openModal(`<h2>${kind === "enh" ? "Atelier" : "Vernisseur"}</h2>
    <p>Choisis la carte à transformer. ${kind === "enh" ? "Une amélioration" : "Une édition"} déjà présente est remplacée.</p>
    <div class="pack" id="modRow"></div>
    <div class="bar"><button class="btn" id="back">Retour à la boutique</button></div>`);
  const row = $("modRow");
  choices.forEach(({c, v}) => {
    const after = {...c, [kind]: v};
    const b = document.createElement("button"); b.className = "opt";
    b.appendChild(cardEl(after));
    b.insertAdjacentHTML("beforeend", `<span>${cardName(c)} devient ${kind === "enh" ? ENH[v].name : EDS[v].name} : ${kind === "enh" ? ENH[v].desc : EDS[v].desc}</span>`);
    b.onclick = () => {
      S.gold -= cost; c[kind] = v;
      if(kind === "enh") shop.crafted = true; else shop.varnished = true;
      renderHud(); openShop(false);
    };
    row.appendChild(b);
  });
  $("back").onclick = () => openShop(false);
}
function nextLabel(){
  const t = S.table === 2 ? 0 : S.table + 1;
  return TABLE_NAME[t].toLowerCase() + (t === 0 ? ` de l'ante ${S.ante + 1}` : "");
}
function advance(){ if(S.table === 2){ S.ante++; S.table = 0; } else S.table++; startTable(); }
function showDeck(mode){
  const burnMode = mode === "burn";
  let html = `<h2>${burnMode ? "Brûler une carte" : "Ton deck"}</h2>
    <p>${S.deck.length} cartes. ${burnMode ? "Clique sur la carte à retirer (3 or)." : ""} ${MODE === "solo" ? "Le croupier pioche dans ce même sabot : retirer les petites cartes l'aide aussi." : ""}</p>`;
  html += SUITS.map(s => `<div><h3>${SUITNAME[s]} ${GLYPH[s]}</h3><div class="deckgrid" data-suit="${s}"></div></div>`).join("");
  if(S.deck.some(c => !isSp(c) && suitOf(c) === NOTHING)) html += `<div><h3>Nothing</h3><div class="deckgrid" data-suit="${NOTHING}"></div></div>`;
  if(S.deck.some(isSp)) html += `<div><h3>Cartes spéciales</h3><div class="deckgrid" data-suit="1"></div></div>`;
  html += `<div class="bar"><button class="btn" id="closeDeck">${burnMode ? "Retour à la boutique" : "Fermer"}</button></div>`;
  openModal(html, burnMode ? null : "deck");
  const order = c => RANKS.indexOf(rankOf(c)) + (c.neg ? 20 : 0) + (c.num ? 40 : 0) + (c.sp ? Object.keys(SPECIALS).indexOf(c.sp) : 0);
  [...SUITS, NOTHING, "1"].forEach(s => {
    const grid = document.querySelector(`.deckgrid[data-suit="${s}"]`); if(!grid) return;
    S.deck.filter(c => suitOf(c) === s).sort((a, b) => order(a) - order(b)).forEach(c => {
      const el = cardEl(c);
      const hidden = inSleeve(c.uid);
      if(hidden){ el.style.opacity = ".45"; el.title = "Dans ta manche"; }
      if(burnMode && !hidden){
        el.classList.add("pick"); el.tabIndex = 0; el.setAttribute("role", "button");
        const go = () => { S.gold -= 3; S.deck = S.deck.filter(i => i.uid !== c.uid); renderHud(); openShop(false); };
        el.onclick = go; el.onkeydown = e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); go(); } };
      }
      grid.appendChild(el);
    });
  });
  $("closeDeck").onclick = () => burnMode ? openShop(false) : closeModal();
}
function gameOver(){
  const daily = DAILY.active; clearRun(); sfx("lose");
  if(daily) submitDaily();
  openModal(`<h2>Fauché</h2>${daily ? `<p class="status">Défi du jour : ${S.tablesWon || 0} table${(S.tablesWon || 0) > 1 ? "s" : ""} gagnée${(S.tablesWon || 0) > 1 ? "s" : ""}, ${Math.round(S.dmgTotal || 0).toLocaleString("fr-FR")} dégâts. Score envoyé au classement.</p>` : ""}
    <p>${T.foe.name} ramasse ta dernière mise à l'ante ${S.ante}, ${TABLE_NAME[S.table].toLowerCase()}.</p>
    <p>Charmes en poche : ${S.charms.map(c => CHARMS[c.id].name).join(", ") || "aucun"}.</p>
    <div class="bar"><button class="btn main" id="again">Nouvelle partie</button><button class="btn" id="toMenu">Menu</button></div>`);
  $("again").onclick = () => deckSelect(startSolo); $("toMenu").onclick = titleScreen;
}
function victory(){
  const daily = DAILY.active; clearRun(); sfx("win"); stat("victory");
  if(daily) submitDaily();
  openModal(`<p class="title-big">Sauté,<br>le patron.</p>${daily ? `<p class="status">Défi du jour réussi : ${Math.round(S.dmgTotal || 0).toLocaleString("fr-FR")} dégâts. Score envoyé au classement.</p>` : ""}
    <p>Tu as vidé les trois antes avec ${S.hp} PV et ${S.gold} or en poche.</p>
    <p>Charmes : ${S.charms.map(c => CHARMS[c.id].name).join(", ") || "aucun, respect"}.</p>
    <div class="bar"><button class="btn main" id="again">Nouvelle partie</button><button class="btn" id="toMenu">Menu</button></div>`);
  $("again").onclick = () => deckSelect(startSolo); $("toMenu").onclick = titleScreen;
}
