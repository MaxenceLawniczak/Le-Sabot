"use strict";
// Illustrations des charmes : un petit tableau SVG par charme, dessiné sur une grille 100 × 64.
// Palette commune pour garder une unité de style.
const CA = {br:"#d9ab52", brd:"#8f6e33", cr:"#f1e8d9", red:"#e25b4a", rd:"#a3281c", bl:"#5ea4dc", bld:"#2c5f8f",
  gr:"#5fbf7a", grd:"#2f7a45", vi:"#b58cff", vid:"#6a45b8", dk:"#1b080c", ink:"#2a1a1f", wh:"#fff", gy:"#9a9aa8"};

// Mini-carte réutilisable (x, y, angle, couleur de l'enseigne, symbole)
const miniCard = (x, y, r, sym = "♠", col = CA.ink) => `<g transform="translate(${x} ${y}) rotate(${r})">
  <rect x="-10" y="-14" width="20" height="28" rx="3" fill="${CA.cr}" stroke="${CA.brd}" stroke-width="1"/>
  <text x="0" y="5" text-anchor="middle" font-size="14" fill="${col}" font-family="serif">${sym}</text></g>`;

const CHARM_ART = {
  pince: `${miniCard(42, 34, -12, "2", CA.red)}${miniCard(58, 34, 12, "3", CA.ink)}
    <path d="M30 60c0-10 6-16 14-18l12-3c4-1 6 3 3 5l-9 5" fill="#e7b48f" stroke="#a86b4a" stroke-width="1.5"/>
    <path d="M70 60c0-9-4-15-10-17" stroke="#a86b4a" stroke-width="1.5" fill="#e7b48f"/>`,
  frime: `<path d="M14 26h72" stroke="${CA.ink}" stroke-width="4" stroke-linecap="round"/>
    <path d="M18 26h26c0 12-4 18-13 18s-13-6-13-18Z" fill="${CA.dk}" stroke="${CA.br}" stroke-width="2"/>
    <path d="M56 26h26c0 12-4 18-13 18s-13-6-13-18Z" fill="${CA.dk}" stroke="${CA.br}" stroke-width="2"/>
    <path d="M24 30l8 8M62 30l8 8" stroke="${CA.wh}" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
    <path d="M86 12l2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" fill="${CA.br}"/>`,
  coeur: `<path d="M50 56C44 50 26 40 26 26c0-8 6-13 12-13 5 0 9 3 12 7 3-4 7-7 12-7 6 0 12 5 12 13 0 14-18 24-24 30Z" fill="${CA.red}"/>
    <path d="M50 20c-6-9-2-16 6-18-2 6 0 11-6 18Z" fill="${CA.gr}"/><path d="M50 20c6-8 14-9 18-4-6 0-11 1-18 4Z" fill="${CA.grd}"/>
    <path d="M36 24q14 8 28 0" stroke="${CA.rd}" stroke-width="2" fill="none"/><path d="M34 34q16 9 32 0" stroke="${CA.rd}" stroke-width="2" fill="none"/>`,
  pique: `<path d="M40 8C36 16 20 22 20 34c0 8 9 12 16 6-1 6-3 9-6 12h20c-3-3-5-6-6-12 7 6 16 2 16-6 0-12-16-18-20-26Z" fill="${CA.cr}" stroke="${CA.brd}" stroke-width="1.5"/>
    <path d="M78 6v26M72 6v12q0 6 6 6t6-6V6" stroke="${CA.gy}" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M78 32v24" stroke="${CA.gy}" stroke-width="5" stroke-linecap="round"/>`,
  trefle: `${[[-1,0],[1,0],[0,-1],[0,1]].map(([dx, dy]) => `<ellipse cx="${50 + dx * 11}" cy="${30 + dy * 11}" rx="11" ry="11" fill="${CA.gr}" stroke="${CA.grd}" stroke-width="2"/>`).join("")}
    <circle cx="50" cy="30" r="5" fill="${CA.grd}"/><path d="M52 40q6 12 16 20" stroke="${CA.grd}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
  gueules: `<path d="M22 48 26 18l14 14 10-20 10 20 14-14 4 30Z" fill="${CA.br}" stroke="${CA.brd}" stroke-width="2"/>
    <rect x="22" y="48" width="56" height="8" rx="2" fill="${CA.brd}"/>
    <circle cx="26" cy="16" r="3.5" fill="${CA.red}"/><circle cx="50" cy="10" r="4" fill="${CA.bl}"/><circle cx="74" cy="16" r="3.5" fill="${CA.red}"/>
    <circle cx="38" cy="52" r="2" fill="${CA.cr}"/><circle cx="50" cy="52" r="2" fill="${CA.cr}"/><circle cx="62" cy="52" r="2" fill="${CA.cr}"/>`,
  as: `<path d="M8 42h44l8 18H8Z" fill="${CA.bld}"/><path d="M8 34h46v10H8Z" fill="${CA.cr}"/>
    <circle cx="44" cy="39" r="2.5" fill="${CA.br}"/>
    ${miniCard(70, 26, 20, "A", CA.ink)}`,
  pile: `<circle cx="42" cy="34" r="24" fill="${CA.cr}"/><circle cx="42" cy="34" r="17" fill="${CA.red}"/><circle cx="42" cy="34" r="10" fill="${CA.cr}"/><circle cx="42" cy="34" r="4.5" fill="${CA.red}"/>
    <path d="M44 32 84 10" stroke="${CA.brd}" stroke-width="3" stroke-linecap="round"/><path d="M80 8l10-4-4 10Z" fill="${CA.gr}"/><path d="M84 14l10 0-6 8Z" fill="${CA.grd}"/>`,
  petit: `<ellipse cx="52" cy="42" rx="24" ry="15" fill="${CA.gy}"/><circle cx="30" cy="32" r="9" fill="${CA.gy}"/>
    <circle cx="26" cy="22" r="7" fill="#c9c9d4"/><circle cx="26" cy="22" r="4" fill="#e8a3b4"/>
    <circle cx="25" cy="33" r="2" fill="${CA.dk}"/><circle cx="21" cy="37" r="2" fill="#e8a3b4"/>
    <path d="M76 44q14 2 14 14" stroke="${CA.gy}" stroke-width="2.5" fill="none" stroke-linecap="round"/>`,
  rapace: `<path d="M50 30C38 18 20 14 4 18c12 4 20 10 26 18 6 2 14 0 20-6Z" fill="${CA.brd}"/>
    <path d="M50 30C62 18 80 14 96 18c-12 4-20 10-26 18-6 2-14 0-20-6Z" fill="${CA.brd}"/>
    <path d="M42 30c0-8 4-14 8-14s8 6 8 14l-4 22h-8Z" fill="#6b4a2b"/><circle cx="50" cy="20" r="6" fill="${CA.cr}"/>
    <path d="M50 22l6 4-6 3Z" fill="${CA.br}"/><circle cx="49" cy="19" r="1.4" fill="${CA.dk}"/>
    <path d="M44 52l-3 8M56 52l3 8" stroke="${CA.br}" stroke-width="2.5" stroke-linecap="round"/>`,
  pyramide: `<path d="M20 58h60l-6-10H26Z" fill="${CA.br}"/><path d="M26 48h48l-6-10H32Z" fill="#e6c06e"/>
    <path d="M32 38h36l-6-10H38Z" fill="${CA.br}"/><path d="M38 28h24l-6-10H44Z" fill="#e6c06e"/><path d="M44 18h12l-6-10Z" fill="${CA.cr}"/>
    <circle cx="80" cy="14" r="7" fill="#ffd97a" opacity=".8"/>`,
  editeur: `<path d="M50 6 62 26 50 58 38 26Z" fill="${CA.bl}"/><path d="M38 26h24L50 58Z" fill="${CA.bld}"/><path d="M50 6 56 26H44Z" fill="#bfe3ff"/>
    ${[[20,14,5],[80,20,6],[24,46,4],[78,50,5]].map(([x, y, s]) => `<path d="M${x} ${y - s}l${s * .35} ${s * .65} ${s * .65} ${s * .35}-${s * .65} ${s * .35}-${s * .35} ${s * .65}-${s * .35}-${s * .65}-${s * .65}-${s * .35} ${s * .65}-${s * .35}Z" fill="${CA.br}"/>`).join("")}`,
  kamikaze: `<path d="M50 4l7 16 17-8-6 17 18 4-16 9 12 14-18-3 1 18-15-11-11 14-2-18-17 6 9-15-15-10 18-3-7-17 17 6Z" fill="${CA.red}"/>
    <path d="M50 16l4 10 10-5-4 10 10 3-10 5 6 8-10-2v10l-8-7-7 8-1-10-10 3 5-8-8-6 10-2-4-10 10 4Z" fill="#ffc15a"/><circle cx="50" cy="32" r="6" fill="#fff4c2"/>`,
  cassecou: `<path d="M22 44c0-18 12-30 28-30s28 12 28 30Z" fill="${CA.red}"/><rect x="16" y="44" width="68" height="7" rx="3" fill="${CA.rd}"/>
    <path d="M50 16l-4 10 6 5-5 9" stroke="${CA.dk}" stroke-width="2.5" fill="none" stroke-linejoin="round"/>
    <path d="M30 22h40" stroke="${CA.cr}" stroke-width="5" stroke-linecap="round" opacity=".8"/><path d="M40 20v4M50 20v4M60 20v4" stroke="${CA.rd}" stroke-width="1.5"/>`,
  parachute: `<path d="M14 28C14 12 32 4 50 4s36 8 36 24c-6-4-12-4-18 0-6-4-12-4-18 0-6-4-12-4-18 0-6-4-12-4-18 0Z" fill="${CA.br}"/>
    <path d="M32 28C32 14 40 4 50 4s18 10 18 24" fill="none" stroke="${CA.brd}" stroke-width="1.5"/>
    <path d="M14 28 46 50M32 28l16 22M68 28 52 50M86 28 54 50" stroke="${CA.cr}" stroke-width="1"/>
    <rect x="42" y="48" width="16" height="12" rx="2" fill="${CA.brd}"/><text x="50" y="58" text-anchor="middle" font-size="10" fill="${CA.cr}" font-family="serif">$</text>`,
  culot: `${[0, 1, 2, 3].map(i => `<ellipse cx="38" cy="${54 - i * 7}" rx="16" ry="5" fill="${i % 2 ? CA.red : CA.cr}" stroke="${CA.rd}" stroke-width="1.2"/>`).join("")}
    ${[0, 1, 2, 3, 4, 5].map(i => `<ellipse cx="66" cy="${56 - i * 7}" rx="14" ry="4.5" fill="${i % 2 ? CA.bl : CA.cr}" stroke="${CA.bld}" stroke-width="1.2"/>`).join("")}
    <path d="M84 20V6m0 0-6 6m6-6 6 6" stroke="${CA.gr}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
  fanfaron: `<path d="M12 30h40l24-16v36L52 34H12Z" fill="${CA.br}" stroke="${CA.brd}" stroke-width="2"/>
    <ellipse cx="76" cy="32" rx="6" ry="18" fill="#e6c06e" stroke="${CA.brd}" stroke-width="2"/>
    <circle cx="28" cy="24" r="3" fill="${CA.brd}"/><circle cx="36" cy="24" r="3" fill="${CA.brd}"/><circle cx="44" cy="24" r="3" fill="${CA.brd}"/>
    <path d="M86 16l6-4M88 32h8M86 48l6 4" stroke="${CA.cr}" stroke-width="2.5" stroke-linecap="round"/>`,
  adrenaline: `<g transform="rotate(-30 50 32)"><rect x="24" y="24" width="44" height="16" rx="3" fill="${CA.cr}" stroke="${CA.gy}" stroke-width="2"/>
    <rect x="26" y="26" width="26" height="12" fill="${CA.red}"/><path d="M68 32h18" stroke="${CA.gy}" stroke-width="2.5"/>
    <rect x="14" y="26" width="10" height="12" fill="${CA.gy}"/><rect x="8" y="22" width="6" height="20" rx="1" fill="${CA.gy}"/>
    <path d="M34 24v5M42 24v5M50 24v5" stroke="${CA.gy}" stroke-width="1.5"/></g>`,
  doubleur: `<g transform="rotate(-12 34 34)"><rect x="16" y="16" width="36" height="36" rx="7" fill="${CA.cr}" stroke="${CA.brd}" stroke-width="2"/>
    ${[[25,25],[43,43],[34,34]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3.5" fill="${CA.red}"/>`).join("")}</g>
    <g transform="rotate(14 68 30)"><rect x="50" y="12" width="36" height="36" rx="7" fill="${CA.red}" stroke="${CA.rd}" stroke-width="2"/>
    ${[[59,21],[77,21],[59,39],[77,39]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3.5" fill="${CA.cr}"/>`).join("")}</g>`,
  jumeaux: `${miniCard(38, 32, -8, "7", CA.red)}${miniCard(62, 32, 8, "7", CA.red)}
    <path d="M50 8v48" stroke="${CA.vi}" stroke-width="1.5" stroke-dasharray="3 3"/>`,
  siamois: `${miniCard(36, 32, -6, "8", CA.ink)}${miniCard(64, 32, 6, "8", CA.ink)}
    <path d="M44 34q6-6 12 0q-6 6-12 0Z" fill="${CA.red}"/><path d="M40 34h20" stroke="${CA.red}" stroke-width="3"/>`,
  ricochet: `<path d="M20 46C30 20 52 12 76 12c-6 6-8 12-8 18-14-2-28 4-36 20Z" fill="${CA.br}" stroke="${CA.brd}" stroke-width="2"/>
    <path d="M30 42c8-12 22-20 38-22" stroke="${CA.brd}" stroke-width="1.5" fill="none"/>
    <path d="M78 34q10 10 2 22M70 40q6 6 0 14" stroke="${CA.cr}" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-dasharray="4 4"/>`,
  scission: `<circle cx="28" cy="46" r="9" fill="none" stroke="${CA.red}" stroke-width="4.5"/><circle cx="28" cy="18" r="9" fill="none" stroke="${CA.red}" stroke-width="4.5"/>
    <path d="M36 42 86 14M36 22l50 28" stroke="${CA.gy}" stroke-width="5" stroke-linecap="round"/><circle cx="52" cy="32" r="3" fill="${CA.dk}"/>`,
  rancune: `<path d="M22 34a14 14 0 0 1 12-20 18 18 0 0 1 32 2 12 12 0 0 1 8 18Z" fill="#4a4a58"/>
    <path d="M30 26l8 3M70 26l-8 3" stroke="${CA.red}" stroke-width="3" stroke-linecap="round"/>
    <path d="M52 34 44 48h8l-6 14 16-20h-8l6-8Z" fill="#ffd84a"/>`,
  diplomate: `<path d="M20 52C36 44 50 30 62 10" stroke="${CA.grd}" stroke-width="3" fill="none" stroke-linecap="round"/>
    ${[[30,44,-40],[40,36,-50],[48,26,-60],[56,18,-65],[36,46,30],[46,38,30],[54,28,20]].map(([x, y, r]) => `<ellipse cx="${x}" cy="${y}" rx="8" ry="3.5" transform="rotate(${r} ${x} ${y})" fill="${CA.gr}"/>`).join("")}
    <circle cx="66" cy="10" r="4" fill="#7a8b3a"/><circle cx="76" cy="34" r="6" fill="${CA.wh}"/><path d="M70 34c-6 0-10 4-12 8 6-2 10-2 12-4" fill="${CA.wh}"/>`,
  filet: `<path d="M12 12Q50 70 88 12" fill="none" stroke="${CA.cr}" stroke-width="3"/>
    ${[20, 32, 44, 56, 68, 80].map(x => `<path d="M${x} 12Q${50 + (x - 50) * .5} 52 50 56" fill="none" stroke="${CA.cr}" stroke-width="1.3" opacity=".8"/>`).join("")}
    ${[22, 32, 42].map(y => `<path d="M${18 + (y - 12) * .4} ${y}Q50 ${y + 14} ${82 - (y - 12) * .4} ${y}" fill="none" stroke="${CA.cr}" stroke-width="1.3" opacity=".8"/>`).join("")}
    <circle cx="50" cy="16" r="6" fill="${CA.br}"/>`,
  voyeur: `<path d="M8 32Q50 -4 92 32Q50 68 8 32Z" fill="${CA.cr}"/><circle cx="50" cy="32" r="15" fill="${CA.bl}"/><circle cx="50" cy="32" r="7" fill="${CA.dk}"/>
    <circle cx="54" cy="27" r="3" fill="${CA.wh}"/><path d="M8 32Q50 -4 92 32" fill="none" stroke="${CA.ink}" stroke-width="3"/>`,
  devin: `<rect x="30" y="50" width="40" height="8" rx="3" fill="${CA.brd}"/><path d="M36 50l4-6h20l4 6Z" fill="${CA.br}"/>
    <circle cx="50" cy="26" r="20" fill="${CA.vid}"/><circle cx="50" cy="26" r="20" fill="url(#ca-orb)"/>
    <path d="M40 18a12 12 0 0 1 10-6" stroke="${CA.wh}" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>
    <path d="M46 30l4-8 4 8-4-2Z" fill="${CA.cr}" opacity=".85"/>`,
  elastique: `<path d="M50 6v6${[0, 1, 2, 3, 4, 5].map(() => "l-16 3 32 4-16 3").join("")}v6" fill="none" stroke="${CA.gr}" stroke-width="3.5" stroke-linejoin="round"/>
    <rect x="34" y="2" width="32" height="6" rx="2" fill="${CA.gy}"/><rect x="34" y="56" width="32" height="6" rx="2" fill="${CA.gy}"/>`,
  vampire: `<path d="M50 24C42 12 28 10 6 14c8 4 10 10 8 16 6-4 12-2 16 4 4-4 10-4 14 0Z" fill="#3a2a4a"/>
    <path d="M50 24c8-12 22-14 44-10-8 4-10 10-8 16-6-4-12-2-16 4-4-4-10-4-14 0Z" fill="#3a2a4a"/>
    <ellipse cx="50" cy="32" rx="8" ry="12" fill="#4a3660"/><path d="M44 20l2-8 3 6M56 20l-2-8-3 6" fill="#4a3660"/>
    <circle cx="47" cy="28" r="1.8" fill="${CA.red}"/><circle cx="53" cy="28" r="1.8" fill="${CA.red}"/><path d="M48 36l1 3 1-3M52 36l-1 3-1-3" fill="${CA.wh}"/>`,
  carapace: `<ellipse cx="50" cy="38" rx="32" ry="20" fill="${CA.grd}"/><path d="M18 38a32 22 0 0 1 64 0Z" fill="${CA.gr}"/>
    <path d="M50 18v20M34 22l6 16M66 22l-6 16M22 32h14M78 32H64" stroke="${CA.grd}" stroke-width="2"/>
    <path d="M40 38l10-8 10 8-4 0h-12Z" fill="#8ad19d"/><circle cx="86" cy="40" r="7" fill="#8ad19d"/><circle cx="88" cy="38" r="1.5" fill="${CA.dk}"/>`,
  banquier: `<path d="M36 18c-12 8-18 22-16 32 2 8 10 10 30 10s28-2 30-10c2-10-4-24-16-32Z" fill="#b8862b"/>
    <path d="M36 18h28l-4-8H40Z" fill="#d9a441"/><path d="M34 18h32" stroke="${CA.brd}" stroke-width="3"/>
    <text x="50" y="48" text-anchor="middle" font-size="22" font-weight="bold" fill="${CA.cr}" font-family="serif">¤</text>`,
  allumette: `<path d="M26 58 66 18" stroke="#e8c48a" stroke-width="5" stroke-linecap="round"/><circle cx="68" cy="16" r="6" fill="${CA.red}"/>
    <path d="M70 12c-4-6 0-12 6-12-2 4 2 6 2 10 2-2 4-2 4 0 0 6-6 8-12 2Z" fill="#ffb13b"/><path d="M72 10c-1-4 1-6 4-7 0 3 2 4 1 7Z" fill="#fff1a8"/>`,
  manchelarge: `<path d="M10 20h40l6 10H16Z" fill="${CA.vid}"/><path d="M16 30h40l30 22H24Z" fill="${CA.vi}"/>
    <path d="M56 30l30 22" stroke="${CA.vid}" stroke-width="2"/><circle cx="30" cy="40" r="2.5" fill="${CA.br}"/><circle cx="40" cy="40" r="2.5" fill="${CA.br}"/>
    ${miniCard(80, 24, 16, "?", CA.vid)}`,
  passepasse: `<rect x="28" y="14" width="34" height="30" rx="2" fill="#2a2030" stroke="${CA.br}" stroke-width="1.5"/>
    <rect x="28" y="36" width="34" height="6" fill="${CA.red}"/><ellipse cx="45" cy="46" rx="26" ry="6" fill="#2a2030" stroke="${CA.br}" stroke-width="1.5"/>
    <path d="M66 50 88 20" stroke="${CA.dk}" stroke-width="4" stroke-linecap="round"/><path d="M86 22l4-6" stroke="${CA.cr}" stroke-width="4" stroke-linecap="round"/>
    <path d="M84 8l1.5 3.5L89 13l-3.5 1.5L84 18l-1.5-3.5L79 13l3.5-1.5Z" fill="${CA.br}"/>`,
  pickpocket: `<path d="M34 58V28c0-3 5-3 5 0v12V18c0-3 5-3 5 0v20V16c0-3 5-3 5 0v22V20c0-3 5-3 5 0v26l6-8c2-3 6-1 5 2l-8 16c-3 4-6 6-12 6H44c-6 0-10-4-10-4Z" fill="${CA.dk}" stroke="${CA.gy}" stroke-width="1.5"/>
    <circle cx="78" cy="18" r="8" fill="${CA.br}" stroke="${CA.brd}" stroke-width="1.5"/><text x="78" y="22" text-anchor="middle" font-size="10" fill="${CA.brd}" font-family="serif">¤</text>`,
  fossoyeur: `<path d="M56 60V30c0-10 20-10 20 0v30Z" fill="${CA.gy}"/><path d="M62 36h8M66 32v10" stroke="#6a6a78" stroke-width="2"/>
    <path d="M18 8 42 50" stroke="#8a5a32" stroke-width="3.5" stroke-linecap="round"/><path d="M38 44l10 16 6-10Z" fill="${CA.gy}"/>
    <path d="M10 60h80" stroke="#4a3620" stroke-width="4"/>`,
  zen: `<path d="M50 8a24 24 0 1 1-22 12" fill="none" stroke="${CA.cr}" stroke-width="7" stroke-linecap="round" opacity=".92"/>
    <path d="M28 20a24 24 0 0 1 8-8" fill="none" stroke="${CA.cr}" stroke-width="3" stroke-linecap="round" opacity=".6"/>
    <circle cx="50" cy="32" r="5" fill="#111"/>`,
  antimatiere: `<ellipse cx="50" cy="32" rx="34" ry="11" fill="none" stroke="${CA.vi}" stroke-width="2.5"/>
    <ellipse cx="50" cy="32" rx="34" ry="11" transform="rotate(60 50 32)" fill="none" stroke="${CA.vi}" stroke-width="2.5"/>
    <ellipse cx="50" cy="32" rx="34" ry="11" transform="rotate(-60 50 32)" fill="none" stroke="${CA.vi}" stroke-width="2.5"/>
    <circle cx="50" cy="32" r="7" fill="${CA.dk}" stroke="${CA.vi}" stroke-width="2"/><text x="50" y="36" text-anchor="middle" font-size="11" fill="${CA.vi}" font-family="serif">−</text>`,
  bouffon: `<path d="M50 50C44 30 30 18 14 16c6 8 8 18 4 28Z" fill="${CA.red}"/><path d="M50 50C56 30 70 18 86 16c-6 8-8 18-4 28Z" fill="${CA.vi}"/>
    <path d="M50 50C48 30 50 14 50 6c2 8 4 24 2 44Z" fill="${CA.br}"/>
    <circle cx="14" cy="16" r="4.5" fill="${CA.br}"/><circle cx="86" cy="16" r="4.5" fill="${CA.br}"/><circle cx="50" cy="6" r="4" fill="${CA.cr}"/>
    <path d="M18 50h64l-4 8H22Z" fill="${CA.br}"/>`,
  contrepoids: `<path d="M50 8v48M34 58h32" stroke="${CA.br}" stroke-width="3.5" stroke-linecap="round"/>
    <path d="M18 18h64" stroke="${CA.br}" stroke-width="3" transform="rotate(-8 50 18)"/>
    <path d="M22 16 12 36h20Z" fill="none" stroke="${CA.brd}" stroke-width="1.5"/><path d="M78 20 68 40h20Z" fill="none" stroke="${CA.brd}" stroke-width="1.5"/>
    <path d="M10 36a12 5 0 0 0 24 0Z" fill="${CA.br}"/><path d="M66 40a12 5 0 0 0 24 0Z" fill="${CA.br}"/>
    <rect x="16" y="26" width="12" height="9" rx="1.5" fill="${CA.red}"/><text x="22" y="34" text-anchor="middle" font-size="8" fill="${CA.wh}" font-family="serif">−</text>`,
  ouroboros: `<path d="M50 8a24 24 0 1 1-20 11" fill="none" stroke="${CA.grd}" stroke-width="10" stroke-linecap="round"/>
    <path d="M50 8a24 24 0 1 1-20 11" fill="none" stroke="${CA.gr}" stroke-width="5" stroke-linecap="round" stroke-dasharray="4 5"/>
    <path d="M30 19c-6-2-10 2-10 6s6 6 12 3Z" fill="${CA.grd}"/><circle cx="25" cy="22" r="1.5" fill="#ffd84a"/>
    <path d="M36 20l-8 4 7 3" fill="${CA.red}"/>`,
};


// ---- vague 2 ----
Object.assign(CHARM_ART, {
  tirelire: `<ellipse cx="48" cy="38" rx="28" ry="19" fill="#e8a3b4"/><circle cx="72" cy="34" r="9" fill="#e8a3b4"/><ellipse cx="78" cy="36" rx="5" ry="4" fill="#d27f94"/>
    <circle cx="77" cy="35" r="1" fill="${CA.dk}"/><circle cx="80" cy="35" r="1" fill="${CA.dk}"/><circle cx="68" cy="30" r="1.6" fill="${CA.dk}"/>
    <path d="M36 22l6 6M60 22l-4 6" stroke="#d27f94" stroke-width="4" stroke-linecap="round"/><rect x="40" y="18" width="14" height="4" rx="2" fill="${CA.dk}"/>
    <path d="M30 54v6M62 54v6" stroke="#d27f94" stroke-width="5" stroke-linecap="round"/><circle cx="47" cy="10" r="6" fill="${CA.br}" stroke="${CA.brd}"/>`,
  pactole: `<path d="M50 6 70 22 50 58 30 22Z" fill="${CA.bl}"/><path d="M30 22h40L50 58Z" fill="${CA.bld}"/><path d="M40 22 50 6 60 22Z" fill="#bfe3ff"/>
    ${[[18,50],[80,48],[24,40]].map(([x, y]) => `<ellipse cx="${x}" cy="${y}" rx="9" ry="3.5" fill="${CA.br}" stroke="${CA.brd}"/>`).join("")}`,
  coffre: `<rect x="20" y="14" width="60" height="44" rx="4" fill="${CA.gy}" stroke="#6a6a78" stroke-width="2"/><rect x="26" y="20" width="48" height="32" rx="2" fill="none" stroke="#6a6a78" stroke-width="1.5"/>
    <circle cx="50" cy="36" r="10" fill="#c9c9d4" stroke="#6a6a78" stroke-width="2"/><path d="M50 26v20M40 36h20M43 29l14 14M57 29 43 43" stroke="#6a6a78" stroke-width="1.5"/>
    <rect x="76" y="24" width="6" height="8" fill="#6a6a78"/><rect x="76" y="40" width="6" height="8" fill="#6a6a78"/>`,
  fauxmonnayeur: `<circle cx="36" cy="32" r="18" fill="${CA.br}" stroke="${CA.brd}" stroke-width="2"/><text x="36" y="39" text-anchor="middle" font-size="18" fill="${CA.brd}" font-family="serif">¤</text>
    <circle cx="64" cy="32" r="18" fill="#c9a24a" stroke="${CA.brd}" stroke-width="2" stroke-dasharray="3 2"/><text x="64" y="39" text-anchor="middle" font-size="18" fill="${CA.brd}" font-family="serif" opacity=".6">¤</text>
    <path d="M46 10l8 44" stroke="${CA.red}" stroke-width="2" stroke-dasharray="3 3"/>`,
  midas: `<path d="M30 60V30c0-3 5-3 5 0v8V14c0-3 5-3 5 0v22V10c0-3 5-3 5 0v26V14c0-3 5-3 5 0v26l6-8c2-3 6-1 5 2l-8 16c-3 4-6 6-12 6H40c-6 0-10-4-10-4Z" fill="${CA.br}" stroke="${CA.brd}" stroke-width="1.5"/>
    ${[[78,14],[20,20],[82,44]].map(([x, y]) => `<path d="M${x} ${y - 5}l1.5 3.5 3.5 1.5-3.5 1.5-1.5 3.5-1.5-3.5-3.5-1.5 3.5-1.5Z" fill="#fff3bf"/>`).join("")}`,
  paire: `${miniCard(38, 32, -10, "Q", CA.red)}${miniCard(62, 32, 10, "Q", CA.ink)}<circle cx="50" cy="54" r="6" fill="${CA.br}"/><text x="50" y="58" text-anchor="middle" font-size="9" fill="${CA.dk}" font-family="serif">=</text>`,
  monochrome: `${[0, 1, 2].map(i => miniCard(32 + i * 18, 32, -12 + i * 12, "♣", CA.grd)).join("")}<path d="M12 56h76" stroke="${CA.gr}" stroke-width="3" stroke-linecap="round"/>`,
  escalier: `<path d="M16 56h16V44h16V32h16V20h16" fill="none" stroke="${CA.br}" stroke-width="4" stroke-linejoin="round"/>
    <text x="24" y="52" text-anchor="middle" font-size="10" fill="${CA.cr}" font-family="serif">4</text><text x="40" y="40" text-anchor="middle" font-size="10" fill="${CA.cr}" font-family="serif">5</text>
    <text x="56" y="28" text-anchor="middle" font-size="10" fill="${CA.cr}" font-family="serif">6</text><text x="72" y="16" text-anchor="middle" font-size="10" fill="${CA.cr}" font-family="serif">7</text>`,
  damier: `${[0,1,2,3,4,5].map(c => [0,1,2,3].map(r => `<rect x="${20 + c * 10}" y="${12 + r * 10}" width="10" height="10" fill="${(c + r) % 2 ? CA.dk : CA.red}"/>`).join("")).join("")}
    <rect x="20" y="12" width="60" height="40" fill="none" stroke="${CA.br}" stroke-width="2"/>`,
  arlequin: `<path d="M50 6 80 32 50 58 20 32Z" fill="${CA.red}"/><path d="M50 6 65 19 50 32 35 19Z" fill="${CA.bl}"/><path d="M35 19 50 32 35 45 20 32Z" fill="${CA.gr}"/>
    <path d="M65 19 80 32 65 45 50 32Z" fill="${CA.br}"/><path d="M50 32 65 45 50 58 35 45Z" fill="${CA.vi}"/>`,
  sept: `<text x="50" y="52" text-anchor="middle" font-size="48" font-weight="bold" fill="${CA.br}" font-family="serif" stroke="${CA.brd}" stroke-width="1.5">7</text>
    <path d="M22 16l2 5 5 2-5 2-2 5-2-5-5-2 5-2ZM80 40l1.5 3.5 3.5 1.5-3.5 1.5L80 50l-1.5-3.5L75 45l3.5-1.5Z" fill="#fff3bf"/>`,
  mainpleine: `${[0,1,2,3,4].map(i => miniCard(26 + i * 12, 34, -20 + i * 10, "♦", CA.red)).join("")}`,
  duo: `${miniCard(40, 32, -8, "A", CA.ink)}${miniCard(60, 32, 8, "K", CA.red)}<text x="84" y="22" text-anchor="middle" font-size="12" fill="${CA.br}" font-family="serif">×2,5</text>`,
  jackpot: `<rect x="18" y="10" width="64" height="44" rx="6" fill="${CA.red}" stroke="${CA.rd}" stroke-width="2"/>
    ${[0,1,2].map(i => `<rect x="${24 + i * 18}" y="18" width="16" height="24" rx="2" fill="${CA.cr}"/><text x="${32 + i * 18}" y="36" text-anchor="middle" font-size="14" fill="${CA.red}" font-family="serif">7</text>`).join("")}
    <path d="M82 20h6v18" stroke="${CA.gy}" stroke-width="3" fill="none"/><circle cx="88" cy="16" r="4" fill="${CA.red}"/><rect x="30" y="46" width="40" height="4" rx="2" fill="${CA.br}"/>`,
  depipe: `<g transform="rotate(-18 50 32)"><rect x="30" y="12" width="40" height="40" rx="8" fill="${CA.cr}" stroke="${CA.brd}" stroke-width="2"/>
    ${[[40,22],[60,22],[40,42],[60,42],[40,32],[60,32]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="3.6" fill="${CA.ink}"/>`).join("")}</g>
    <path d="M78 50q6 4 12 0" stroke="${CA.red}" stroke-width="2.5" fill="none"/><circle cx="84" cy="44" r="2" fill="${CA.red}"/>`,
  debutant: `${[[-1,0],[1,0],[0,-1]].map(([dx, dy]) => `<ellipse cx="${50 + dx * 11}" cy="${30 + dy * 11}" rx="11" ry="11" fill="${CA.gr}" stroke="${CA.grd}" stroke-width="2"/>`).join("")}
    <circle cx="50" cy="30" r="5" fill="${CA.grd}"/><path d="M50 34v24" stroke="${CA.grd}" stroke-width="3.5" stroke-linecap="round"/>
    <text x="80" y="54" text-anchor="middle" font-size="16" fill="${CA.br}" font-family="serif">1</text>`,
  dernier: `<rect x="40" y="26" width="20" height="32" rx="2" fill="${CA.cr}"/><path d="M40 30h20" stroke="#d8cdb8" stroke-width="2"/>
    <path d="M50 26v-4" stroke="${CA.ink}" stroke-width="1.5"/><path d="M50 4c-6 8-6 14 0 18 6-4 6-10 0-18Z" fill="#ffb13b"/><path d="M50 12c-2 4-2 6 0 8 2-2 2-4 0-8Z" fill="#fff1a8"/>
    <path d="M34 58h32" stroke="${CA.brd}" stroke-width="4" stroke-linecap="round"/>`,
  masochiste: `<rect x="18" y="22" width="64" height="20" rx="10" fill="#e8c48a" transform="rotate(-20 50 32)"/>
    <rect x="38" y="22" width="24" height="20" fill="#f4dfb8" transform="rotate(-20 50 32)"/>
    ${[[44,28],[52,26],[48,36],[56,33]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1.4" fill="#c9a06a"/>`).join("")}
    <path d="M78 8l-4 8h6l-4 8" stroke="${CA.red}" stroke-width="2.5" fill="none"/>`,
  croquemort: `<path d="M34 58h32l-4-30c-2-10-22-10-24 0Z" fill="${CA.gy}"/><rect x="30" y="16" width="40" height="6" rx="3" fill="#6a6a78"/>
    <path d="M44 34h12M50 30v14" stroke="#6a6a78" stroke-width="2.5"/><path d="M76 20v-10M72 14h8" stroke="${CA.br}" stroke-width="2"/>`,
  recuperateur: `${[0, 120, 240].map(r => `<path d="M50 14a18 18 0 0 1 16 10" stroke="${CA.gr}" stroke-width="6" fill="none" transform="rotate(${r} 50 32)" stroke-linecap="round"/><path d="M62 20l6 6-8 1Z" fill="${CA.gr}" transform="rotate(${r} 50 32)"/>`).join("")}
    <circle cx="50" cy="32" r="7" fill="${CA.br}"/>`,
  pyromane: `<path d="M50 60c-16 0-24-10-20-24 3 6 8 8 10 6-4-12 4-24 14-32-2 10 6 14 10 20 2-4 1-8 0-12 8 8 12 20 6 30-4 8-10 12-20 12Z" fill="${CA.red}"/>
    <path d="M50 60c-8 0-12-6-10-14 3 4 6 4 7 2-2-8 2-14 7-18 0 8 6 10 6 18 0 8-4 12-10 12Z" fill="#ffb13b"/><path d="M50 60c-3 0-5-3-4-7 2 2 3 1 3 0 0-3 2-6 4-7 0 4 2 5 2 8 0 4-2 6-5 6Z" fill="#fff1a8"/>`,
  illusionniste: `<path d="M20 50 72 14" stroke="${CA.dk}" stroke-width="6" stroke-linecap="round"/><path d="M66 18l8-6" stroke="${CA.cr}" stroke-width="6" stroke-linecap="round"/>
    ${[[80,8,6],[84,26,4],[62,6,4],[88,16,3]].map(([x, y, r]) => `<path d="M${x} ${y - r}l${r * .3} ${r * .7} ${r * .7} ${r * .3}-${r * .7} ${r * .3}-${r * .3} ${r * .7}-${r * .3}-${r * .7}-${r * .7}-${r * .3} ${r * .7}-${r * .3}Z" fill="${CA.vi}"/>`).join("")}
    ${miniCard(34, 44, -30, "?", CA.vid)}`,
  graveur: `<path d="M20 50 56 14" stroke="#8a5a32" stroke-width="5" stroke-linecap="round"/><rect x="50" y="6" width="26" height="14" rx="2" fill="${CA.gy}" transform="rotate(45 63 13)"/>
    <rect x="52" y="40" width="34" height="18" rx="2" fill="url(#enh-steel)" stroke="#7d8a99"/><path d="M56 46h26M56 50h20M56 54h24" stroke="#5f6f82" stroke-width="1"/>`,
  lapidaire: `<circle cx="50" cy="40" r="16" fill="none" stroke="${CA.br}" stroke-width="5"/>
    <path d="M38 18l6-8h12l6 8-12 14Z" fill="${CA.red}"/><path d="M38 18h24L50 32Z" fill="${CA.rd}"/><path d="M44 10l3 8h6l3-8Z" fill="#ff8a9b"/>`,
  verrier: `<path d="M34 10h32M40 10c0 14-14 18-14 32 0 10 10 16 24 16s24-6 24-16c0-14-14-18-14-32" fill="#bfe3ff" fill-opacity=".35" stroke="#e6f3ff" stroke-width="2.5"/>
    <path d="M34 36c4-2 6 4 2 12" stroke="#fff" stroke-width="2.5" fill="none" opacity=".7"/>`,
  prismatique: `<path d="M50 8 74 52H26Z" fill="none" stroke="${CA.cr}" stroke-width="3"/>
    <path d="M6 36 38 32" stroke="${CA.wh}" stroke-width="3"/>
    ${["#ff5e7e","#ffd25e","#5effa0","#5ec8ff","#c05eff"].map((c, i) => `<path d="M62 30 94 ${16 + i * 8}" stroke="${c}" stroke-width="3"/>`).join("")}`,
  boulier: `<rect x="16" y="8" width="68" height="48" rx="3" fill="none" stroke="#8a5a32" stroke-width="4"/>
    ${[18, 30, 42].map((y, r) => `<path d="M18 ${y}h64" stroke="#6b4a2b" stroke-width="1.5"/>${[0,1,2,3,4].map(i => `<circle cx="${26 + i * 8 + (r === 1 ? 16 : r === 2 ? 8 : 0)}" cy="${y}" r="3.6" fill="${[CA.red, CA.br, CA.bl][r]}"/>`).join("")}`).join("")}`,
  numerologue: `<text x="50" y="30" text-anchor="middle" font-size="18" fill="${CA.br}" font-family="serif">1 2 3</text>
    <text x="50" y="52" text-anchor="middle" font-size="18" fill="${CA.cr}" font-family="serif">4 5 6</text>
    <circle cx="50" cy="32" r="28" fill="none" stroke="${CA.vi}" stroke-width="1.5" stroke-dasharray="3 3"/>`,
  mecene: `<path d="M16 22 50 8l34 14Z" fill="${CA.cr}"/><rect x="16" y="22" width="68" height="4" fill="${CA.cr}"/>
    ${[24, 38, 52, 66].map(x => `<rect x="${x}" y="28" width="8" height="24" fill="${CA.cr}"/>`).join("")}<rect x="12" y="52" width="76" height="6" fill="${CA.cr}"/>
    <circle cx="50" cy="16" r="3" fill="${CA.br}"/>`,
  photocopie: `<rect x="16" y="26" width="68" height="28" rx="4" fill="${CA.gy}"/><rect x="22" y="20" width="56" height="8" rx="2" fill="#c9c9d4"/>
    <rect x="30" y="8" width="40" height="14" fill="${CA.cr}"/><rect x="28" y="44" width="44" height="12" fill="${CA.cr}"/>
    <path d="M34 48h20M34 52h28" stroke="${CA.gy}" stroke-width="1.5"/><circle cx="74" cy="34" r="3" fill="${CA.gr}"/><rect x="20" y="36" width="60" height="3" fill="#5ec8ff" opacity=".7"/>`,
});

// Dégradé partagé (boule de cristal) : injecté une fois
document.body.insertAdjacentHTML("afterbegin", `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
  <radialGradient id="ca-orb" cx=".35" cy=".35" r=".8"><stop offset="0" stop-color="#e9d8ff" stop-opacity=".9"/><stop offset=".5" stop-color="#b58cff" stop-opacity=".4"/><stop offset="1" stop-color="#3a1f73" stop-opacity=".2"/></radialGradient>
</defs></svg>`);

function charmArt(id){
  const art = CHARM_ART[id];
  const col = RARITY[CHARMS[id].rarity].color;
  if(!art) return `<div class="cart cart-emoji" aria-hidden="true">${CHARMS[id].ico}</div>`;
  return `<svg class="cart" viewBox="0 0 100 64" aria-hidden="true"><defs><radialGradient id="cbg-${id}" cx=".5" cy=".4" r=".8">
    <stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="#140608" stop-opacity="0"/></radialGradient></defs>
    <rect width="100" height="64" rx="6" fill="#140608"/><rect width="100" height="64" rx="6" fill="url(#cbg-${id})"/>${art}</svg>`;
}
