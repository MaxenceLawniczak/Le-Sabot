"use strict";
// Codex : une vitrine de tout le contenu du jeu, avec les effets de chaque élément.
// Tout est lu directement dans content.js : un charme ou une carte ajouté apparaît ici tout seul.

const CODEX_TABS = [
  {id:"cartes",    label:"Cartes"},
  {id:"decks",     label:"Decks"},
  {id:"bonus",     label:"Améliorations et éditions"},
  {id:"speciales", label:"Cartes spéciales"},
  {id:"charmes",   label:"Charmes"},
  {id:"patrons",   label:"Patrons"},
];
let codexTab = "cartes", codexRarity = "tous", codexBack = null;

// back : fonction appelée à la fermeture (retour au menu, ou simple fermeture en jeu)
function openCodex(back = null){
  if(back) codexBack = back;
  const tabs = CODEX_TABS.map(t => `<button class="ctab${t.id === codexTab ? " on" : ""}" role="tab" aria-selected="${t.id === codexTab}" data-tab="${t.id}">${t.label}</button>`).join("");
  openModal(`<div class="codex">
    <div class="chead"><h2>Codex</h2><button class="btn" id="codexClose">Fermer</button></div>
    <div class="ctabs" role="tablist">${tabs}</div>
    <div class="cbody" id="codexBody" role="tabpanel"></div></div>`, "codex");
  $("sheet").classList.add("wide");
  document.querySelectorAll(".ctab").forEach(b => b.onclick = () => { codexTab = b.dataset.tab; openCodex(); });
  $("codexClose").onclick = closeCodex;
  renderCodexBody();
  const on = document.querySelector(".ctab.on"); if(on) on.focus();
}
function closeCodex(){
  $("sheet").classList.remove("wide");
  const back = codexBack; codexBack = null;
  if(back) back(); else closeModal();
}

// Glisser-déposer : on attrape une vignette, elle suit le pointeur en s'inclinant selon la vitesse
// du geste, les autres s'écartent pour lui faire de la place, et elle se pose en douceur.
function makeSortable(container, selector){
  container.addEventListener("pointerdown", e => {
    const item = e.target.closest(selector);
    if(!item || item.parentElement !== container || e.button !== 0) return;
    e.preventDefault();
    const r0 = item.getBoundingClientRect();
    const offX = e.clientX - r0.left, offY = e.clientY - r0.top;
    let started = false, ph = null, lastX = e.clientX, vx = 0, raf = 0;
    const move = ev => {
      if(!started){
        if(Math.hypot(ev.clientX - e.clientX, ev.clientY - e.clientY) < 6) return;
        started = true;
        ph = document.createElement(item.tagName); ph.className = "sortph";
        ph.style.width = r0.width + "px"; ph.style.height = r0.height + "px";
        item.after(ph);
        Object.assign(item.style, {position:"fixed", left: r0.left + "px", top: r0.top + "px", width: r0.width + "px", zIndex: 1000, pointerEvents:"none", margin:0});
        item.classList.add("dragging");
        item.querySelectorAll(".card.tilt").forEach(c => c.classList.remove("tilt"));
      }
      vx = vx * .75 + (ev.clientX - lastX) * .25; lastX = ev.clientX;
      item.style.left = (ev.clientX - offX) + "px"; item.style.top = (ev.clientY - offY) + "px";
      item.style.rotate = Math.max(-20, Math.min(20, vx * 1.6)).toFixed(1) + "deg";
      const over = document.elementFromPoint(ev.clientX, ev.clientY)?.closest(selector);
      if(over && over !== item && over.parentElement === container){
        const orr = over.getBoundingClientRect();
        container.insertBefore(ph, ev.clientX < orr.left + orr.width / 2 ? over : over.nextSibling);
      }
      // l'inclinaison retombe quand le pointeur s'arrête
      cancelAnimationFrame(raf);
      const settle = () => { vx *= .8; item.style.rotate = (vx * 1.6).toFixed(1) + "deg"; if(Math.abs(vx) > .2) raf = requestAnimationFrame(settle); };
      raf = requestAnimationFrame(settle);
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
      if(!started) return;
      const pr = ph.getBoundingClientRect();
      item.style.transition = "left .22s cubic-bezier(.2,1.3,.4,1), top .22s cubic-bezier(.2,1.3,.4,1), rotate .22s";
      item.style.left = pr.left + "px"; item.style.top = pr.top + "px"; item.style.rotate = "0deg";
      setTimeout(() => {
        ph.replaceWith(item);
        item.removeAttribute("style"); item.classList.remove("dragging");
      }, 230);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up, {once:true});
    window.addEventListener("pointercancel", up, {once:true});
  });
}

// Une vignette : la carte (avec relief au survol) et sa légende
function codexItem(card, title, text){
  const w = document.createElement("figure"); w.className = "citem";
  w.appendChild(cardEl(card));
  w.insertAdjacentHTML("beforeend", `<figcaption><b>${title}</b>${text ? `<span>${text}</span>` : ""}</figcaption>`);
  return w;
}
function codexGrid(title, intro, items){
  const sec = document.createElement("section"); sec.className = "csec";
  sec.innerHTML = `<h3>${title}</h3>${intro ? `<p>${intro}</p>` : ""}<div class="cgrid"></div>`;
  const grid = sec.querySelector(".cgrid");
  items.forEach(it => grid.appendChild(it));
  makeSortable(grid, ".citem");
  return sec;
}
const fakeInst = (code, extra = {}) => ({uid: -1, code, enh:null, ed:null, sp:null, neg:false, ...extra});

function renderCodexBody(){
  const body = $("codexBody"); body.innerHTML = "";
  const add = el => body.appendChild(el);
  const valueOf = r => r === "A" ? "11, ou 1 si tu dépasses" : "0JQK".includes(r) ? "10" : r;

  if(codexTab === "cartes"){
    add(codexGrid("Les 13 rangs", "Chaque couleur compte 13 cartes. Les figures valent 10, l'As vaut 11 ou 1 selon ce qui t'arrange.",
      RANKS.map(r => codexItem(fakeInst(r + "S"), rankLabel(r) === "A" ? "As" : r === "J" ? "Valet (V)" : r === "Q" ? "Dame (D)" : r === "K" ? "Roi (R)" : rankLabel(r), `Vaut ${valueOf(r)}`))));
    add(codexGrid("Les 4 couleurs", "Les couleurs n'ont pas d'effet par elles-mêmes, mais certains charmes les récompensent et certains patrons en désactivent une.",
      SUITS.map(s => {
        const fans = Object.entries(CHARMS).filter(([, c]) => c.desc.includes(GLYPH[s])).map(([, c]) => c.name);
        const foes = BOSSES.filter(b => b.mod === "suit" && b.suit === s).map(b => b.name);
        const bits = [fans.length && `Aimée de : ${fans.join(", ")}`, foes.length && `Désactivée par : ${foes.join(", ")}`].filter(Boolean).join(". ");
        return codexItem(fakeInst("A" + s), `${SUITNAME[s]} ${GLYPH[s]}`, bits);
      })));
    add(codexGrid("Valeurs d'enseigne et enseignes de valeur",
      "Le jeu a les deux. Une <b>valeur d'enseigne</b>, comme le <b>4 de cœur</b>, est une carte classique : quatre cœurs, qui rapportent 4 <b>jetons</b>. Une <b>enseigne de valeur</b>, comme le <b>cœur de 4</b>, est un seul grand cœur formé de petits 4, dans un cadre couleur mult. Il compte pareil dans le total, mais sa valeur part dans le <b>mult</b> au lieu des jetons : +4 mult. Les enseignes de valeur vont de l'As (1 ou 11) au 10 et ne sont jamais négatives. On les trouve dans le paquet chiffré, le paquet standard et le paquet éclat, et les decks chiffré et double en sont remplis. Le Boulier et le Numérologue les adorent.",
      [["4H", false, "4 jetons"], ["4H", true, "+4 mult"], ["8C", false, "8 jetons"], ["8C", true, "+8 mult"], ["0S", true, "+10 mult"], ["AD", true, "+11 mult, ou +1"]].map(([code, num, t]) => {
        const c = fakeInst(code, {num});
        return codexItem(c, num ? numName(c) : `${rankLabel(rankOf(c))} de ${SUITNAME[suitOf(c)].toLowerCase()}`, t);
      })));
    add(codexGrid("Cartes négatives",
      "Fond de la couleur de l'enseigne, valeurs en blanc. Elles <b>retirent</b> leur valeur au total : un −2 de cœur retire 2, un As négatif retire 1, une figure négative retire 10. On en trouve dans le paquet standard et le paquet éclat, et le charme Contrepoids en crée.",
      [["2H","Retire 2"],["5D","Retire 5"],["9S","Retire 9"],["KC","Retire 10"],["AH","Retire 1"]].map(([code, t]) =>
        codexItem(fakeInst(code, {neg:true}), `${cardName(fakeInst(code, {neg:true}))}`, t))));
    add(codexGrid("Les Nothing",
      "Une cinquième famille sans couleur : de l'As au Roi, leurs enseignes sont de simples points noirs. Ils valent comme les cartes classiques, mais aucun charme de couleur ne les compte et aucun patron ne les désactive. Le charme Zen les adore. On les trouve surtout dans le paquet occulte, parfois dans le paquet standard.",
      RANKS.map(r => codexItem(fakeInst(r + NOTHING), rankLabel(r) + " Nothing", `Vaut ${valueOf(r)}`))));
  }

  if(codexTab === "decks"){
    const items = Object.entries(DECKS).map(([id, d]) => {
      const w = document.createElement("figure"); w.className = "citem";
      w.appendChild(cardEl({}, {hidden:true, back:id}));
      w.insertAdjacentHTML("beforeend", `<figcaption><b>${d.name}</b><span>${d.desc}</span></figcaption>`);
      return w;
    });
    add(codexGrid("Les decks", "Le deck se choisit avant chaque partie, depuis le menu. Il donne son dos à toutes tes cartes et, sauf le classique, un bonus pour toute la partie. En JcJ, tes adversaires voient ton dos de cartes.", items));
  }

  if(codexTab === "bonus"){
    add(codexGrid("Améliorations",
      "Elles transforment la carte elle-même : acier gravé, or, rubis sertis ou verre translucide. Elles s'obtiennent à l'Atelier (4 or) ou dans les paquets, et ne s'appliquent que dans une main gagnante.",
      Object.entries(ENH).map(([k, e]) => codexItem(fakeInst(k === "rouge" ? "QH" : k === "or" ? "KS" : "7S", {enh:k}), e.name, e.desc))));
    add(codexGrid("Éditions",
      "Un reflet animé en permanence, plus vif quand tu survoles la carte. Elles s'obtiennent chez le Vernisseur (6 or) ou dans les paquets, et se cumulent avec une amélioration.",
      Object.entries(EDS).map(([k, e]) => codexItem(fakeInst("QH", {ed:k}), e.name, e.desc))));
    add(codexGrid("Tout ensemble", "Une carte peut être négative, améliorée et brillante à la fois.",
      [codexItem(fakeInst("KD", {enh:"grave", ed:"holo"}), "R♦ gravé et holo", "+15 jetons et +6 mult"),
       codexItem(fakeInst("4C", {neg:true, ed:"poly"}), "−4♣ polychrome", "Retire 4 au total, ×1,5 mult"),
       codexItem(fakeInst("AS", {enh:"verre", ed:"foil"}), "A♠ de verre et foil", "×1,5 mult et +25 jetons, peut se briser")]));
  }

  if(codexTab === "speciales"){
    const plain = Object.entries(SPECIALS).filter(([, d]) => !d.nail);
    const valTxt = d => typeof d.val === "number" ? `Vaut ${d.val}` : d.val === "wild" ? "Valeur libre" : d.val === "die" ? "Vaut 1 à 6" : "Valeur copiée";
    add(codexGrid("Cartes spéciales",
      "Hors du jeu classique : elles s'obtiennent dans le paquet occulte (6 or). Elles n'ont pas de couleur, donc aucun patron ne les désactive. La pastille en haut à gauche rappelle leur valeur. Astuce : attrape les cartes pour les réorganiser comme tu veux.",
      plain.map(([id, d]) => codexItem(fakeInst("X1", {sp:id}), d.name, `${valTxt(d)}. ${d.desc.replace(/^Vaut \d+\.\s*/, "")}`))));
    add(codexGrid("Les Clous du cercueil",
      `Cinq clous différents, qui valent 2 chacun. Un clou encore dans ta main à la fin d'une main est planté. Plante les cinq à une même table et ton adversaire est enterré sur-le-champ (80 dégâts à chaque adversaire en JcJ). Garde-les dans ta manche en attendant d'avoir les autres. Le paquet occulte propose plus souvent ceux qui te manquent.`,
      [1,2,3,4,5].map(n => codexItem(fakeInst("X1", {sp:"clou" + n}), `Clou ${ROMAN[n]}`, "Vaut 2"))));
  }

  if(codexTab === "charmes"){
    const filters = [["tous", "Toutes"], ...Object.entries(RARITY).map(([k, r]) => [k, r.name])];
    const bar = document.createElement("div"); bar.className = "cfilters";
    bar.innerHTML = filters.map(([k, n]) => `<button class="cfilter${k === codexRarity ? " on" : ""}" data-r="${k}" ${k !== "tous" ? `style="--rc:${RARITY[k].color}"` : ""}>${n}</button>`).join("");
    bar.querySelectorAll("button").forEach(b => b.onclick = () => { codexRarity = b.dataset.r; renderCodexBody(); });
    add(bar);
    const intro = document.createElement("p"); intro.className = "cnote";
    intro.innerHTML = `Les charmes s'appliquent de gauche à droite. La rareté règle leur fréquence en boutique : ${Object.values(RARITY).map(r => `<b style="color:${r.color}">${r.name}</b> ${Math.round(r.weight / Object.values(RARITY).reduce((a, x) => a + x.weight, 0) * 100)} %`).join(", ")}. L'étiquette en haut à droite indique quand un charme se déclenche en dehors du calcul d'une main gagnante.`;
    add(intro);
    // Éditions de charme, illustrées avec le même charme
    const eds = document.createElement("section"); eds.className = "csec";
    eds.innerHTML = `<h3>Éditions de charme</h3><p>Un charme en boutique peut sortir avec une édition, qui coûte un peu plus cher. Son bonus s'ajoute au passage du charme, même s'il ne se déclenche pas. Le négatif n'occupe aucun emplacement.</p><div class="charms"></div>`;
    const ebox = eds.querySelector(".charms");
    for(const [k, e] of Object.entries(CHARM_EDS)){
      const d = document.createElement("div"); d.className = charmClass(k);
      d.innerHTML = charmTile("banquier", `<div class="price"><span class="gold">+${e.cost} or</span></div>`, k);
      ebox.appendChild(d);
    }
    makeSortable(ebox, ".charm");
    add(eds);
    for(const [rk, r] of Object.entries(RARITY)){
      if(codexRarity !== "tous" && codexRarity !== rk) continue;
      const ids = Object.keys(CHARMS).filter(id => CHARMS[id].rarity === rk).sort((a, b) => CHARMS[a].cost - CHARMS[b].cost || CHARMS[a].name.localeCompare(CHARMS[b].name));
      const sec = document.createElement("section"); sec.className = "csec";
      sec.innerHTML = `<h3 style="color:${r.color}">${r.name} (${ids.length})</h3><div class="charms"></div>`;
      const box = sec.querySelector(".charms");
      ids.forEach(id => {
        const d = document.createElement("div"); d.className = "charm";
        d.innerHTML = charmTile(id, `<div class="price"><span class="gold">${CHARMS[id].cost} or</span>${STARTERS.includes(id) ? `<span class="rar">Possible au départ</span>` : ""}</div>`);
        box.appendChild(d);
      });
      makeSortable(box, ".charm");
      add(sec);
    }
  }

  if(codexTab === "patrons"){
    const sec = document.createElement("section"); sec.className = "csec";
    const hp = TABLE_HP.map((h, i) => `${TABLE_NAME[i].toLowerCase()} ${h} PV`).join(", ");
    sec.innerHTML = `<h3>Les patrons</h3>
      <p>La troisième table de chaque ante est tenue par un patron qui change une règle, et le décor de la table avec lui, jamais le même deux fois dans une partie. À l'ante 1 : ${hp} ; les PV sont multipliés par ${ANTE_X[1]} à l'ante 2 et par ${String(ANTE_X[2]).replace(".", ",")} à l'ante 3.</p>
      <div class="bosses">${BOSSES.map(b => `<div class="cboss">
        <div class="mono">${(b.name.replace(/^(Le |La |L'|Madame |Monsieur )/, "")[0] || "?").toUpperCase()}</div>
        <div><b>${b.name}</b><p>${b.text}</p>${b.mod === "suit" ? `<span class="bsuit ${"HD".includes(b.suit) ? "red" : ""}">${GLYPH[b.suit]} désactivés</span>` : ""}</div></div>`).join("")}</div>`;
    add(sec);
    const foes = document.createElement("section"); foes.className = "csec";
    foes.innerHTML = `<h3>Les croupiers ordinaires</h3><p>Aux petites et grandes tables, sans règle spéciale : ${FOES.join(", ")}.</p>`;
    add(foes);
  }
}
