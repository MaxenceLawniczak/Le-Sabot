"use strict";
// JcJ en ligne, de 2 à 8 joueurs, via le relais WebSocket du Worker.
// À chaque manche, tout le monde joue en même temps. Chaque main est comparée à la
// meilleure main de chaque adversaire : si elle la bat, elle lui inflige jetons × mult.
// Boutique toutes les SET_ROUNDS manches ; le dernier joueur debout gagne.

const MAX_PLAYERS = 8;
const NET = {ws:null, me:null, name:"", code:"", roster:[], players:[], inbox:{}, gathers:[], closing:false, inMatch:false};

/* ---------- relais ---------- */
let relayAvailable = null;
async function hasRelay(){
  if(relayAvailable !== null) return relayAvailable;
  if(!location.protocol.startsWith("http")) return relayAvailable = false;
  try{
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 3000);
    const r = await fetch("/relay/ping", {signal: ctl.signal, cache: "no-store"});
    clearTimeout(t);
    relayAvailable = r.ok && (await r.text()).trim() === "ok";
  }catch(e){ relayAvailable = false; }
  return relayAvailable;
}
const RELAY_ERRORS = {4001:"Ce code est déjà pris, réessaie.", 4003:`Ce salon est complet (${MAX_PLAYERS} joueurs).`, 4004:"Aucun salon avec ce code.", 4005:"La partie de ce salon a déjà commencé."};
const newCode = () => Array.from({length:5}, () => "ABCDEFGHJKMNPQRSTUVWXYZ"[rnd(23)]).join("");

function netSend(type, data = {}){ if(NET.ws && NET.ws.readyState === 1) NET.ws.send(JSON.stringify({type, ...data})); }
function netClose(){
  NET.closing = true;
  try{ NET.ws && NET.ws.close(1000); }catch(e){}
  Object.assign(NET, {ws:null, me:null, roster:[], players:[], inbox:{}, gathers:[], inMatch:false});
  setTimeout(() => NET.closing = false, 0);
}
function connect(code, role){
  netClose();
  NET.code = code;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/relay/${code}?role=${role}&name=${encodeURIComponent(NET.name)}`);
  NET.ws = ws;
  let opened = false;
  ws.onmessage = e => { let m; try{ m = JSON.parse(e.data); }catch(err){ return; } if(m.type === "_welcome") opened = true; onNet(m); };
  ws.onclose = e => {
    if(NET.ws !== ws || NET.closing) return;
    if(!opened){ status(RELAY_ERRORS[e.code] || "Relais injoignable."); NET.ws = null; return; }
    NET.ws = null; lostConnection();
  };
}

/* ---------- réception et attente de plusieurs joueurs ---------- */
function onNet(m){
  if(!m || typeof m !== "object") return;
  switch(m.type){
    case "_welcome": NET.me = m.id; return;
    case "_roster":
      NET.roster = m.players || [];
      if(m.left) playerLeft(m.left);
      if(!NET.inMatch) showRoom();
      return;
    case "_start": startMatch(m.players || []); return;
    case "_lobby": NET.roster = m.players || NET.roster; NET.inMatch = false; MODE = "duel"; showRoom(); return;
    case "state": {
      const o = O && O[m.from]; if(!o) return;
      Object.assign(o, {hp: +m.hp, maxHp: +m.maxHp, deck: DECKS[m.deck] ? m.deck : "classique",
        charms: (m.charms || []).map(c => typeof c === "string" ? {id:c, ed:null} : {id: c && c.id, ed: CHARM_EDS[c && c.ed] ? c.ed : null}).filter(c => CHARMS[c.id])});
      // Spectateur (déjà éliminé) : on suit les éliminations grâce aux PV annoncés
      if(S && S.hp <= 0 && o.hp <= 0 && !o.out){ o.out = true; o.place = others().length + 1; }
      renderFoe(); if(modalKind === "out") showStandings(false);
      return;
    }
    case "live": { const o = O && O[m.from]; if(o){ o.live = sanitizeHands(m.hands); if(H && H.phase !== "done") renderHands(); } return; }
  }
  deliver(m.type === "sync" ? "sync:" + m.tag : m.type, m.from, m);
}
// gather(clé, joueurs) : attend un message de chacun des joueurs indiqués.
function gather(key, ids){
  return new Promise(res => {
    const g = {key, need: new Set(ids), got: new Map(), res};
    for(const id of [...g.need]){
      const q = NET.inbox[key + ":" + id];
      if(q && q.length){ g.got.set(id, q.shift()); g.need.delete(id); }
    }
    NET.gathers.push(g); checkGathers();
  });
}
function deliver(key, from, msg){
  const g = NET.gathers.find(x => x.key === key && x.need.has(from));
  if(g){ g.got.set(from, msg); g.need.delete(from); checkGathers(); }
  else (NET.inbox[key + ":" + from] ||= []).push(msg);
}
function checkGathers(){ NET.gathers = NET.gathers.filter(g => { if(g.need.size) return true; g.res(g.got); return false; }); }
const others = () => NET.players.filter(id => id !== NET.me && O[id] && !O[id].out);
async function sync(tag){ netSend("sync", {tag}); await gather("sync:" + tag, others()); }
function sendState(){ if(MODE === "duel" && NET.inMatch) netSend("state", {hp: S.hp, maxHp: S.maxHp, deck: S.deckId, charms: S.charms.map(c => ({id: c.id, ed: c.ed || null}))}); }
function sendLive(){ if(MODE === "duel" && NET.inMatch) netSend("live", {hands: H.hands.map(h => ({cards: h.cards.map(pub), state: h.state, lim: limit()}))}); }

const validCode = c => typeof c === "string" && /^([A2-9JQK0][SHDCN]|X1)$/.test(c);
function sanitizeHands(hands){
  return (Array.isArray(hands) ? hands : []).slice(0, 2).map(h => ({
    cards: (h.cards || []).filter(c => validCode(c.code) && (c.code !== "X1" || SPECIALS[c.sp])).slice(0, 12)
      .map(c => ({code:c.code, enh: ENH[c.enh] ? c.enh : null, ed: EDS[c.ed] ? c.ed : null, sp: c.code === "X1" ? c.sp : null, neg: c.code !== "X1" && !!c.neg})),
    state: String(h.state || ""), doubled: !!h.doubled, lim: h.lim === 22 ? 22 : 21, natural: !!h.natural,
  }));
}

/* ---------- salon ---------- */
function status(t){ const s = $("netStatus"); if(s) s.textContent = t; }
function duelLobby(){
  let saved = ""; try{ saved = localStorage.getItem("sabot:name") || ""; }catch(e){}
  openModal(`<h2>JcJ en ligne</h2>
    <p>De 2 à ${MAX_PLAYERS} joueurs, chacun son deck et ses charmes. À chaque manche, tout le monde joue en même temps : chaque main qui bat la meilleure main d'un adversaire lui inflige ses jetons × mult. Boutique toutes les ${SET_ROUNDS} manches. Le dernier debout gagne.</p>
    <label class="field">Ton pseudo<input id="pseudo" maxlength="20" value="${esc(saved)}" placeholder="Maxence"></label>
    <div class="bar"><button class="btn main" id="host">Créer un salon</button></div>
    <label class="field">Ou le code d'un ami<input id="joinCode" maxlength="5" placeholder="ABCDE" autocapitalize="characters"></label>
    <div class="bar"><button class="btn" id="join">Rejoindre</button><button class="btn" id="back">Retour</button></div>
    <p class="status" id="netStatus"></p>`);
  const name = () => { const n = $("pseudo").value.trim().slice(0, 20) || "Joueur"; try{ localStorage.setItem("sabot:name", n); }catch(e){} return n; };
  $("back").onclick = titleScreen;
  const go = async (role, code) => {
    if(!(await hasRelay())){
      status("Le JcJ passe par le relais du Worker : lance le jeu avec « npx wrangler dev » ou ouvre la version en ligne.");
      return;
    }
    if(!/^[A-Z]{5}$/.test(code)){ status("Le code fait 5 lettres."); return; }
    NET.name = name(); status("Connexion…");
    MODE = "duel";
    connect(code, role);
  };
  $("host").onclick = () => go("host", newCode());
  $("join").onclick = () => go("guest", $("joinCode").value.trim().toUpperCase());
}
const isHost = () => NET.roster.length && NET.roster[0].id === NET.me;
function showRoom(){
  if(!NET.me) return;
  const list = NET.roster.map((p, i) => `<li>${esc(p.name)}${i === 0 ? " <span class=\"tag\">hôte</span>" : ""}${p.id === NET.me ? " <span class=\"tag win\">toi</span>" : ""}</li>`).join("");
  openModal(`<h2>Salon</h2><p>Code à partager :</p><p class="code">${NET.code}</p>
    <h3>Joueurs (${NET.roster.length}/${MAX_PLAYERS})</h3><ul class="roster">${list}</ul>
    <p class="status" id="netStatus">${isHost() ? (NET.roster.length < 2 ? "Il faut au moins un autre joueur." : "Lance la partie quand tout le monde est là.") : "En attente que l'hôte lance la partie…"}</p>
    <div class="bar">${isHost() ? `<button class="btn main" id="launch" ${NET.roster.length < 2 ? "disabled" : ""}>Lancer la partie</button>` : ""}<button class="btn" id="quit">Quitter le salon</button></div>`, "room");
  if($("launch")) $("launch").onclick = () => { $("launch").disabled = true; netSend("_start"); };
  $("quit").onclick = () => { netClose(); titleScreen(); };
}
function lostConnection(){
  NET.inMatch = false;
  openModal(`<h2>Connexion perdue</h2><p>La connexion au salon a été coupée.</p>
    <div class="bar"><button class="btn main" id="toMenu">Retour au menu</button></div>`);
  $("toMenu").onclick = () => { netClose(); titleScreen(); };
}
function playerLeft(id){
  if(!NET.inMatch || !O || !O[id]) return;
  const o = O[id];
  // Un joueur qui part abandonne : il prend la place derrière ceux encore en jeu.
  if(!o.out){ o.out = true; o.place = others().length + (S.hp > 0 ? 1 : 0) + 1; }
  o.gone = true;
  NET.gathers.forEach(g => g.need.delete(id)); checkGathers();
  $("steps").textContent = `${o.name} a quitté la partie.`;
  renderFoe(); renderHands();
  // S'il ne reste plus que toi en jeu, la partie s'arrête là.
  if(S.hp > 0 && !others().length && !["end"].includes(modalKind)){ busy = false; H.phase = "over"; renderActions(); showStandings(); }
  else if(modalKind === "out") showStandings();
}

/* ---------- partie ---------- */
function startMatch(players){
  MODE = "duel"; NET.inMatch = true;
  NET.players = players.map(p => p.id);
  O = {};
  for(const p of players) if(p.id !== NET.me) O[p.id] = {name: p.name, hp:DUEL_HP, maxHp:DUEL_HP, charms:[], live:null, out:false, place:null};
  newRun(); shoe = null; S.name = NET.name;
  T = {foe:null, burns:0, wins:0, round:0, netUsed:false, nails:new Set(), coffin:false, cpUsed:false};
  H = {hands:[], cur:0, d:[], phase:"over"};
  refreshAll();
  const n = players.length - 1;
  const go = async () => {
    closeModal(); sendState();
    setMsg("En attente des autres joueurs…");
    await sync("start");
    sendState();
    await duelStartSet();
  };
  showGame();
  if(deckDef().noStarter) go();
  else starterPick(`${n} adversaire${n > 1 ? "s" : ""} : ${players.filter(p => p.id !== NET.me).map(p => esc(p.name)).join(", ")}. Choisis ton premier charme.`, go);
}
async function duelStartSet(){
  T.burns = 1 + (has("allumette") ? 1 : 0) + (deckDef().burns || 0); T.netUsed = false; T.wins = 0; T.nails = new Set(); T.coffin = false; T.cpUsed = false;
  H = {hands:[], cur:0, d:[], phase:"idle"};
  busy = true; refreshAll(); setMsg("Mélange de ton sabot…");
  await openShoe();
  busy = false;
  setMsg(`Manche ${T.round + 1}. Clique sur « Je suis prêt ».`);
  refreshAll();
}
async function duelDeal(){
  busy = true;
  H = {hands:[], cur:0, d:[], phase:"wait"};
  for(const o of Object.values(O)) o.live = null;
  setBoxes(0, 0, 0); $("steps").textContent = ""; setMsg("En attente des autres joueurs…");
  refreshAll();
  await sync("round" + T.round);
  try{
    if(shoe.left() < 12) shoe.reshuffle();
    H = {hands:[newHand()], cur:0, d:[], phase:"deal"};
    setMsg("");
    const cs = await draw(2);
    for(const c of cs){ H.hands[0].cards.push(c); renderHands(); await wait(170); }
    sendLive();
    H.phase = "player"; renderHands();
    if(isNatural(H.hands[0])){ setMsg("Blackjack !", "good"); H.hands[0].state = "stand"; busy = false; await duelSubmit(); return; }
  } finally { busy = false; if(H.phase === "player") renderHands(); renderActions(); renderPeek(); }
}
const handValue = h => h.natural ? 21.5 : handTotal(h.cards, h.lim);
async function duelSubmit(){
  H.phase = "wait"; busy = true; renderActions(); $("peek").hidden = true;
  sendLive();
  setMsg("Tes mains sont jouées. En attente des autres joueurs…");
  netSend("hand", {hands: H.hands.map(h => ({cards: h.cards.map(pub), state: h.state, doubled: h.doubled, lim: limit(), natural: isNatural(h)}))});
  const got = await gather("hand", others());
  H.opp = {};
  const ref = {}, bust = {};
  for(const [id, msg] of got){
    H.opp[id] = sanitizeHands(msg.hands);
    const alive = H.opp[id].filter(h => h.state === "stand");
    bust[id] = !alive.length;
    ref[id] = bust[id] ? 0 : Math.max(...alive.map(handValue));
  }
  const opps = [...got.keys()];
  H.phase = "done"; renderHands();

  const out = Object.fromEntries(opps.map(id => [id, 0]));
  let selfDmg = 0; const log = [];
  if(await plantNails()){
    opps.forEach(id => out[id] += 80);
    log.push("Le cercueil se referme : 80 dégâts à chacun"); setMsg("Le cercueil se referme !", "good"); await wait(900);
  }
  for(let i = 0; i < H.hands.length; i++){
    const h = H.hands[i]; H.cur = i;
    const lab = H.hands.length > 1 ? `Main ${i + 1} : ` : "";
    const mine = isNatural(h) ? 21.5 : hTotal(h);
    const beats = [], losesTo = [];
    if(h.state === "bust"){ for(const id of opps) if(!bust[id]) losesTo.push(id); }
    else if(h.state !== "saved"){
      for(const id of opps){ if(bust[id] || mine > ref[id]) beats.push(id); else if(mine < ref[id]) losesTo.push(id); }
    }
    h.result = beats.length ? "win" : losesTo.length ? "lose" : "push";
    renderHands();
    const names = ids => ids.map(id => O[id].name).join(", ");
    if(beats.length){
      setMsg(lab + `tu bats ${names(beats)}.`, "good");
      const anyBust = beats.some(id => bust[id]);
      const s = scoreHand(h, {foeBust: anyBust});
      await animateScore(s, h);
      // Rapace ne double que contre les adversaires qui ont sauté
      const plain = anyBust && has("rapace") && beats.some(id => !bust[id]) ? scoreHand({...h}, {foeBust:false}).dmg : s.dmg;
      for(const id of beats) out[id] += bust[id] ? s.dmg : plain;
      const extra = winExtras(h, s);
      log.push(`${lab}${s.dmg} dégâts à ${names(beats)}` + (extra.length ? " (" + extra.join(", ") + ")" : ""));
    } else if(losesTo.length){
      setMsg(lab + (h.state === "bust" ? "sautée." : `battue par ${names(losesTo)}.`), "bad");
      fire("onLose", h);
      if(h.doubled){ selfDmg += 8; log.push("main doublée perdue : 8 PV"); }
    } else {
      setMsg(lab + "égalité."); fire("onPush");
    }
    if(h.kami){ opps.forEach(id => out[id] += h.kami); log.push(`Kamikaze : ${h.kami} dégâts à chacun`); }
    renderHud(); await wait(450);
  }
  netSend("dmg", {to: out});
  const dmgs = await gather("dmg", others());
  let incoming = 0; const hitBy = [];
  for(const [id, msg] of dmgs){
    let a = Math.max(0, Math.round(+(msg.to && msg.to[NET.me]) || 0));
    if(a > 0 && has("carapace")){ a = Math.max(1, a - 3); flash("carapace"); }
    if(a > 0) hitBy.push(`${O[id].name} ${a}`);
    incoming += a;
  }
  const dealt = Object.values(out).reduce((a, b) => a + b, 0);
  S.hp -= incoming + selfDmg;
  S.gold += dealt > 0 ? 3 : 1;
  setBoxes(0, 0, dealt);
  setMsg(`Tu infliges ${dealt} dégâts et tu en subis ${incoming + selfDmg}.`, dealt >= incoming + selfDmg ? "good" : "bad");
  $("steps").textContent = [...log, hitBy.length ? "Reçu : " + hitBy.join(", ") : ""].filter(Boolean).join(" · ");
  renderHud(); sendState();

  netSend("end", {hp: S.hp});
  const ends = await gather("end", others());
  for(const [id, msg] of ends) O[id].hp = +msg.hp;
  T.round++;
  // éliminations de la manche : même place pour ceux qui tombent ensemble
  const fallen = [...ends.keys()].filter(id => O[id].hp <= 0);
  const meFallen = S.hp <= 0;
  const stillIn = others().filter(id => !fallen.includes(id)).length + (meFallen ? 0 : 1);
  for(const id of fallen){ O[id].out = true; O[id].place = stillIn + 1; }
  if(meFallen) S.place = stillIn + 1;
  renderFoe();
  busy = false;
  if(meFallen || stillIn <= 1){ H.phase = "over"; renderActions(); await wait(900); showStandings(true); return; }
  const shopDue = T.round % SET_ROUNDS === 0;
  H.phase = shopDue ? "over" : "done"; renderActions(); renderHud();
  if(shopDue){
    await wait(900);
    S.gold += Math.min(5, Math.floor(S.gold / 5));
    openShop(true);
  }
}
async function duelLeaveShop(){
  closeModal(); busy = true; renderActions();
  setMsg("En attente des joueurs encore en boutique…");
  sendState();
  await sync("shop" + T.round);
  busy = false;
  await duelStartSet();
}
// Classement : les éliminés par place, les survivants par PV restants.
function showStandings(){
  const rows = [{name: NET.name + " (toi)", hp: S.hp, out: S.hp <= 0, place: S.hp > 0 ? null : S.place},
    ...Object.values(O).map(o => ({name: o.name + (o.gone ? " (parti)" : ""), hp: o.hp, out: o.out, place: o.out ? o.place : null}))];
  const alive = rows.filter(r => !r.out);
  const over = alive.length <= 1;
  if(over) alive.forEach(r => r.place = 1);
  rows.sort((a, b) => (a.place ?? 0) - (b.place ?? 0) || b.hp - a.hp);
  const me = rows.find(r => r.name.endsWith("(toi)"));
  const title = !over ? "Éliminé" : me.place === 1 ? "Victoire" : `${me.place}e place`;
  const text = !over ? `Tu termines au mieux ${me.place}e. La partie continue entre ${alive.map(r => esc(r.name)).join(", ")}.`
    : me.place === 1 ? `Dernier debout après ${T.round} manche${T.round > 1 ? "s" : ""}.` : `${esc(rows[0].name)} remporte la partie en ${T.round} manche${T.round > 1 ? "s" : ""}.`;
  const list = rows.map(r => `<tr><td>${r.place ? r.place + "." : "·"}</td><td>${esc(r.name)}</td><td>${Math.max(0, r.hp)} PV</td></tr>`).join("");
  openModal(`<h2>${title}</h2><p>${text}</p><table class="ledger standings">${list}</table>
    <div class="bar">${isHost() ? `<button class="btn main" id="relobby">Retour au salon</button>` : ""}<button class="btn" id="toMenu">Quitter</button></div>
    <p class="status">${isHost() ? "Le salon se rouvre pour tout le monde, et d'autres joueurs peuvent le rejoindre." : "L'hôte peut ramener tout le monde au salon pour une nouvelle partie."}</p>`, over ? "end" : "out");
  if($("relobby")) $("relobby").onclick = () => netSend("_lobby");
  $("toMenu").onclick = () => { netClose(); titleScreen(); };
}
