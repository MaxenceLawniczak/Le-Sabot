"use strict";
// Affichage : cartes (relief 3D), HUD, adversaire, mains, manche, charmes, boutons.

/* ======================================================================
   Rendu
   ====================================================================== */
const $ = id => document.getElementById(id);
const reduced = () => SETTINGS.calm || matchMedia("(prefers-reduced-motion: reduce)").matches;
const shownKeys = new Set();
function addTilt(el){
  if(reduced()) return;
  el.addEventListener("pointermove", e => {
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
    el.style.setProperty("--rx", ((0.5 - y) * 24).toFixed(1) + "deg");
    el.style.setProperty("--ry", ((x - 0.5) * 28).toFixed(1) + "deg");
    el.style.setProperty("--mx", (x * 100).toFixed(0) + "%");
    el.style.setProperty("--my", (y * 100).toFixed(0) + "%");
    el.classList.add("tilt");
  });
  el.addEventListener("pointerleave", () => {
    el.classList.remove("tilt");
    for(const p of ["--rx","--ry","--mx","--my"]) el.style.removeProperty(p);
  });
}
function cardLabel(c){
  if(isSp(c)) return `${SPECIALS[c.sp].name} : ${SPECIALS[c.sp].desc}`;
  const r = rankOf(c), s = suitOf(c);
  const v = c.neg ? `, carte négative (${pts(c)})` : "";
  const bits = [c.enh && ENH[c.enh].name, c.ed && EDS[c.ed].name].filter(Boolean).join(", ");
  return `${rankLabel(r)} de ${SUITNAME[s]}${v}${bits ? " (" + bits + ")" : ""}`;
}
function cardEl(c, {hidden = false, small = false, key = null, back = null} = {}){
  const el = document.createElement("div");
  const k = key || c.key;
  if(hidden){
    el.className = "card back";
    el.innerHTML = backSVG(back || (S && S.deckId) || SETTINGS.deck); // dos du deck de celui qui tient la carte
    el.setAttribute("role", "img"); el.setAttribute("aria-label", "Carte face cachée");
  } else {
    el.className = "card" + (isSp(c) ? " special" : "") + (c.neg ? " neg" : "") + (c.ed ? " " + c.ed : "") + (c.enh ? " enh-" + c.enh : "");
    el.style.setProperty("--d", (-Math.random() * 4).toFixed(2) + "s");
    el.innerHTML = cardSVG(c);
    el.setAttribute("role", "img"); el.setAttribute("aria-label", cardLabel(c)); el.title = cardLabel(c);
    if(!small){
      if(c.ed) el.insertAdjacentHTML("beforeend", `<div class="ed">${EDS[c.ed].short || EDS[c.ed].name}</div>`);
    }
    addTilt(el);
  }
  if(k) el.dataset.key = k;
  if(k && !shownKeys.has(k)){ el.classList.add("deal"); shownKeys.add(k); }
  return el;
}
function renderHud(){
  const pips = $("pips"); pips.innerHTML = "";
  if(MODE === "duel"){
    $("stageLabel").textContent = `JcJ, manche ${T ? T.round + 1 : 1} (boutique toutes les ${SET_ROUNDS})`;
    for(let i = 0; i < SET_ROUNDS; i++){
      const p = document.createElement("span"); const r = T ? T.round % SET_ROUNDS : 0;
      p.className = "pip" + (i < r ? " done" : i === r ? " now" : ""); pips.appendChild(p);
    }
  } else {
    $("stageLabel").textContent = `Ante ${S.ante} sur 3`;
    for(let i = 0; i < 3; i++){
      const p = document.createElement("span");
      p.className = "pip" + (i === 2 ? " boss" : "") + (i < S.table ? " done" : i === S.table ? " now" : "");
      p.title = TABLE_NAME[i]; pips.appendChild(p);
    }
  }
  $("hpN").textContent = `${Math.max(0, S.hp)}/${S.maxHp}`;
  $("hpbar").querySelector("i").style.width = Math.max(0, S.hp / S.maxHp * 100) + "%";
  $("hpbar").classList.toggle("low", S.hp <= S.maxHp * .3);
  $("goldN").textContent = S.gold;
  $("shoeN").textContent = shoe ? `${shoe.left()}/${S.deck.length}` : S.deck.length;
}
// Décor de la table : chaque patron a le sien (styles.css, body[data-theme])
function setTheme(t){ if(t) document.body.dataset.theme = t; else delete document.body.dataset.theme; }
function renderFoe(){
  const el = $("foe");
  const initial = n => (n.replace(/^(Le |La |L'|Madame |Monsieur )/, "")[0] || "?").toUpperCase();
  if(MODE === "duel"){
    // Liste de tous les adversaires, éliminés compris (grisés)
    const ids = (NET.players || []).filter(id => id !== NET.me && O && O[id]);
    const charm = ({id, ed}) => `<span class="${ed ? "ed-" + ed : ""}" title="${CHARMS[id].name} (${RARITY[CHARMS[id].rarity].name}${ed ? ", " + CHARM_EDS[ed].name : ""}) : ${esc(CHARMS[id].desc.replace("{n}", "?").replace("{x}", "?"))}" style="border-color:${RARITY[CHARMS[id].rarity].color}">${charmArt(id)}</span>`;
    setTheme("");
    el.className = "foe rival multi";
    el.innerHTML = `<div class="kind">Adversaires : ${ids.filter(id => !O[id].out).length} en jeu</div>` + ids.map(id => {
      const o = O[id];
      return `<div class="opp${o.out ? " out" : ""}"><div class="mono sm">${esc(initial(o.name))}</div><div class="oinfo">
        <b>${esc(o.name)}</b> ${o.out ? `<span class="tag lose">${o.gone ? "parti" : "éliminé"}</span>` : ""}
        <div class="hpbar"><i style="width:${Math.max(0, o.hp / o.maxHp * 100)}%"></i></div>
        <small>${Math.max(0, o.hp)} / ${o.maxHp} PV</small>
        <div class="ocharms">${(o.charms || []).map(c => typeof c === "string" ? {id:c} : c).filter(c => CHARMS[c.id]).map(charm).join("")}</div></div></div>`;
    }).join("");
    return;
  }
  const f = T.foe;
  el.className = "foe" + (S.table === 2 ? " boss" : "");
  setTheme(S.table === 2 && f.mod ? BOSS_THEME(f) : "");
  el.innerHTML = `<div class="mono">${initial(f.name)}</div>
    <div class="info"><h2>${f.name}</h2><div class="kind">${TABLE_NAME[S.table]}</div></div>
    ${f.text ? `<div class="mod">${f.text}</div>` : ""}
    <div class="hpwrap"><div class="hpbar"><i style="width:${Math.max(0, f.hp / f.maxHp * 100)}%"></i></div>
    <div class="hpnum">${Math.max(0, f.hp)} / ${f.maxHp} PV</div></div>`;
}
const esc = s => String(s).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[ch]);

function handBlock(h, i, multi, {active, hideFirst = false, hideRest = false, keyPrefix = null, lim = limit(), pickable = false, mine = false, back = null}){
  const b = document.createElement("div");
  b.className = "hblock" + (active ? " active" : "");
  const t = handTotal(h.cards, lim);
  let totalTxt;
  if(!h.cards.length) totalTxt = "";
  else if(hideRest) totalTxt = pts(h.cards[0]) + " + ?";
  else if(hideFirst) totalTxt = "? + " + handTotal(h.cards.slice(1), lim);
  else totalTxt = t;
  const tags = [];
  if(h.doubled) tags.push(`<span class="tag">doublée</span>`);
  if(h.state === "saved") tags.push(`<span class="tag">rattrapée</span>`);
  if(h.result === "win") tags.push(`<span class="tag win">gagnée</span>`);
  if(h.result === "lose") tags.push(`<span class="tag lose">perdue</span>`);
  if(h.result === "push") tags.push(`<span class="tag">égalité</span>`);
  const bust = !hideRest && !hideFirst && t > lim;
  b.innerHTML = `<div class="hhead">${multi ? `Main ${i + 1}` : "Total"} <b class="${bust ? "bust" : ""}">${totalTxt}</b> ${tags.join(" ")}</div><div class="hand"></div>`;
  const row = b.querySelector(".hand");
  h.cards.forEach((c, j) => {
    const hidden = (j === 0 && hideFirst) || (j > 0 && hideRest);
    const el = cardEl(c, {hidden, key: keyPrefix ? `${keyPrefix}-${i}-${j}` : null, back});
    if(c.fromSleeve) el.classList.add("fromsleeve");
    if(mine && !hidden && disabled(c)){ el.classList.add("off"); el.title = "Désactivée par le patron : " + el.title; }
    if(pickable && !hidden){
      el.classList.add("pick"); el.tabIndex = 0; el.setAttribute("role", "button");
      if(H.sel === j) el.classList.add("sel");
      el.title = "Choisir cette carte pour la cacher dans ta manche";
      const go = () => { H.sel = H.sel === j ? null : j; renderHands(); renderActions(); };
      el.onclick = go; el.onkeydown = e => { if(e.key === "Enter"){ e.preventDefault(); go(); } };
    }
    row.appendChild(el);
  });
  return b;
}
function renderHands(){
  const reveal = H.phase === "dealer" || H.phase === "done" || H.phase === "over";
  const dh = $("dHands"); dh.innerHTML = "";
  if(MODE === "duel"){
    $("dLabel").textContent = "Adversaires";
    dh.classList.add("opps");
    for(const id of (NET.players || []).filter(id => id !== NET.me && O && O[id] && !O[id].out)){
      const o = O[id];
      const done = reveal && H.opp && H.opp[id];
      const hands = done ? H.opp[id] : (o.live || []);
      const see = done ? true : has("voyeur");
      const wrap = document.createElement("div"); wrap.className = "oppblock";
      wrap.innerHTML = `<div class="oname">${esc(o.name)}</div>`;
      const row = document.createElement("div"); row.className = "hands";
      if(!hands.length) row.innerHTML = `<span class="owait">en attente…</span>`;
      hands.forEach((h, i) => row.appendChild(handBlock(h, i, hands.length > 1, {active:false, hideRest: !see, keyPrefix: "o" + id, lim: h.lim || 21, back: o.deck})));
      wrap.appendChild(row); dh.appendChild(wrap);
    }
    $("dTot").textContent = "";
  } else {
    $("dLabel").textContent = "Croupier"; dh.classList.remove("opps");
    if(H.d.length){
      const hide = !reveal && !has("voyeur");
      dh.appendChild(handBlock({cards:H.d, state:""}, 0, false, {active:false, hideRest: false, lim:21}));
      if(hide){
        const cards = dh.querySelectorAll(".card");
        if(cards[1]){ const back = cardEl(H.d[1], {hidden:true}); cards[1].replaceWith(back); }
        dh.querySelector(".hhead b").textContent = pts(H.d[0]) + " + ?";
      }
    }
    $("dTot").textContent = "";
  }
  const ph = $("pHands"); ph.innerHTML = "";
  const multi = H.hands.length > 1;
  const canPick = H.phase === "player" && !busy && canHide();
  H.hands.forEach((h, i) => ph.appendChild(handBlock(h, i, multi, {
    active: multi && H.phase === "player" && i === H.cur,
    hideFirst: MODE === "solo" && i === 0 && T.foe && T.foe.mod === "brume" && !reveal,
    pickable: canPick && i === H.cur, mine: true,
  })));
  renderSleeve(); renderNails();
  renderHud();
}
function renderSleeve(){
  const box = $("sleeve"); if(!box) return;
  const can = canResurface();
  box.innerHTML = `<span class="slabel">Ta manche (${S.sleeve.length}/${sleeveCap()})${sleeveLocked() ? ", fouillée à cette table" : ""}</span>`;
  if(!S.sleeve.length) box.insertAdjacentHTML("beforeend", `<span class="sempty">Vide. Sélectionne une carte de ta main puis « Cacher ».</span>`);
  S.sleeve.forEach((c, i) => {
    const wrap = document.createElement("div"); wrap.className = "sitem";
    wrap.appendChild(cardEl(c));
    const b = document.createElement("button"); b.className = "linkbtn"; b.textContent = "Ressortir";
    b.disabled = !can; b.onclick = () => resurface(i);
    wrap.appendChild(b); box.appendChild(wrap);
  });
}
function renderNails(){
  const el = $("nails"); if(!el) return;
  const owned = new Set([...S.deck, ...S.sleeve].filter(c => isSp(c) && SPECIALS[c.sp].nail).map(c => SPECIALS[c.sp].nail));
  if(!owned.size){ el.textContent = ""; return; }
  const planted = T && T.nails ? T.nails : new Set();
  el.innerHTML = "Cercueil : " + [1,2,3,4,5].map(n => `<span class="${planted.has(n) ? "on" : owned.has(n) ? "own" : ""}" title="Clou ${ROMAN[n]}${planted.has(n) ? " planté" : owned.has(n) ? " dans ton deck" : " manquant"}">${ROMAN[n]}</span>`).join("");
}
function charmDesc(c){
  const st = S.charms.find(x => x.id === c) || {n:0};
  return CHARMS[c].desc.replace("{n}", st.n).replace("{x}", (1 + st.n / 4).toLocaleString("fr-FR"));
}
// Tuile de charme : illustration, rareté, déclencheur, édition éventuelle, effet.
// La classe « ed-… » (reflet ou inversion) se pose sur le conteneur via charmClass().
function charmTile(id, extra = "", ed = null){
  const c = CHARMS[id];
  const r = RARITY[c.rarity];
  return `<span class="rarbar" style="background:${r.color}" aria-hidden="true"></span>` +
    `${c.trig ? `<span class="trig">${c.trig}</span>` : ""}${charmArt(id)}` +
    `${ed ? `<span class="ced">${CHARM_EDS[ed].name} · ${CHARM_EDS[ed].desc}</span>` : ""}` +
    `<span class="rar-label" style="color:${r.color}">${r.name}</span><b>${c.name}</b><p>${charmDesc(id)}</p>${extra}`;
}
const charmClass = ed => "charm" + (ed ? " ed-" + ed : "");
function renderCharms(){
  const box = $("charms"); box.innerHTML = "";
  S.charms.forEach(({id, ed}) => {
    const d = document.createElement("div"); d.className = charmClass(ed); d.dataset.id = id; d.tabIndex = 0;
    d.innerHTML = charmTile(id, "", ed); box.appendChild(d);
  });
  for(let i = slotsUsed(); i < charmSlots(); i++){ const d = document.createElement("div"); d.className = "charm empty"; d.textContent = "Emplacement libre"; box.appendChild(d); }
  $("charmCount").textContent = `${slotsUsed()}/${charmSlots()}`;
  renderBurger();
}
function canSplit(){
  const h = cur();
  if(!h || H.hands.length !== 1 || h.cards.length !== 2 || h.burned) return false;
  if(MODE === "solo" && T.foe.mod === "bavure") return false;
  return has("scission") || pts(h.cards[0]) === pts(h.cards[1]);
}
function canHide(){
  const h = cur();
  return !!h && h.state === "play" && h.cards.length >= 2 && !H.hidUsed && S.sleeve.length < sleeveCap() && !sleeveLocked();
}
function canResurface(){
  return H.phase === "player" && !busy && !H.outUsed && S.sleeve.length > 0 && !sleeveLocked() && !!cur() && cur().state === "play";
}
function renderActions(){
  const play = H.phase === "player" && !busy;
  const h = cur();
  const deal = $("dealBtn");
  const dealLabel = MODE === "duel" ? (H.phase === "idle" ? "Je suis prêt" : "Manche suivante") : (H.phase === "idle" ? "Distribuer" : "Main suivante");
  deal.innerHTML = dealLabel + "<kbd>Espace</kbd>";
  deal.disabled = busy || !["idle","done"].includes(H.phase);
  $("hitBtn").disabled = !play;
  $("standBtn").disabled = !play;
  $("dblBtn").disabled = !play || !h || h.cards.length !== 2 || h.burned > 0;
  $("splitBtn").disabled = !play || !canSplit();
  $("burnBtn").disabled = !play || T.burns <= 0 || !h || h.cards.length < 2;
  $("hideBtn").disabled = !play || !canHide();
  $("burnBtn").innerHTML = `Brûler (${T ? T.burns : 0})<kbd>B</kbd>`;
}
async function renderPeek(){
  const box = $("peek");
  if(!has("devin") || H.phase !== "player"){ box.hidden = true; return; }
  const c = await peekNext();
  if(!c){ box.hidden = true; return; }
  box.hidden = false; box.innerHTML = "Prochaine carte :";
  box.appendChild(cardEl(c, {small:true}));
}
function setMsg(t, kind = ""){ const m = $("msg"); m.textContent = t; m.className = "msg" + (kind ? " " + kind : ""); }
function setBoxes(chips, mult, dmg){
  $("chipsBox").lastChild.textContent = chips;
  $("multBox").lastChild.textContent = Number.isInteger(mult) ? mult : mult.toFixed(1);
  $("dmgBox").lastChild.textContent = dmg;
  // Les flammes montent avec les valeurs, comme dans les grands jeux de cartes à scores
  heatBox("chipsBox", chips >= 30 ? Math.min(1, (Math.log10(chips) - 1.4) / 1.3 + .15) : 0);
  heatBox("multBox", mult >= 4 ? Math.min(1, Math.log(mult / 3) / Math.log(12) + .15) : 0);
  if(dmg === 0 || dmg === "…") heatBox("dmgBox", 0);
}
function heatBox(id, heat){
  const b = $(id); b.style.setProperty("--heat", heat.toFixed(2)); b.classList.toggle("hot", heat > 0);
  if(typeof Fire !== "undefined") Fire.set(id, heat); // shader WebGL (fire.js), sinon flammes CSS
}
const cardNode = key => key ? document.querySelector(`.card[data-key="${key}"]`) : null;
function jiggle(el){ if(!el) return; el.classList.remove("jiggle"); void el.offsetWidth; el.classList.add("jiggle"); }
// Petit chiffre qui jaillit au-dessus d'une carte
function floatText(el, text, kind = "chips"){
  if(!el) return;
  const r = el.getBoundingClientRect();
  const f = document.createElement("div");
  f.className = "floatnum " + kind; f.textContent = text;
  f.style.left = (r.left + r.width / 2) + "px"; f.style.top = (r.top + 4) + "px";
  document.body.appendChild(f);
  setTimeout(() => f.remove(), 950);
}
function countUp(node, to){
  return new Promise(res => {
    if(reduced() || to <= 0){ node.textContent = to; return res(); }
    const t0 = performance.now(), dur = Math.min(900, 300 + to * 2);
    const step = now => {
      const k = Math.min(1, (now - t0) / dur);
      node.textContent = Math.round(to * (1 - Math.pow(1 - k, 3)));
      if(k < 1) requestAnimationFrame(step); else res();
    };
    requestAnimationFrame(step);
  });
}
function quake(power = 1){
  const f = document.querySelector(".felt");
  f.style.setProperty("--q", power); f.classList.remove("quake"); void f.offsetWidth; f.classList.add("quake");
}
const wait = ms => new Promise(r => setTimeout(r, reduced() ? Math.min(ms, 60) : ms));
function flash(id){
  const el = document.querySelector(`#charms .charm[data-id="${id}"]`);
  if(el){ el.classList.remove("fire"); void el.offsetWidth; el.classList.add("fire"); }
}
function pop(id){ const el = $(id); el.classList.remove("pop"); void el.offsetWidth; el.classList.add("pop"); }
function refreshAll(){ renderHands(); renderActions(); renderCharms(); renderFoe(); }
