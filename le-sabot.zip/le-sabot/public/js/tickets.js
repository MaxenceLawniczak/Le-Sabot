"use strict";
// Tickets : objets à usage unique. On en garde 2 au plus, achetés en boutique,
// et on les utilise entre deux mains ou en boutique. Certains visent une carte de ton deck.

const TICKET_SLOTS = 2;
const TICKETS = {
  burin:     {ico:"🔨", name:"Burin", cost:3, desc:"Grave une carte au choix (+15 jetons).", target:c => !isSp(c), apply:c => { c.enh = "grave"; }},
  ecrin:     {ico:"💍", name:"Écrin", cost:4, desc:"Sertit de rubis une carte au choix (+4 mult).", target:c => !isSp(c), apply:c => { c.enh = "rouge"; }},
  feuille:   {ico:"🪙", name:"Feuille d'or", cost:3, desc:"Dore une carte au choix (+2 or quand elle gagne).", target:c => !isSp(c), apply:c => { c.enh = "or"; }},
  soufflet:  {ico:"🫙", name:"Soufflet", cost:4, desc:"Change une carte au choix en verre (×1,5 mult, fragile).", target:c => !isSp(c), apply:c => { c.enh = "verre"; }},
  vernis:    {ico:"✨", name:"Vernis", cost:5, desc:"Donne à une carte au choix une édition au hasard : foil, holo ou poly.", target:() => true, apply:c => { c.ed = randomEd(); }},
  duplicata: {ico:"📄", name:"Duplicata", cost:4, desc:"Ajoute à ton deck une copie d'une carte au choix, améliorations comprises.", target:() => true, apply:c => { S.deck.push({...c, uid: ++uidSeq}); }},
  scalpel:   {ico:"🔪", name:"Scalpel", cost:2, desc:"Retire définitivement une carte au choix de ton deck.", target:c => !inSleeve(c.uid), apply:c => { S.deck = S.deck.filter(i => i.uid !== c.uid); }},
  chiffrage: {ico:"🔢", name:"Chiffrage", cost:4, desc:"Change un As à 10 classique au choix en enseigne de valeur (le 4 de cœur devient un cœur de 4).",
              target:c => !isSp(c) && !c.num && suitOf(c) !== NOTHING && NUM_RANKS.includes(rankOf(c)), apply:c => { c.num = true; c.neg = false; }},
  inversion: {ico:"🔄", name:"Inversion", cost:3, desc:"Rend négative une carte au choix, ou la rétablit si elle l'est déjà.", target:c => !isSp(c) && !c.num, apply:c => { c.neg = !c.neg; }},
  remede:    {ico:"🧪", name:"Remède", cost:3, desc:"Récupère 20 PV.", use:() => { const v = Math.min(20, S.maxHp - S.hp); S.hp += v; return `+${v} PV`; }},
  placement: {ico:"📈", name:"Placement", cost:4, desc:"Double ton or (20 or de plus au maximum).", use:() => { const v = Math.min(20, S.gold); S.gold += v; sfx("coin"); stat("gold", {gold:S.gold}); return `+${v} or`; }},
  recrue:    {ico:"🎟️", name:"Recrue", cost:4, desc:"Te donne un charme commun au hasard, s'il te reste un emplacement.",
              when:() => slotsUsed() < charmSlots(),
              use:() => { const id = pickOne(Object.keys(CHARMS).filter(k => CHARMS[k].rarity === "commun" && !has(k))); S.charms.push({id, n:0, ed:null}); stat("charm", {id}); return CHARMS[id].name; }},
  potdevin:  {ico:"🤝", name:"Pot-de-vin", cost:5, desc:"En solo, pendant une table : ton adversaire perd 25 % de ses PV maximum.",
              when:() => MODE === "solo" && T && T.foe && T.foe.maxHp > 1 && T.foe.hp > 0 && $("modal").hidden,
              use:() => { const v = Math.round(T.foe.maxHp * .25); T.foe.hp -= v; renderFoe(); sfx("hit", .6); return `${T.foe.name} perd ${v} PV`; }},
};

// Utilisable entre deux mains ou en boutique, jamais pendant qu'on joue une main
const ticketsFree = () => !busy && !["deal", "player", "dealer", "wait"].includes(H && H.phase);
function renderTickets(){
  const box = $("tickets"); if(!box || !S) return;
  $("ticketCount").textContent = `${(S.tickets || []).length}/${TICKET_SLOTS}`;
  box.innerHTML = "";
  (S.tickets || []).forEach((id, i) => box.appendChild(ticketEl(id, i, true)));
  if(!(S.tickets || []).length) box.innerHTML = `<p class="tempty">Aucun ticket. On en achète en boutique.</p>`;
}
function ticketEl(id, i, usable){
  const t = TICKETS[id], d = document.createElement("div");
  d.className = "ticket";
  d.innerHTML = `<span class="tico" aria-hidden="true">${t.ico}</span><span class="ttxt"><b>${t.name}</b><em>${t.desc}</em></span>`;
  if(usable){
    const b = document.createElement("button"); b.className = "tuse"; b.textContent = "Utiliser";
    b.disabled = !ticketsFree() || (t.when && !t.when());
    b.onclick = () => useTicket(i);
    d.appendChild(b);
  }
  return d;
}
// back : ce qu'on rouvre après usage (la boutique, ou rien pour revenir à la table)
function useTicket(i, back = null){
  const id = S.tickets[i], t = TICKETS[id];
  if(!t || !ticketsFree() || (t.when && !t.when())) return;
  const done = note => {
    S.tickets.splice(i, 1); sfx("pack");
    toast(`${t.ico} ${t.name}`, note || "");
    refreshAll(); sendState();
    if(MODE === "solo") saveRun(back ? "shop" : "table");
    if(back) back(); else closeModal();
  };
  if(!t.target){ done(t.use()); return; }
  pickCard(`${t.ico} ${t.name}`, t.desc, t.target, c => { t.apply(c); done(cardName(c)); }, () => back ? back() : closeModal());
}
// Choix d'une carte du deck, présentée comme la vue « Mon deck »
function pickCard(title, text, filter, then, cancel){
  const cards = S.deck.filter(c => !inSleeve(c.uid) && filter(c));
  openModal(`<h2>${title}</h2><p>${text}</p><p class="status">Choisis la carte.</p><div class="deckgrid" id="pickGrid"></div>
    <div class="bar"><button class="btn" id="pickCancel">Annuler</button></div>`, "pick");
  const grid = $("pickGrid");
  if(!cards.length) grid.outerHTML = `<p style="color:var(--dim)">Aucune carte de ton deck ne convient.</p>`;
  const order = c => (isSp(c) ? 100 : SUITS.indexOf(suitOf(c)) * 20) + RANKS.indexOf(rankOf(c));
  cards.sort((a, b) => order(a) - order(b)).forEach(c => {
    const el = cardEl(c); el.classList.add("pick"); el.tabIndex = 0; el.setAttribute("role", "button");
    el.onclick = () => then(c); el.onkeydown = e => { if(e.key === "Enter" || e.key === " "){ e.preventDefault(); then(c); } };
    grid && grid.appendChild(el);
  });
  $("pickCancel").onclick = cancel;
}
