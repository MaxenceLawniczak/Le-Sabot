"use strict";
// Dessin des cartes, entièrement en SVG : cartes classiques, Nothing, négatives, améliorations et spéciales.
// Les symboles (enseignes, illustrations, dégradés) sont définis une seule fois dans un
// « sprite » caché, puis réutilisés par chaque carte avec <use>.

const INK_STD = {S:"#1d1a22", C:"#1d1a22", H:"#b3202b", D:"#b3202b", N:"#111"};
// Contraste élevé : une couleur franche par enseigne (♠ marine, ♥ rouge, ♦ orange, ♣ bleu)
const INK_HC = {S:"#1c2b5a", C:"#1f7fcf", H:"#d8203a", D:"#e8761a", N:"#111"};
const NEG_HC = {H:"#c81a33", D:"#e06a10", S:"#1c2b5a", C:"#1a6fb8", N:"#46464d"};
// Fond des cartes négatives : chaque enseigne a sa couleur, les valeurs sont en blanc.
const NEG_STD = {H:"#b3202b", D:"#cf4a22", S:"#24202c", C:"#1f4a33", N:"#46464d"};
const CREAM = "#fbf7ef";
const FONT_D = "'Alfa Slab One', Rockwell, Georgia, serif";
const FONT_B = "'Barlow Semi Condensed', 'Arial Narrow', sans-serif";

const SUIT_SHAPE = {
  H:'<path d="M0 4.6C-1.3 3.3-5 .8-5-2.1-5-3.9-3.7-5-2.3-5-1.2-5-.4-4.3 0-3.4.4-4.3 1.2-5 2.3-5 3.7-5 5-3.9 5-2.1 5 .8 1.3 3.3 0 4.6Z"/>',
  D:'<path d="M0-5.2 3.8 0 0 5.2-3.8 0Z"/>',
  S:'<path d="M0-5.2C-1-3.4-5-1.4-5 1.2-5 3-3.1 3.9-1.2 2.7-1.4 3.8-2 4.6-2.8 5.2H2.8C2 4.6 1.4 3.8 1.2 2.7 3.1 3.9 5 3 5 1.2 5-1.4 1-3.4 0-5.2Z"/>',
  N:'<circle r="3.4"/>',
  C:'<circle cy="-2.6" r="2.3"/><circle cx="-2.5" cy="1.1" r="2.3"/><circle cx="2.5" cy="1.1" r="2.3"/><circle cy=".4" r="1.3"/><path d="M-.7 .5H.7L1.5 5.2H-1.5Z"/>',
};

// Fonds des cartes spéciales (haut → bas)
const SP_BG = {
  cameleon:["#2a7356","#0c241c"], fantome:["#4a3b7c","#15102a"], miroir:["#34597f","#0f1b2b"],
  petard:["#7a2219","#1e0806"], pie:["#2a3b66","#0a0f1d"], sangsue:["#5e1427","#17040a"], clou:["#4a3616","#120c05"],
};

// Illustrations originales, dessinées dans une boîte 100 × 100.
const SP_ART = {
  cameleon: `
    <path d="M4 82Q50 72 96 84" stroke="#6b4a2b" stroke-width="5" fill="none" stroke-linecap="round"/>
    <path d="M70 80l6-9M84 83l3-8" stroke="#6b4a2b" stroke-width="3" stroke-linecap="round"/>
    <path d="M34 66C20 70 11 60 17 52c4-5 13-4 13 3 0 4-5 5-6 2" stroke="#52c47f" stroke-width="6" fill="none" stroke-linecap="round"/>
    <path d="M30 66C31 47 49 36 66 40c10 2 17 9 20 17-6 5-14 9-25 11Z" fill="#52c47f"/>
    <path d="M40 50c3 6 3 12 0 17M50 44c3 7 3 16 0 23M60 42c3 8 3 17 0 24" stroke="#2f8f58" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M62 40c4-8 12-10 18-6-4 1-7 4-8 8" fill="#3aa865"/>
    <path d="M38 67l-4 13M56 68l2 13" stroke="#3aa865" stroke-width="5" stroke-linecap="round"/>
    <circle cx="74" cy="50" r="7" fill="#f4e27a" stroke="#1b4d33" stroke-width="2"/>
    <circle cx="76" cy="50" r="2.6" fill="#10261a"/>
    <path d="M86 58q8 1 10 6" stroke="#e8516a" stroke-width="2.5" fill="none" stroke-linecap="round"/>`,
  fantome: `
    <ellipse cx="50" cy="93" rx="22" ry="3.5" fill="#000" opacity=".3"/>
    <path d="M26 86V46c0-19 12-30 24-30s24 11 24 30v40l-8-8-8 8-8-8-8 8-8-8Z" fill="#f3efff"/>
    <path d="M62 22c7 5 12 14 12 24v40l-8-8" fill="#d6cdf5"/>
    <ellipse cx="41" cy="46" rx="4.5" ry="6.5" fill="#241a3a"/>
    <ellipse cx="59" cy="46" rx="4.5" ry="6.5" fill="#241a3a"/>
    <circle cx="42.5" cy="43.5" r="1.4" fill="#fff"/><circle cx="60.5" cy="43.5" r="1.4" fill="#fff"/>
    <ellipse cx="50" cy="62" rx="5" ry="6.5" fill="#241a3a"/>
    <path d="M12 40h8M9 52h9M80 38h8M82 50h9" stroke="#b9a9f0" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>`,
  miroir: `
    <rect x="45" y="70" width="10" height="26" rx="4" fill="#c9a24a"/>
    <rect x="43" y="68" width="14" height="6" rx="2" fill="#a8842f"/>
    <ellipse cx="50" cy="40" rx="27" ry="33" fill="#c9a24a"/>
    <ellipse cx="50" cy="40" rx="22" ry="28" fill="url(#sp-glass)"/>
    <path d="M36 28l14-12M36 44l24-22M42 56l20-18" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".55"/>
    <circle cx="50" cy="7.5" r="3" fill="#e8c56a"/><circle cx="23.5" cy="40" r="2.5" fill="#e8c56a"/><circle cx="76.5" cy="40" r="2.5" fill="#e8c56a"/>`,
  petard: `
    <path d="M50 36c0-9 6-12 10-19" stroke="#5a3b1c" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M62 4l3 7 7-2-4 6 6 5-8 1 1 8-6-5-5 5v-8l-7-2 6-4-3-7 7 3Z" fill="#ffd84a"/>
    <circle cx="61" cy="14" r="3.5" fill="#fff4c2"/>
    <circle cx="76" cy="8" r="1.8" fill="#ffb13b"/><circle cx="48" cy="6" r="1.5" fill="#ffb13b"/><circle cx="78" cy="24" r="1.4" fill="#ffb13b"/>
    <rect x="34" y="36" width="32" height="54" rx="6" fill="#d8332b"/>
    <rect x="34" y="36" width="10" height="54" rx="5" fill="#f05a4a" opacity=".6"/>
    <rect x="34" y="45" width="32" height="7" fill="#f1c34b"/>
    <rect x="34" y="74" width="32" height="7" fill="#f1c34b"/>
    <ellipse cx="50" cy="37" rx="16" ry="4" fill="#a8231d"/>`,
  pie: `
    <path d="M34 60L4 76l5 6 28-13Z" fill="#2b4a9a"/>
    <path d="M34 62 8 74" stroke="#4e74d6" stroke-width="2"/>
    <ellipse cx="50" cy="58" rx="22" ry="15" fill="#15151b"/>
    <ellipse cx="46" cy="64" rx="13" ry="8.5" fill="#f4f4f4"/>
    <path d="M36 50c8-6 22-6 30 2-8 6-20 8-30-2Z" fill="#2c4390"/>
    <path d="M42 52c5-2 11-2 15 1-5 2-10 2-15-1Z" fill="#f4f4f4"/>
    <circle cx="70" cy="45" r="10" fill="#15151b"/>
    <circle cx="73" cy="42.5" r="2.2" fill="#fff"/><circle cx="73.6" cy="42.5" r="1" fill="#111"/>
    <path d="M78 44l11 3-11 4Z" fill="#3a3a44"/>
    <circle cx="90" cy="53" r="6" fill="#e2b340" stroke="#a37a1c" stroke-width="1.5"/>
    <path d="M44 72l-3 12M54 72l2 12" stroke="#3a3a44" stroke-width="2.5" stroke-linecap="round"/>`,
  sangsue: `
    <path d="M18 68C18 38 48 30 58 48c6 11 20 14 26-2" stroke="#5b1426" stroke-width="17" fill="none" stroke-linecap="round"/>
    <path d="M18 68C18 38 48 30 58 48c6 11 20 14 26-2" stroke="#8a2a3f" stroke-width="7" fill="none" stroke-linecap="round" opacity=".6"/>
    <path d="M14 56h9M16 46l8 3M24 38l6 6M34 33l3 8M45 33l-1 8M53 38l-4 6M60 49l-7 3M66 56l-4 7M76 58l-1 8M84 50l-8 1" stroke="#3b0a17" stroke-width="2" stroke-linecap="round"/>
    <circle cx="84" cy="46" r="6" fill="#3b0a17"/><circle cx="84" cy="46" r="2.5" fill="#c3122b"/>
    <path d="M44 82c0-6 6-12 6-12s6 6 6 12a6 6 0 0 1-12 0Z" fill="#d0142f"/>
    <circle cx="48" cy="82" r="1.6" fill="#ff8a98"/>`,
  clou: `
    <path d="M34 8h32l10 22-10 66H34L24 30Z" fill="#000" opacity=".32" stroke="#8f6e33" stroke-width="1.5"/>
    <path d="M44 38h12M50 32v18" stroke="#8f6e33" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
    <rect x="36" y="58" width="28" height="7" rx="2.5" fill="#c9c9d4"/>
    <path d="M47 65h6l-1 22-2 9-2-9Z" fill="#9a9aa8"/>
    <path d="M49 66v20" stroke="#e4e4ee" stroke-width="1.2"/>`,
};

(function injectSprite(){
  const sym = Object.entries(SUIT_SHAPE).map(([s, d]) => `<symbol id="su-${s}" viewBox="-5.5 -5.5 11 11">${d}</symbol>`).join("");
  const grads = Object.entries(SP_BG).map(([id, [a, b]]) =>
    `<linearGradient id="bg-${id}" x1="0" y1="0" x2=".35" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient>`).join("");
  const arts = Object.entries(SP_ART).map(([id, d]) => `<symbol id="art-${id}" viewBox="0 0 100 100">${d}</symbol>`).join("");
  const extra = `<linearGradient id="sp-glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e6f3ff"/><stop offset="1" stop-color="#6f98c8"/></linearGradient>
    <linearGradient id="enh-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3bf"/><stop offset=".3" stop-color="#f1cc62"/><stop offset=".65" stop-color="#c9922a"/><stop offset="1" stop-color="#f7dc8a"/></linearGradient>
    <linearGradient id="enh-gold-shine" x1="0" y1="0" x2="1" y2=".4" gradientUnits="objectBoundingBox">
      <stop offset=".35" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".75"/><stop offset=".65" stop-color="#fff" stop-opacity="0"/>
      <animateTransform attributeName="gradientTransform" type="translate" values="-1 0;1.2 0;1.2 0" dur="3.2s" repeatCount="indefinite"/></linearGradient>
    <linearGradient id="enh-steel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3f6f9"/><stop offset=".5" stop-color="#cdd5de"/><stop offset="1" stop-color="#e8edf2"/></linearGradient>
    <pattern id="enh-lines" width="4" height="2.4" patternUnits="userSpaceOnUse"><path d="M0 1.2H4" stroke="#5f6f82" stroke-width=".45" opacity=".45"/></pattern>
    <linearGradient id="enh-glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f2f9ff" stop-opacity=".78"/><stop offset="1" stop-color="#b5d8f0" stop-opacity=".58"/></linearGradient>
    <linearGradient id="enh-glass-glint" x1="0" y1="0" x2="1" y2=".6">
      <stop offset=".4" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".8"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/>
      <animateTransform attributeName="gradientTransform" type="translate" values="-1 0;1.2 0;1.2 0;1.2 0" dur="4.5s" repeatCount="indefinite"/></linearGradient>
    <symbol id="gem" viewBox="-7 -7 14 14"><circle r="6.6" fill="#b88a2e"/><circle r="5.6" fill="#f0cf73"/>
      <path d="M-4.6-1.6-2.3-4.4H2.3L4.6-1.6 0 4.8Z" fill="#c8102e"/><path d="M-4.6-1.6H4.6L0 4.8Z" fill="#8a0b1f"/>
      <path d="M-2.3-4.4-.9-1.6H.9L2.3-4.4Z" fill="#ff7a8f"/><path d="M-.9-1.6 0 4.8 .9-1.6Z" fill="#e3284a"/></symbol>
    <pattern id="hatch-dark" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V6" stroke="#000" stroke-width="1" opacity=".08"/></pattern>
    <pattern id="hatch-light" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V6" stroke="#fff" stroke-width="1" opacity=".16"/></pattern>`;
  document.body.insertAdjacentHTML("afterbegin",
    `<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs>${sym}${grads}${extra}${arts}</defs></svg>`);
})();

const pip = (s, x, y, size, color, flip = false) =>
  `<use href="#su-${s}" x="${x - size / 2}" y="${y - size / 2}" width="${size}" height="${size}" fill="${color}"${flip ? ` transform="rotate(180 ${x} ${y})"` : ""}/>`;

// Positions des enseignes au centre, de 2 à 10 (celles du bas sont retournées)
const PIPS = {
  2:[[50,30],[50,110]],
  3:[[50,30],[50,70],[50,110]],
  4:[[30,30],[70,30],[30,110],[70,110]],
  5:[[30,30],[70,30],[50,70],[30,110],[70,110]],
  6:[[30,30],[70,30],[30,70],[70,70],[30,110],[70,110]],
  7:[[30,30],[70,30],[50,50],[30,70],[70,70],[30,110],[70,110]],
  8:[[30,30],[70,30],[50,50],[30,70],[70,70],[50,90],[30,110],[70,110]],
  9:[[30,30],[70,30],[30,57],[70,57],[50,70],[30,83],[70,83],[30,110],[70,110]],
  10:[[30,30],[70,30],[50,44],[30,57],[70,57],[30,83],[70,83],[50,96],[30,110],[70,110]],
};

// Emblèmes des figures : couronne (roi), diadème (dame), épée (valet)
const FACE_EMBLEM = {
  K: c => `<path d="M31 66 33 44l9 11 8-15 8 15 9-11 2 22Z" fill="${c}"/>
           <rect x="31" y="66" width="38" height="7" rx="2" fill="${c}"/>
           <circle cx="33" cy="42" r="3" fill="${c}"/><circle cx="50" cy="38" r="3.4" fill="${c}"/><circle cx="67" cy="42" r="3" fill="${c}"/>
           <circle cx="42" cy="69.5" r="1.7" fill="${CREAM}"/><circle cx="50" cy="69.5" r="1.7" fill="${CREAM}"/><circle cx="58" cy="69.5" r="1.7" fill="${CREAM}"/>`,
  Q: c => `<path d="M30 70Q50 34 70 70Z" fill="${c}"/>
           <path d="M36 70Q50 48 64 70" fill="none" stroke="${CREAM}" stroke-width="1.6"/>
           <circle cx="50" cy="44" r="4" fill="${c}"/><circle cx="50" cy="44" r="1.6" fill="${CREAM}"/>
           <circle cx="38" cy="55" r="2.6" fill="${c}"/><circle cx="62" cy="55" r="2.6" fill="${c}"/>
           <rect x="30" y="70" width="40" height="5" rx="2" fill="${c}"/>`,
  J: c => `<path d="M50 30 55 38V64H45V38Z" fill="${c}"/>
           <path d="M50 36V62" stroke="${CREAM}" stroke-width="1.4"/>
           <rect x="36" y="64" width="28" height="5" rx="2.5" fill="${c}"/>
           <rect x="47" y="69" width="6" height="9" rx="1.5" fill="${c}"/>
           <circle cx="50" cy="81" r="3.6" fill="${c}"/>
           <circle cx="36" cy="66.5" r="3" fill="${c}"/><circle cx="64" cy="66.5" r="3" fill="${c}"/>`,
};

// Couches de fond (sous l'encre) et de surface (par-dessus) propres à chaque amélioration.
// Sur une carte négative, le fond garde la couleur de l'enseigne : l'amélioration la teinte seulement.
function enhUnder(enh, neg){
  const o = neg ? ' opacity=".45"' : "";
  if(enh === "or") return `<rect width="100" height="140" rx="7" fill="url(#enh-gold)"${o}/>`;
  if(enh === "grave") return `<rect width="100" height="140" rx="7" fill="url(#enh-steel)"${o}/><rect width="100" height="140" rx="7" fill="url(#enh-lines)"/>`;
  return "";
}
function enhOver(enh){
  if(enh === "or") return `<rect width="100" height="140" rx="7" fill="url(#enh-gold-shine)"/>
    <rect x="2" y="2" width="96" height="136" rx="6" fill="none" stroke="#a8781f" stroke-width="2.5"/>
    <rect x="5.5" y="5.5" width="89" height="129" rx="4" fill="none" stroke="#fff4c4" stroke-width=".8" opacity=".8"/>`;
  if(enh === "grave") return `<rect x="2" y="2" width="96" height="136" rx="6" fill="none" stroke="#7d8a99" stroke-width="2"/>
    <rect x="5" y="5" width="90" height="130" rx="4" fill="none" stroke="#fff" stroke-width=".7" opacity=".9"/>
    <circle cx="8" cy="8" r="1.6" fill="#8995a3"/><circle cx="92" cy="8" r="1.6" fill="#8995a3"/><circle cx="8" cy="132" r="1.6" fill="#8995a3"/><circle cx="92" cy="132" r="1.6" fill="#8995a3"/>`;
  if(enh === "rouge") return `<rect x="3" y="3" width="94" height="134" rx="5.5" fill="none" stroke="#c8102e" stroke-width="2.2"/>
    <rect x="6" y="6" width="88" height="128" rx="4" fill="none" stroke="#d9ab52" stroke-width="1"/>
    ${[[50,6],[50,134],[5,70],[95,70],[22,6],[78,6],[22,134],[78,134]].map(([x, y], i) =>
      `<use href="#gem" x="${x - (i < 4 ? 6 : 4)}" y="${y - (i < 4 ? 6 : 4)}" width="${i < 4 ? 12 : 8}" height="${i < 4 ? 12 : 8}"/>`).join("")}`;
  if(enh === "verre") return `<rect width="100" height="140" rx="7" fill="url(#enh-glass-glint)"/>
    <path d="M-5 38 38-5h14L-5 52Z" fill="#fff" opacity=".35"/><path d="M60 145 105 100v12L72 145Z" fill="#fff" opacity=".28"/>
    <path d="M71 98l7 9-4 6 9 8M78 107l6-3" stroke="#fff" stroke-width=".9" fill="none" opacity=".8"/>
    <rect x="1.5" y="1.5" width="97" height="137" rx="6.5" fill="none" stroke="#fff" stroke-width="1.6" opacity=".85"/>
    <rect x="4" y="4" width="92" height="132" rx="5" fill="none" stroke="#bfe3ff" stroke-width=".8" opacity=".7"/>`;
  return "";
}

function standardSVG(c){
  const INK = SETTINGS.highContrast ? INK_HC : INK_STD, NEG_BG = SETTINGS.highContrast ? NEG_HC : NEG_STD;
  const r = rankOf(c), s = suitOf(c), neg = !!c.neg, enh = c.enh;
  const ink = neg ? "#fff" : INK[s];
  const glass = enh === "verre";
  // Le verre laisse voir le tapis à travers la carte (fond translucide, flou géré en CSS)
  const bg = glass ? (neg ? NEG_BG[s] + "99" : "url(#enh-glass)") : neg ? NEG_BG[s] : CREAM;
  const accent = neg ? NEG_BG[s] : enh === "or" ? "#f1cc62" : enh === "grave" ? "#dfe5eb" : CREAM;
  const label = (neg ? "−" : "") + rankLabel(r);
  const small = label.length > 2 ? 12 : label.length > 1 ? 15 : 18;
  const corner = `<text x="11" y="21" text-anchor="middle" font-family="${FONT_D}" font-size="${small}" fill="${ink}">${label}</text>${pip(s, 11, 30, 10, ink)}`;
  let center = "";
  if(r === "A"){
    center = pip(s, 50, 70, s === NOTHING ? 30 : neg ? 40 : 46, ink);
    if(neg) center += `<text x="50" y="118" text-anchor="middle" font-family="${FONT_D}" font-size="13" fill="#fff" opacity=".85">−1</text>`;
  } else if("JQK".includes(r)){
    center = `<rect x="20" y="22" width="60" height="96" rx="5" fill="url(#hatch-${neg ? "light" : "dark"})" stroke="${ink}" stroke-width="1.4"/>
      <rect x="23" y="25" width="54" height="90" rx="3.5" fill="none" stroke="${ink}" stroke-width=".6" opacity=".6"/>
      ${FACE_EMBLEM[r](ink).replaceAll(CREAM, accent)}
      ${pip(s, 50, 96, s === NOTHING ? 16 : 24, ink)}`;
  } else {
    const n = r === "0" ? 10 : +r;
    const size = s === NOTHING ? (n === 10 ? 11 : 12) : n === 10 ? 15 : 17;
    center = PIPS[n].map(([x, y]) => pip(s, x, y, size, ink, y > 72)).join("");
  }
  return `<svg viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="100" height="140" rx="7" fill="${bg}"/>${glass ? "" : enhUnder(enh, neg)}
    <rect x="3" y="3" width="94" height="134" rx="5.5" fill="none" stroke="${neg ? "#fff" : "#000"}" stroke-opacity="${neg ? .3 : .08}"/>
    ${corner}<g transform="rotate(180 50 70)">${corner}</g>${center}${enhOver(enh)}</svg>`;
}

function specialSVG(c){
  const d = SPECIALS[c.sp];
  const id = d.nail ? "clou" : c.sp;
  const v = typeof d.val === "number" ? d.val : d.val === "wild" ? "?" : "=";
  const name = d.nail ? "Clou du cercueil" : d.name;
  const top = d.nail
    ? `<text x="50" y="27" text-anchor="middle" font-family="${FONT_D}" font-size="20" fill="#e2b85a">${ROMAN[d.nail]}</text>`
    : "";
  return `<svg viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="100" height="140" rx="7" fill="url(#bg-${id})"/>
    <rect x="3" y="3" width="94" height="134" rx="5.5" fill="none" stroke="#fff" stroke-opacity=".2"/>
    <rect x="7" y="7" width="86" height="126" rx="4" fill="none" stroke="${d.nail ? "#d9ab52" : "#b58cff"}" stroke-opacity=".45" stroke-dasharray="2 3"/>
    ${top}
    <use href="#art-${id}" x="8" y="${d.nail ? 28 : 20}" width="84" height="84"/>
    <circle cx="16" cy="16" r="9.5" fill="#000" fill-opacity=".45" stroke="#d9ab52" stroke-width="1.2"/>
    <text x="16" y="20.5" text-anchor="middle" font-family="${FONT_D}" font-size="12" fill="#f1e8d9">${v}</text>
    <rect x="10" y="112" width="80" height="18" rx="4" fill="#000" fill-opacity=".4"/>
    <text x="50" y="125" text-anchor="middle" font-family="${FONT_B}" font-weight="700" font-size="${name.length > 13 ? 10 : 11.5}" fill="#f1e8d9">${name}</text></svg>`;
}

const cardSVG = c => isSp(c) ? specialSVG(c) : standardSVG(c);

// Dos de cartes : un par deck. Motifs dessinés une fois dans un sprite, puis réutilisés.
const BACKS = {
  classique:{bg:["#7a2230","#4d121b"], pat:`<path d="M0 6 6 0 12 6 6 12Z" fill="none" stroke="#d9ab52" stroke-opacity=".35" stroke-width=".8"/>`, w:12, h:12, emblem:"S", ink:"#d9ab52"},
  rouge:    {bg:["#d0342c","#7a1410"], pat:`<path d="M6 11C3 9 3 6 6 2 6 5 9 6 9 8.5 9 10 8 11 6 11Z" fill="#ffb13b" opacity=".35"/>`, w:12, h:12, emblem:"♥", ink:"#ffd08a"},
  or:       {bg:["#f3d27a","#b8862b"], pat:`<circle cx="7" cy="7" r="4.5" fill="none" stroke="#8a5f14" stroke-opacity=".45" stroke-width="1"/><circle cx="7" cy="7" r="1.6" fill="#8a5f14" opacity=".35"/>`, w:14, h:14, emblem:"¤", ink:"#6b4508"},
  azur:     {bg:["#3f86c8","#173d66"], pat:`<path d="M0 6q3-4 6 0t6 0" fill="none" stroke="#bfe3ff" stroke-opacity=".45" stroke-width="1.1"/>`, w:12, h:8, emblem:"≈", ink:"#e3f3ff"},
  braise:   {bg:["#3a1a12","#120806"], pat:`<circle cx="3" cy="4" r="1" fill="#ff7a2e" opacity=".7"/><circle cx="10" cy="9" r=".7" fill="#ffb13b" opacity=".6"/><circle cx="7" cy="1.5" r=".5" fill="#ffd08a" opacity=".6"/>`, w:13, h:12, emblem:"✹", ink:"#ff9a4a", glow:"#ff5a1e"},
  emeraude: {bg:["#2f8f5a","#0f3b24"], pat:`<path d="M6 0C9 3 9 6 6 9 3 6 3 3 6 0Z" fill="#8ce0a8" opacity=".3"/>`, w:12, h:10, emblem:"✦", ink:"#c9f5d8"},
  neant:    {bg:["#fbf7ef","#e6dfd2"], pat:``, w:10, h:10, emblem:"●", ink:"#111", plain:true},
  abysse:   {bg:["#1a2a5a","#050914"], pat:`<circle cx="8" cy="8" r="6" fill="none" stroke="#5ea4dc" stroke-opacity=".22"/><circle cx="8" cy="8" r="2.5" fill="none" stroke="#5ea4dc" stroke-opacity=".3"/>`, w:16, h:16, emblem:"◉", ink:"#8fc6ff", glow:"#2f6fd0"},
  prisme:   {bg:["#2a1f3d","#0e0a18"], pat:`<path d="M0 10 5 0 10 10Z" fill="none" stroke="#fff" stroke-opacity=".12"/>`, w:10, h:10, emblem:"▲", ink:"#fff", rainbow:true},
};
(function injectBacks(){
  const defs = Object.entries(BACKS).map(([id, b]) =>
    `<linearGradient id="bk-bg-${id}" x1="0" y1="0" x2=".4" y2="1"><stop offset="0" stop-color="${b.bg[0]}"/><stop offset="1" stop-color="${b.bg[1]}"/></linearGradient>
     <pattern id="bk-pat-${id}" width="${b.w}" height="${b.h}" patternUnits="userSpaceOnUse">${b.pat}</pattern>`).join("") +
    `<linearGradient id="bk-rainbow" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff5e7e"/><stop offset=".25" stop-color="#ffd25e"/><stop offset=".5" stop-color="#5effa0"/><stop offset=".75" stop-color="#5ec8ff"/><stop offset="1" stop-color="#c05eff"/></linearGradient>`;
  document.body.insertAdjacentHTML("afterbegin", `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${defs}</defs></svg>`);
})();
function backSVG(deckId){
  const id = BACKS[deckId] ? deckId : "classique", b = BACKS[id];
  const emblem = b.plain
    ? `<circle cx="50" cy="70" r="7" fill="#111"/><rect x="10" y="10" width="80" height="120" rx="4" fill="none" stroke="#111" stroke-opacity=".25"/>`
    : `${b.glow ? `<circle cx="50" cy="70" r="30" fill="${b.glow}" opacity=".35"/>` : ""}
       ${b.rainbow ? `<path d="M50 44 72 86H28Z" fill="none" stroke="#fff" stroke-width="2.5"/><path d="M10 72 42 66M58 64 92 50" stroke="url(#bk-rainbow)" stroke-width="5" opacity=".9"/><path d="M58 64 92 78" stroke="url(#bk-rainbow)" stroke-width="3" opacity=".7"/>`
         : `<circle cx="50" cy="70" r="19" fill="#000" fill-opacity=".25" stroke="${b.ink}" stroke-width="2"/>
            <text x="50" y="78" text-anchor="middle" font-family="${FONT_D}" font-size="22" fill="${b.ink}">${b.emblem}</text>`}
       <rect x="9" y="9" width="82" height="122" rx="4" fill="none" stroke="${b.ink}" stroke-opacity=".55"/>`;
  return `<svg viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="100" height="140" rx="7" fill="url(#bk-bg-${id})"/>
    <rect x="6" y="6" width="88" height="128" rx="5" fill="url(#bk-pat-${id})"/>
    <rect x="3" y="3" width="94" height="134" rx="6" fill="none" stroke="#fbf7ef" stroke-width="4"/>
    ${emblem}</svg>`;
}
