"use strict";
// Sabot local : on mélange directement les exemplaires de ton deck (plus aucune API).

const SUITS = ["S","H","D","C"], RANKS = ["A","2","3","4","5","6","7","8","9","0","J","Q","K"];
// « N » : les Nothing, une cinquième famille sans couleur, dont les enseignes sont des points noirs.
const NOTHING = "N";
const GLYPH = {S:"♠",H:"♥",D:"♦",C:"♣",N:"•"};
const SUITNAME = {S:"Pique",H:"Cœur",D:"Carreau",C:"Trèfle",N:"Nothing"};
const FULL = SUITS.flatMap(s => RANKS.map(r => r + s));
const NOTHINGS = RANKS.map(r => r + NOTHING);
const rnd = n => Math.floor(Math.random() * n);
const pickOne = a => a[rnd(a.length)];
const shuffled = a => { a = a.slice(); for(let i = a.length - 1; i > 0; i--){ const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };

let drawSeq = 0;
// Une carte cachée dans ta manche quitte le sabot tant qu'elle y reste.
const inSleeve = uid => S.sleeve.some(c => c.uid === uid);
const shoeCards = () => S.deck.filter(i => !inSleeve(i.uid));
// Chaque tirage est une copie de l'exemplaire, avec une clé unique pour l'animation.
const drawn = inst => ({...inst, key: "k" + (++drawSeq)});

class Shoe{
  constructor(){ this.pile = []; this.reshuffle(); }
  // Au milieu d'une main, les cartes déjà sur la table ne reviennent pas dans le sabot.
  reshuffle(){
    const onTable = new Set(H && H.hands ? [...H.hands.flatMap(h => h.cards), ...(H.d || [])].map(c => c.uid) : []);
    this.pile = shuffled(shoeCards().filter(i => !onTable.has(i.uid)));
    if(!this.pile.length) this.pile = shuffled(shoeCards());
  }
  draw(n){
    const out = [];
    while(out.length < n){ if(!this.pile.length) this.reshuffle(); out.push(drawn(this.pile.shift())); }
    return out;
  }
  peek(){ if(!this.pile.length) this.reshuffle(); return {...this.pile[0], key: "peek"}; }
  left(){ return this.pile.length; }
}
let shoe = null;
async function openShoe(){ shoe = new Shoe(); }
async function draw(n){ return shoe.draw(n); }
async function peekNext(){ return shoe ? shoe.peek() : null; }
