"use strict";
// Flammes WebGL derrière les cases Jetons, Mult et Dégâts.
// C'est le portage du shader Godot (canvas_item) fourni : même forme de flamme, même mélange
// à trois couleurs, même ondulation. Seule différence : la texture de bruit (noise_tex) est
// remplacée par un bruit procédural calculé dans le shader, pour ne dépendre d'aucune image.
// Si WebGL n'est pas disponible, les flammes CSS de styles.css prennent le relais.

const Fire = (() => {
  // Réglages, avec le nom de l'uniform Godot correspondant
  const CONFIG = {
    speed: [0.0, 0.62],        // fire_speed (réduit : le bruit est échantillonné 3 fois plus serré)
    apertureCold: 0.42,        // fire_aperture quand la case chauffe à peine (flammes basses)
    apertureHot: 0.12,         // fire_aperture à pleine chauffe (flammes hautes)
    alphaCold: 0.6,            // fire_alpha au minimum
    alphaHot: 1.0,             // fire_alpha à pleine chauffe
    heightMin: 40, heightMax: 140, // hauteur de la flamme en pixels selon la chaleur
    // Deux retouches absentes du shader Godot (mets 1 et 1 pour retrouver l'original exact) :
    contrast: 1.9,             // contraste du bruit : imite une texture de bruit bien tranchée
    tipSoftness: 7.0,          // pointes plus transparentes : évite le mélange terne bleu + orange
    taper: true,               // flamme plus étroite en haut qu'en bas
  };
  // bottom_color, middle_color, top_color du shader (les mêmes que dans ton fichier pour le mult)
  const PALETTES = {
    multBox:  {bottom:[0.0, 0.7, 1.0],  middle:[1.0, 0.5, 0.0],  top:[1.0, 0.03, 0.001]},
    chipsBox: {bottom:[0.8, 0.97, 1.0], middle:[0.35, 0.78, 1.0], top:[0.08, 0.4, 1.0]},
    dmgBox:   {bottom:[1.0, 0.97, 0.7], middle:[1.0, 0.72, 0.18], top:[0.85, 0.3, 0.02]},
  };

  const VERT = `attribute vec2 p; varying vec2 vUv;
    void main(){ vUv = p * 0.5 + 0.5; gl_Position = vec4(p, 0.0, 1.0); }`;

  const FRAG = `precision mediump float;
    varying vec2 vUv;
    uniform float uTime, uAlpha, uAperture, uSeed, uContrast, uTipSoftness, uTaper;
    uniform vec2 uSpeed;
    uniform vec3 uBottom, uMiddle, uTop;

    // Bruit de valeur lissé + fBm : remplace texture(noise_tex, ...)
    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
    float vnoise(vec2 p){
      vec2 i = floor(p), f = fract(p);
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                 mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
    }
    float fbm(vec2 p){
      float v = 0.0, a = 0.5;
      for(int k = 0; k < 4; k++){ v += a * vnoise(p); p *= 2.0; a *= 0.5; }
      return v / 0.9375; // ramène à [0, 1] comme une texture de bruit
    }
    // tri_color_mix du shader d'origine
    vec3 triColorMix(vec3 c1, vec3 c2, vec3 c3, float pos){
      pos = clamp(pos, 0.0, 1.0);
      return pos < 0.5 ? mix(c1, c2, pos * 2.0) : mix(c2, c3, (pos - 0.5) * 2.0);
    }
    void main(){
      vec2 uv = vec2(vUv.x, 1.0 - vUv.y);       // UV à la Godot : y = 0 en haut
      vec2 shifted1 = uv + uTime * uSpeed;
      vec2 shifted2 = uv + uTime * uSpeed * 1.5;
      float n1 = fbm(shifted1 * vec2(4.0, 3.0) + uSeed);
      float n2 = fbm(shifted2 * vec2(4.0, 3.0) + uSeed + 17.0);
      float combined = clamp(((n1 + n2) * 0.5 - 0.5) * uContrast + 0.5, 0.0, 1.0);
      float noise = uv.y * (((uv.y + uAperture) * combined - uAperture) * 75.0);
      noise += sin(uv.y * 10.0 + uTime * 2.0) * 0.1;
      float gradientPos = clamp(noise * 0.08, 0.3, 2.0);
      vec3 color = triColorMix(uBottom, uMiddle, uTop, gradientPos);
      float a = clamp(noise / uTipSoftness, 0.0, 1.0) * uAlpha;
      float edge = mix(0.2, mix(0.2, 0.42, 1.0 - uv.y), uTaper);   // resserre la flamme vers le haut
      a *= smoothstep(0.0, edge, uv.x) * smoothstep(1.0, 1.0 - edge, uv.x);
      gl_FragColor = vec4(color * a, a);        // alpha prémultiplié
    }`;

  const flames = {};
  let running = false;
  const t0 = performance.now();

  function compile(gl, type, src){
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if(!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  }
  function create(id){
    const box = document.getElementById(id);
    const cv = document.createElement("canvas");
    cv.className = "fire"; cv.width = 160; cv.height = 240; cv.setAttribute("aria-hidden", "true");
    let gl;
    try{ gl = cv.getContext("webgl", {premultipliedAlpha:true, alpha:true, antialias:false}); }catch(e){ gl = null; }
    if(!gl) return null;
    try{
      const prog = gl.createProgram();
      gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT));
      gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG));
      gl.linkProgram(prog);
      if(!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
      const p = gl.getAttribLocation(prog, "p");
      gl.enableVertexAttribArray(p); gl.vertexAttribPointer(p, 2, gl.FLOAT, false, 0, 0);
      const u = n => gl.getUniformLocation(prog, n);
      const loc = {time:u("uTime"), alpha:u("uAlpha"), aperture:u("uAperture"), seed:u("uSeed"), speed:u("uSpeed"), bottom:u("uBottom"), middle:u("uMiddle"), top:u("uTop")};
      gl.uniform1f(u("uContrast"), CONFIG.contrast); gl.uniform1f(u("uTipSoftness"), CONFIG.tipSoftness); gl.uniform1f(u("uTaper"), CONFIG.taper ? 1 : 0);
      const pal = PALETTES[id];
      gl.uniform3fv(loc.bottom, pal.bottom); gl.uniform3fv(loc.middle, pal.middle); gl.uniform3fv(loc.top, pal.top);
      gl.uniform2fv(loc.speed, CONFIG.speed); gl.uniform1f(loc.seed, Math.random() * 40);
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      box.prepend(cv); box.classList.add("gl");
      return {box, cv, gl, loc, heat:0};
    }catch(e){ console.warn("Flammes WebGL indisponibles :", e); return null; }
  }
  function draw(f, t){
    const {gl, loc, heat} = f;
    gl.viewport(0, 0, f.cv.width, f.cv.height);
    gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(loc.time, t);
    gl.uniform1f(loc.alpha, CONFIG.alphaCold + (CONFIG.alphaHot - CONFIG.alphaCold) * heat);
    gl.uniform1f(loc.aperture, CONFIG.apertureCold + (CONFIG.apertureHot - CONFIG.apertureCold) * heat);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
  function frame(now){
    const t = (now - t0) / 1000;
    let any = false;
    for(const f of Object.values(flames)) if(f && f.heat > 0){ any = true; draw(f, t); }
    // Avec « réduire les animations », une seule image fixe ; sinon on anime tant qu'une case chauffe
    if(any && !reduced()) requestAnimationFrame(frame);
    else running = false;
  }
  function set(id, heat){
    if(!PALETTES[id]) return;
    let f = flames[id];
    if(f === undefined){ if(heat <= 0) return; f = flames[id] = create(id); }
    if(!f) return; // pas de WebGL : les flammes CSS s'en chargent
    f.heat = heat;
    f.box.style.setProperty("--fh", Math.round(CONFIG.heightMin + (CONFIG.heightMax - CONFIG.heightMin) * heat) + "px");
    f.cv.classList.toggle("on", heat > 0);
    if(heat > 0 && !running){ running = true; requestAnimationFrame(frame); }
  }
  return {set, CONFIG, PALETTES};
})();
