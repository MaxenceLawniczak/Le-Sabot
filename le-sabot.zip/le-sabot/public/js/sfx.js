"use strict";
// Bruitages synthétisés à la volée avec l'API audio du navigateur : aucun fichier son à charger.
// Le volume se règle dans les Options (SETTINGS.volume, de 0 à 1).

const Sfx = (() => {
  let ctx = null, master = null;
  const last = {};
  function ensure(){
    if(ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if(!AC) return null;
    ctx = new AC(); master = ctx.createGain(); master.connect(ctx.destination);
    return ctx;
  }
  // Le navigateur n'autorise le son qu'après un geste de l'utilisateur
  const unlock = () => { const c = ensure(); if(c && c.state === "suspended") c.resume(); };
  window.addEventListener("pointerdown", unlock, {passive:true});
  window.addEventListener("keydown", unlock);

  function tone({freq = 440, to = null, dur = .12, type = "sine", vol = .3, delay = 0, attack = .005}){
    const c = ctx, t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if(to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + .02);
  }
  function noise({dur = .08, vol = .25, freq = 2500, q = 1, delay = 0}){
    const c = ctx, t = c.currentTime + delay;
    const buf = c.createBuffer(1, Math.ceil(c.sampleRate * dur), c.sampleRate), d = buf.getChannelData(0);
    for(let i = 0; i < d.length; i++) d[i] = (uiRand() * 2 - 1) * (1 - i / d.length);
    const src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = buf; f.type = "bandpass"; f.frequency.value = freq; f.Q.value = q; g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(master); src.start(t);
  }
  const SOUNDS = {
    card:  () => noise({dur:.07, vol:.35, freq:3200, q:.8}),
    click: () => tone({freq:900, to:700, dur:.05, type:"triangle", vol:.12}),
    chip:  (i = 0) => tone({freq:520 * Math.pow(1.06, Math.min(i, 24)), dur:.09, type:"triangle", vol:.22}),
    mult:  (i = 0) => { tone({freq:260 * Math.pow(1.06, Math.min(i, 20)), dur:.14, type:"sawtooth", vol:.12}); tone({freq:390 * Math.pow(1.06, Math.min(i, 20)), dur:.12, type:"triangle", vol:.1}); },
    coin:  () => { tone({freq:1320, dur:.08, type:"square", vol:.08}); tone({freq:1760, dur:.18, type:"square", vol:.08, delay:.06}); },
    hit:   (p = 1) => { tone({freq:180, to:60, dur:.35, type:"sine", vol:.5 * Math.min(1.5, p)}); noise({dur:.25, vol:.3 * Math.min(1.5, p), freq:600, q:.6}); },
    hurt:  () => { tone({freq:220, to:110, dur:.25, type:"square", vol:.1}); noise({dur:.12, vol:.15, freq:900}); },
    win:   () => [523, 659, 784, 1047].forEach((f, i) => tone({freq:f, dur:.22, type:"triangle", vol:.18, delay:i * .08})),
    lose:  () => [392, 330, 262, 196].forEach((f, i) => tone({freq:f, dur:.3, type:"sawtooth", vol:.08, delay:i * .14})),
    pack:  () => { noise({dur:.18, vol:.2, freq:1800, q:.5}); tone({freq:600, to:1200, dur:.2, type:"sine", vol:.12, delay:.05}); },
    achieve: () => [784, 988, 1175, 1568].forEach((f, i) => tone({freq:f, dur:.3, type:"sine", vol:.16, delay:i * .09})),
    burn:  () => noise({dur:.35, vol:.25, freq:900, q:.4}),
  };
  function play(name, ...args){
    const vol = SETTINGS.volume ?? .6;
    if(!vol || !SOUNDS[name]) return;
    const c = ensure(); if(!c || c.state !== "running") return;
    // Pas plus d'un même son toutes les 35 ms (évite la bouillie sonore des distributions rapides)
    const now = performance.now(); if(now - (last[name] || 0) < 35) return; last[name] = now;
    master.gain.value = vol;
    try{ SOUNDS[name](...args); }catch(e){}
  }
  return {play};
})();
const sfx = (name, ...args) => Sfx.play(name, ...args);
// Un petit clic sur tous les boutons du jeu
document.addEventListener("click", e => { if(e.target.closest("button, .deckopt")) sfx("click"); });
