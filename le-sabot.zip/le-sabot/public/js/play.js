"use strict";
// Déroulé d'une main : déclencheurs, actions, manche, clous, calcul du score, résolution solo.

/* ======================================================================
   Déclencheurs de charmes hors calcul (saut, double, split, défaite, égalité)
   ====================================================================== */
function fire(hook, ...args){
  const notes = []; let dmg = 0;
  for(const [i, st] of S.charms.entries()){
    if(charmMuted(i)) continue;
    const fn = CHARMS[st.id][hook]; if(!fn) continue;
    const r = fn(st, ...args) || {};
    flash(st.id);
    const parts = [];
    if(r.gold){ S.gold += r.gold; parts.push(`+${r.gold} or`); }
    if(r.heal){ const h = Math.min(r.heal, S.maxHp - S.hp); S.hp += h; parts.push(`+${h} PV`); }
    if(r.burn){ T.burns += r.burn; parts.push(`+${r.burn} brûlage`); }
    if(r.dmg){ dmg += r.dmg; parts.push(`${r.dmg} dégâts`); }
    if(r.note) parts.push(r.note);
    if(parts.length) notes.push(`${CHARMS[st.id].name} : ${parts.join(", ")}`);
  }
  if(notes.length) $("steps").textContent = notes.join(" · ");
  renderCharms(); renderHud();
  return dmg;
}

/* ======================================================================
   Déroulé d'une main (commun solo et duel)
   ====================================================================== */
async function deal(){
  if(busy) return;
  if(MODE === "duel") return duelDeal();
  busy = true;
  H = {hands:[newHand()], cur:0, d:[], phase:"deal"};
  T.hands = (T.hands || 0) + 1;
  setBoxes(0, 0, 0); $("steps").textContent = ""; setMsg("");
  if(T.foe.mod === "poison"){ S.hp -= 2; renderHud(); $("steps").textContent = "Le poison te coûte 2 PV."; if(S.hp <= 0){ busy = false; H.phase = "over"; gameOver(); return; } }
  renderActions();
  try{
    if(shoe.left() < 12){ shoe.reshuffle(); setMsg("Le sabot est remélangé."); }
    const cs = await draw(4);
    for(const [who, c] of [["p",cs[0]],["d",cs[1]],["p",cs[2]],["d",cs[3]]]){
      if(who === "p") giveP(H.hands[0], c); else H.d.push(c);
      renderHands(); await wait(170);
    }
    const h = H.hands[0];
    if(isNatural(h) || dNatural()){
      H.phase = "dealer"; renderHands(); await wait(300);
      if(isNatural(h) && dNatural()) await settle(h, "push", "Deux blackjacks. Égalité.");
      else if(isNatural(h)) await settle(h, "win", "Blackjack !");
      else await settle(h, "lose", "Le croupier a un blackjack.");
      endOfHands();
    } else {
      H.phase = "player"; renderHands();
    }
  } finally { busy = false; if(H.phase === "player") renderHands(); renderActions(); renderPeek(); }
}
function giveP(h, c){
  h.cards.push(c);
  if(isSp(c)) stat("special", {id: c.sp});
  if(isSp(c) && SPECIALS[c.sp].draw){
    const e = SPECIALS[c.sp].draw, bits = [];
    if(e.gold){ S.gold += e.gold; bits.push(`+${e.gold} or`); }
    if(e.hurt){ S.hp -= e.hurt; bits.push(`−${e.hurt} PV`); }
    $("steps").textContent = `${SPECIALS[c.sp].name} : ${bits.join(", ")}`;
    renderHud(); sendState();
  }
}
async function act(fn){
  if(busy || H.phase !== "player") return;
  busy = true; renderActions();
  try{ await fn(); } finally { busy = false; if(H.phase === "player") renderHands(); renderActions(); renderPeek(); }
}
const hit = () => act(async () => {
  const h = cur(); H.sel = null; const [c] = await draw(1); giveP(h, c); renderHands();
  await afterCard(h);
});
const stand = () => act(async () => { cur().state = "stand"; await nextHand(); });
const dbl = () => act(async () => {
  const h = cur(); if(h.cards.length !== 2 || h.burned) return;
  h.doubled = true; setMsg("Tu doubles : une seule carte pour cette main.");
  fire("onDouble", h);
  H.sel = null; const [c] = await draw(1); giveP(h, c); renderHands(); await wait(250);
  if(hTotal(h) > limit()) await afterCard(h); else { h.state = "stand"; await nextHand(); }
});
const split = () => act(async () => {
  if(!canSplit()) return;
  const [a, b] = cur().cards;
  H.hands = [newHand([a], true), newHand([b], true)];
  setMsg(`Tu sépares ${cardName(a)} et ${cardName(b)}.`);
  fire("onSplit");
  renderHands(); await wait(200);
  const [c1, c2] = await draw(2);
  H.sel = null;
  giveP(H.hands[0], c1); renderHands(); await wait(170);
  giveP(H.hands[1], c2); renderHands(); await wait(170);
  H.cur = 0;
  if(hTotal(H.hands[0]) === limit()){ H.hands[0].state = "stand"; await nextHand(); }
});
const burn = () => act(async () => {
  const h = cur(); if(T.burns <= 0 || h.cards.length < 2) return;
  const c = h.cards.pop(); T.burns--; h.burned++; H.sel = null; sfx("burn");
  fire("onBurn", c);
  if(c.sp === "phenix" && S.sleeve.length < sleeveCap()){ const {key, fromSleeve, ...kept} = c; S.sleeve.push({...kept, key: "s" + (++drawSeq)}); setMsg("Le Phénix renaît de ses cendres, dans ta manche."); return; }
  setMsg(`${cardName(c)} part en fumée.`);
  renderHands();
});
// La manche : on y glisse une carte de la main, on la ressort dans une main plus tard
const hide = () => act(async () => {
  if(!canHide()) return;
  const h = cur();
  const j = (H.sel != null && H.sel < h.cards.length) ? H.sel : h.cards.length - 1;
  const [c] = h.cards.splice(j, 1);
  const {key, fromSleeve, ...kept} = c;
  S.sleeve.push({...kept, key: "s" + (++drawSeq)});
  h.tricked = true; H.hidUsed = true; H.sel = null;
  setMsg(`${cardName(c)} disparaît dans ta manche.`);
  fire("onHide", c);
  renderHands(); sendLive();
  if(hTotal(h) === limit()){ h.state = "stand"; await nextHand(); }
});
function resurface(i){
  if(!canResurface()) return;
  act(async () => {
    const h = cur();
    const [c] = S.sleeve.splice(i, 1);
    h.cards.push({...c, key: "k" + (++drawSeq), fromSleeve: true});
    h.tricked = true; H.outUsed = true; H.sel = null;
    setMsg(`Tu ressors ${cardName(c)} de ta manche.`);
    renderHands(); sendLive();
    await afterCard(h);
  });
}
// Contrepoids : une carte négative créée juste assez forte pour revenir pile à la limite.
async function counterweight(h, t){
  const need = Math.min(10, t - limit());
  const last = [...h.cards].reverse().find(c => !isSp(c));
  const suit = last ? suitOf(last) : pickOne(SUITS);
  const rank = need === 1 ? "A" : need === 10 ? "0" : String(need);
  const created = inst(rank + suit, null, null, null, true);
  S.deck.push(created);
  h.cards.push(drawn(created));
  T.cpUsed = true; flash("contrepoids");
  setMsg(`Contrepoids : un ${cardName(created)} surgit et rejoint ton deck.`, "good");
  renderHands(); renderHud(); sendLive();
  await wait(500);
}
async function afterCard(h){
  let t = hTotal(h);
  if(t > limit() && has("contrepoids") && !T.cpUsed){ await counterweight(h, t); t = hTotal(h); }
  if(t > limit()){
    if(has("filet") && !T.netUsed){ T.netUsed = true; h.state = "saved"; flash("filet"); setMsg("Le filet de sécurité te rattrape : égalité.", "good"); }
    else {
      h.state = "bust"; setMsg(`Tu sautes avec ${t}.`, "bad");
      h.kami = fire("onBust", h, t);
    }
    renderHands(); await wait(350);
    await nextHand();
  } else if(t === limit()){
    h.state = "stand"; await nextHand();
  }
}
async function nextHand(){
  const i = H.hands.findIndex(h => h.state === "play");
  if(i >= 0){ H.cur = i; renderHands(); return; }
  if(MODE === "duel") return duelSubmit();
  await dealerPlay();
}
async function dealerPlay(){
  H.phase = "dealer"; renderHands(); await wait(350);
  const anyAlive = H.hands.some(h => h.state === "stand");
  const standOn = T.foe.mod === "fer" ? 18 : 17;
  const best = Math.max(0, ...H.hands.filter(h => h.state === "stand").map(hTotal));
  const target = () => T.foe.mod === "malin" ? Math.max(standOn, Math.min(21, best)) : standOn;
  if(anyAlive) while(dTotal() < target()){ const [c] = await draw(1); H.d.push(c); renderHands(); await wait(330); }
  if(await plantNails()){
    T.foe.hp = 0; renderFoe();
    setMsg(`Le cercueil se referme sur ${T.foe.name}.`, "good");
    await wait(900); endOfHands(); return;
  }
  const d = dTotal(), bust = d > 21;
  for(let i = 0; i < H.hands.length; i++){
    const h = H.hands[i]; H.cur = i;
    const lab = H.hands.length > 1 ? `Main ${i + 1} : ` : "";
    const p = hTotal(h);
    if(h.state === "saved") await settle(h, "push", lab + "rattrapée par le filet.");
    else if(h.state === "bust") await settle(h, "lose", lab + `sautée à ${p}.`);
    else if(bust) await settle(h, "win", lab + `le croupier saute avec ${d} !`, {foeBust:true});
    else if(p > d) await settle(h, "win", lab + `${p} contre ${d}.`);
    else if(p < d) await settle(h, "lose", lab + `${d} contre ${p}.`);
    else await settle(h, "push", lab + `${p} partout.`);
    if(T.foe.hp <= 0 || S.hp <= 0) break;
    if(i < H.hands.length - 1) await wait(500);
  }
  endOfHands();
}
// Les clous restés dans tes mains à la fin d'une main sont plantés pour la table.
async function plantNails(){
  const before = T.nails.size;
  for(const h of H.hands) for(const c of h.cards) if(isSp(c) && SPECIALS[c.sp].nail) T.nails.add(SPECIALS[c.sp].nail);
  renderNails();
  if(T.nails.size > before && T.nails.size < 5){
    $("steps").textContent = `Clou planté : ${T.nails.size} sur 5.`;
    await wait(500);
  }
  if(T.nails.size === 5 && !T.coffin){ T.coffin = true; stat("coffin"); return true; }
  return false;
}
async function endOfHands(){
  H.phase = "done"; renderHands(); renderActions();
  if(T.foe.hp > 0 && S.hp > 0) saveRun("table");
  if(T.foe.hp <= 0){ H.phase = "over"; renderActions(); await wait(700); tableWon(); }
  else if(S.hp <= 0){ H.phase = "over"; renderActions(); await wait(700); gameOver(); }
}

/* ---------- calcul d'une main gagnante ---------- */
function scoreHand(h, ctx){
  const total = hTotal(h), steps = [];
  const off = h.cards.filter(disabled);
  const cards = h.cards.filter(c => !disabled(c)); // ce que voient les améliorations et les charmes
  const mod = MODE === "solo" && T.foe ? T.foe.mod : null;
  // Cartes à chiffres : leur valeur part dans le mult au lieu des jetons (Numérologue : dans les deux)
  const vals = cardValues(h.cards, limit());
  const numMult = h.cards.reduce((a, c, i) => a + (c.num && !disabled(c) ? Math.max(0, vals[i]) : 0), 0);
  let chips = Math.max(0, total - (has("numerologue") ? 0 : numMult)), mult = 1 + numMult;
  const x = {...ctx, total, doubled:h.doubled, split:h.fromSplit, natural:isNatural(h)};
  steps.push({text:`Total de la main : ${total}` + (numMult ? ` · enseignes de valeur : +${numMult} mult` : " jetons"), chips, mult, base:true});
  if(off.length){
    const lost = off.reduce((a, c) => a + Math.max(0, pts(c)), 0);
    chips = Math.max(0, chips - lost);
    steps.push({text:`${off.map(cardName).join(" ")} désactivée${off.length > 1 ? "s" : ""} : −${lost} jetons`, chips, mult});
  }
  const broken = []; let gold = 0, heal = 0;
  const E = has("prismatique") ? 2 : 1; // Prismatique : les éditions des cartes comptent double
  const enhOn = mod !== "casse", edOn = mod !== "gel";
  for(const c of cards){
    const lab = cardName(c);
    const st = (text, pop, popKind) => steps.push({text:`${lab} ${text}`, chips, mult, card:c.key, pop, popKind});
    if(enhOn && c.enh === "grave"){ const v = has("graveur") ? 30 : 15; chips += v; st(`gravée : +${v} jetons`, "+" + v, "chips"); }
    if(enhOn && c.enh === "rouge"){ const v = has("lapidaire") ? 8 : 4; mult += v; st(`rubis : +${v} mult`, `+${v} mult`, "mult"); }
    if(enhOn && c.enh === "or"){ const v = has("fauxmonnayeur") ? 5 : 2; gold += v; st(`dorée : +${v} or`, `+${v} or`, "gold"); }
    if(enhOn && c.enh === "verre"){ mult *= 1.5; st("de verre : ×1,5 mult", "×1,5", "mult"); if(!has("verrier") && Math.random() < .25 && c.uid > 0) broken.push(c.uid); }
    if(isSp(c) && SPECIALS[c.sp].score){
      const e = SPECIALS[c.sp].score;
      if(e.chips){ chips += e.chips; st(`: +${e.chips} jetons`, "+" + e.chips, "chips"); }
      if(e.chipsPer){ const v = e.chipsPer * h.cards.length; chips += v; st(`: +${v} jetons`, "+" + v, "chips"); }
      if(e.mult){ mult += e.mult; st(`: +${e.mult} mult`, `+${e.mult} mult`, "mult"); }
      if(e.goldPer){ const v = e.goldPer * h.cards.length; gold += v; st(`: +${v} or`, `+${v} or`, "gold"); }
      if(e.xmult){ mult *= e.xmult; st(`: ×${e.xmult} mult`, "×" + e.xmult, "mult"); }
      if(e.heal) heal += e.heal;
    }
    if(edOn && c.ed === "foil"){ chips += 25 * E; st(`foil : +${25 * E} jetons`, "+" + 25 * E, "chips"); }
    if(edOn && c.ed === "holo"){ mult += 6 * E; st(`holographique : +${6 * E} mult`, `+${6 * E} mult`, "mult"); }
    if(edOn && c.ed === "poly"){ const k = E === 2 ? 2.25 : 1.5; mult *= k; st(`polychrome : ×${String(k).replace(".", ",")} mult`, "×" + String(k).replace(".", ","), "mult"); }
  }
  if(isNatural(h)){ mult *= 2; steps.push({text:"Blackjack naturel : ×2 mult", chips, mult}); }
  else if(total === limit()){ mult += 1; steps.push({text:`${limit()} pile : +1 mult`, chips, mult}); }
  const deck = deckDef();
  if(deck.chips){ chips += deck.chips; steps.push({text:`${deck.name} : +${deck.chips} jetons`, chips, mult}); }
  if(deck.mult){ mult += deck.mult; steps.push({text:`${deck.name} : +${deck.mult} mult`, chips, mult}); }
  const apply = (r, name, id) => {
    if(!r) return;
    if(r.chips) chips += r.chips;
    if(r.mult) mult += r.mult;
    if(r.xmult) mult *= r.xmult;
    const parts = [r.chips && `+${r.chips} jetons`, r.mult && `+${r.mult} mult`, r.xmult && `×${String(r.xmult).replace(".", ",")} mult`].filter(Boolean).join(", ");
    if(parts) steps.push({text:`${name} : ${parts}`, chips, mult, charm:id});
  };
  S.charms.forEach((st, i) => {
    if(charmMuted(i)) return; // Le Mime fait taire ton premier charme
    const fn = CHARMS[st.id].score;
    apply(fn ? fn(cards, x, st) : null, CHARMS[st.id].name, st.id);
    // Photocopieuse : reproduit le calcul du charme placé juste après elle
    if(st.id === "photocopie"){
      const next = S.charms[i + 1];
      if(next && CHARMS[next.id].score) apply(CHARMS[next.id].score(cards, x, next), `Photocopieuse (${CHARMS[next.id].name})`, st.id);
    }
    // Édition du charme : s'applique à son passage, même s'il ne s'est pas déclenché
    if(st.ed === "foil"){ chips += 25; steps.push({text:`${CHARMS[st.id].name} foil : +25 jetons`, chips, mult, charm:st.id}); }
    if(st.ed === "holo"){ mult += 6; steps.push({text:`${CHARMS[st.id].name} holo : +6 mult`, chips, mult, charm:st.id}); }
    if(st.ed === "poly"){ mult *= 1.5; steps.push({text:`${CHARMS[st.id].name} poly : ×1,5 mult`, chips, mult, charm:st.id}); }
  });
  if(h.doubled){ const k = has("doubleur") ? 3 : 2; mult *= k; steps.push({text:`Mise doublée : ×${k} mult`, chips, mult, charm: has("doubleur") ? "doubleur" : null}); }
  return {chips, mult, dmg: Math.round(chips * mult), steps, broken, gold, heal};
}
async function animateScore(s, h = null){
  for(const st of s.steps){
    if(st.base && h){
      // Comme au comptoir : chaque carte tressaute et annonce ce qu'elle rapporte
      const vals = cardValues(h.cards, limit());
      let run = 0, runMult = 1;
      setBoxes(0, 1, "…"); $("steps").textContent = st.text;
      for(let i = 0; i < h.cards.length; i++){
        const c = h.cards[i], el = cardNode(c.key);
        if(disabled(c)){ run += vals[i]; jiggle(el); floatText(el, "désactivée", "off"); setBoxes(Math.max(0, run), runMult, "…"); await wait(220); continue; }
        if(c.num){
          runMult += Math.max(0, vals[i]); if(has("numerologue")) run += vals[i];
          jiggle(el); floatText(el, `+${vals[i]} mult`, "mult"); sfx("mult", i);
          setBoxes(Math.max(0, run), runMult, "…"); pop("multBox");
        } else {
          run += vals[i];
          jiggle(el); floatText(el, (vals[i] >= 0 ? "+" : "") + vals[i], vals[i] < 0 ? "neg" : "chips"); sfx("chip", i);
          setBoxes(Math.max(0, run), runMult, "…"); pop("chipsBox");
        }
        await wait(260);
      }
      setBoxes(st.chips, st.mult, "…");
      continue;
    }
    setBoxes(st.chips, st.mult, "…"); $("steps").textContent = st.text;
    pop("chipsBox"); pop("multBox");
    if(st.charm) flash(st.charm);
    sfx(st.popKind === "mult" || /mult/.test(st.text) ? "mult" : "chip", s.steps.indexOf(st) + 4);
    if(st.card){ const el = cardNode(st.card); jiggle(el); if(st.pop) floatText(el, st.pop, st.popKind); }
    await wait(st.card || st.charm ? 430 : 380);
  }
  setBoxes(s.chips, s.mult, 0);
  await countUp($("dmgBox").lastChild, s.dmg);
  sfx("hit", s.dmg >= 500 ? 1.5 : s.dmg >= 100 ? 1 : .6);
  heatBox("dmgBox", s.dmg >= 60 ? Math.min(1, Math.log10(s.dmg / 60) / 1.3 + .25) : 0);
  pop("dmgBox");
  if(s.dmg >= 150) quake(Math.min(3, s.dmg / 300 + 1));
}
// Effets d'après victoire communs (or, soin, verre brisé, remise à zéro de Rancune)
function winExtras(h, s){
  const extra = [];
  S.gold += 1; extra.push("+1 or");
  if(s.gold){ S.gold += s.gold; extra.push(`+${s.gold} or`); }
  if(s.heal){ const v = Math.min(s.heal, S.maxHp - S.hp); S.hp += v; if(v) extra.push(`+${v} PV (sangsue)`); }
  if(has("banquier")){ S.gold += 1; extra.push("+1 or"); flash("banquier"); }
  if(has("vampire")){ const v = Math.min(4, S.maxHp - S.hp); S.hp += v; if(v) extra.push(`+${v} PV`); flash("vampire"); }
  if(s.broken.length){
    S.deck = S.deck.filter(i => !s.broken.includes(i.uid));
    extra.push(s.broken.length > 1 ? "des cartes de verre se brisent" : "une carte de verre se brise");
  }
  for(const st of S.charms) if(CHARMS[st.id].afterWin) CHARMS[st.id].afterWin(st);
  T.wins++;
  if(MODE === "solo") S.dmgTotal = (S.dmgTotal || 0) + s.dmg;
  stat("hand", {dmg: s.dmg, natural: isNatural(h)}); stat("gold", {gold: S.gold});
  return extra;
}

/* ---------- résolution en solo ---------- */
async function settle(h, result, text, ctx = {}){
  h.result = result; renderHands();
  if(result === "win"){
    setMsg(text, "good");
    const s = scoreHand(h, ctx);
    await animateScore(s, h);
    T.foe.hp -= s.dmg;
    const f = $("foe"); f.classList.remove("hit"); void f.offsetWidth; f.classList.add("hit");
    const extra = winExtras(h, s);
    $("steps").textContent = `${s.dmg} dégâts infligés` + (extra.length ? " · " + extra.join(", ") : "");
  } else if(result === "push"){
    setMsg(text); setBoxes(0, 0, 0);
    fire("onPush");
  } else {
    let dmg = h.state === "bust" ? 8 : dNatural() ? 12 : (dTotal() - hTotal(h)) + 4;
    const why = [];
    if(h.doubled){ dmg *= 2; why.push("mise doublée ×2"); }
    if(T.foe.mod === "gorge"){ dmg *= 2; why.push("coupe-gorge ×2"); }
    if(has("carapace")){ dmg = Math.max(1, dmg - 3); why.push("carapace −3"); flash("carapace"); }
    S.hp -= dmg;
    quake(dmg >= 15 ? 1.4 : .7); sfx("hurt");
    setMsg(`${text} Tu perds ${dmg} PV.`, "bad");
    setBoxes(0, 0, 0);
    fire("onLose", h);
    if(h.kami){ T.foe.hp -= h.kami; why.push(`Kamikaze : ${h.kami} dégâts au croupier`); }
    if(T.foe.mod === "carmin"){ const v = Math.min(T.foe.maxHp - T.foe.hp, Math.round(T.foe.maxHp * .1)); T.foe.hp += v; if(v) why.push(`${T.foe.name} se soigne de ${v} PV`); }
    if(T.foe.mod === "taxe" && S.gold > 0){ const v = Math.min(2, S.gold); S.gold -= v; why.push(`le Percepteur prend ${v} or`); }
    $("steps").textContent = why.join(" · ");
  }
  renderFoe(); renderHud(); renderCharms();
  await wait(300);
}
