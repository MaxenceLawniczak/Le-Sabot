"use strict";
// Sauvegarde de la partie solo en cours, statistiques et succès, dans le stockage du navigateur.

/* ======================================================================
   Sauvegarde : entre deux mains, au début d'une table et en boutique
   ====================================================================== */
const SAVE_KEY = "sabot:run";
function saveRun(at = "table"){
  if(MODE !== "solo" || !S || !T || !T.foe || !T.foe.maxHp || S.hp <= 0) return;
  try{
    const t = {...T, nails: [...(T.nails || [])]};
    localStorage.setItem(SAVE_KEY, JSON.stringify({v:1, at, S, T:t, daily: DAILY.active ? {date: DAILY.date, rng: DAILY.state} : null, savedAt: Date.now()}));
  }catch(e){}
}
function loadRun(){ try{ const r = JSON.parse(localStorage.getItem(SAVE_KEY) || "null"); return r && r.v === 1 ? r : null; }catch(e){ return null; } }
function clearRun(){ try{ localStorage.removeItem(SAVE_KEY); }catch(e){} }
async function continueRun(){
  const r = loadRun(); if(!r) return;
  netClose(); MODE = "solo"; O = null;
  S = r.S; T = {...r.T, nails: new Set(r.T.nails || [])};
  uidSeq = Math.max(uidSeq, ...S.deck.map(c => c.uid || 0), 0);
  if(r.daily) resumeDaily(r.daily); else stopDaily();
  H = {hands:[], cur:0, d:[], phase:"idle"};
  showGame(); refreshAll();
  await openShoe();
  if(r.at === "shop"){ openShop(true); return; }
  setMsg(`Partie reprise : ${T.foe.name}, ${Math.max(0, T.foe.hp)} PV restants.`);
  renderHud(); renderActions();
}

/* ======================================================================
   Statistiques
   ====================================================================== */
const STATS = (() => {
  let s = {};
  try{ s = JSON.parse(localStorage.getItem("sabot:stats") || "{}"); }catch(e){}
  return Object.assign({runs:0, wins:0, bestAnte:1, bestHit:0, handsWon:0, totalDmg:0, bosses:[], charms:[], specials:[], decksWon:[], achievements:[]}, s);
})();
function saveStats(){ try{ localStorage.setItem("sabot:stats", JSON.stringify(STATS)); }catch(e){} }
const addUnique = (arr, v) => { if(v && !arr.includes(v)){ arr.push(v); return true; } return false; };
// Événements de la partie : chaque appel met à jour les stats puis vérifie les succès
function stat(event, data = {}){
  if(MODE !== "solo" && !["hand", "charm", "special"].includes(event)) return;
  switch(event){
    case "run":     STATS.runs++; break;
    case "hand":    STATS.handsWon++; STATS.bestHit = Math.max(STATS.bestHit, data.dmg || 0); STATS.totalDmg += data.dmg || 0; break;
    case "table":   STATS.bestAnte = Math.max(STATS.bestAnte, S.ante); if(data.boss) addUnique(STATS.bosses, data.boss); break;
    case "victory": STATS.wins++; addUnique(STATS.decksWon, S.deckId); break;
    case "charm":   addUnique(STATS.charms, data.id); break;
    case "special": addUnique(STATS.specials, data.id); break;
  }
  saveStats();
  checkAchievements(event, data);
}

/* ======================================================================
   Succès
   ====================================================================== */
const ACHIEVEMENTS = [
  {id:"premiere",  ico:"🂡", name:"Première main", desc:"Gagner une main.", test:() => STATS.handsWon >= 1},
  {id:"blackjack", ico:"🃏", name:"Blackjack !", desc:"Gagner avec un blackjack naturel.", test:(e, d) => e === "hand" && d.natural},
  {id:"massue",    ico:"🔨", name:"Coup de massue", desc:"Infliger 1 000 dégâts en une main.", test:() => STATS.bestHit >= 1000},
  {id:"seisme",    ico:"🌋", name:"Séisme", desc:"Infliger 10 000 dégâts en une main.", test:() => STATS.bestHit >= 10000},
  {id:"cent-mains",ico:"💯", name:"Habitué du tapis", desc:"Gagner 100 mains au total.", test:() => STATS.handsWon >= 100},
  {id:"patron",    ico:"👑", name:"Tombeur de patron", desc:"Battre un patron.", test:() => STATS.bosses.length >= 1},
  {id:"chasseur",  ico:"🎯", name:"Chasseur de patrons", desc:"Battre 10 patrons différents.", test:() => STATS.bosses.length >= 10},
  {id:"tous",      ico:"🏆", name:"Plus aucun patron", desc:"Battre les 21 patrons.", test:() => STATS.bosses.length >= BOSSES.length},
  {id:"ante3",     ico:"🪜", name:"Dernier étage", desc:"Atteindre l'ante 3.", test:() => STATS.bestAnte >= 3},
  {id:"victoire",  ico:"🥇", name:"Sauté, le patron", desc:"Terminer une partie en solo.", test:() => STATS.wins >= 1},
  {id:"chiffre",   ico:"🔢", name:"Tout en chiffres", desc:"Gagner une partie avec le deck chiffré.", test:() => STATS.decksWon.includes("chiffre")},
  {id:"cinq-decks",ico:"🎴", name:"Joueur polyvalent", desc:"Gagner une partie avec 5 decks différents.", test:() => STATS.decksWon.length >= 5},
  {id:"cercueil",  ico:"⚰️", name:"Enterré vivant", desc:"Refermer le cercueil sur un adversaire.", test:(e) => e === "coffin"},
  {id:"riche",     ico:"💰", name:"Crésus", desc:"Avoir 100 or en poche.", test:(e, d) => e === "gold" && d.gold >= 100},
  {id:"legende",   ico:"✨", name:"Légende", desc:"Posséder un charme légendaire.", test:(e, d) => e === "charm" && CHARMS[d.id] && CHARMS[d.id].rarity === "legendaire"},
  {id:"collection",ico:"📚", name:"Collectionneur", desc:"Obtenir 40 charmes différents.", test:() => STATS.charms.length >= 40},
  {id:"survivant", ico:"🩹", name:"Sur le fil", desc:"Gagner une table avec 5 PV ou moins.", test:(e) => e === "table" && S.hp <= 5},
  {id:"quotidien", ico:"📅", name:"Rendez-vous quotidien", desc:"Terminer un défi du jour.", test:(e) => e === "daily"},
];
function checkAchievements(event, data){
  for(const a of ACHIEVEMENTS){
    if(STATS.achievements.includes(a.id)) continue;
    let ok = false; try{ ok = a.test(event, data); }catch(e){}
    if(ok){ STATS.achievements.push(a.id); saveStats(); toast(`${a.ico} Succès : ${a.name}`, a.desc); sfx("achieve"); }
  }
}
// Petit bandeau qui glisse en haut de l'écran
function toast(title, text = ""){
  const t = document.createElement("div");
  t.className = "toast"; t.setAttribute("role", "status");
  t.innerHTML = `<b>${esc(title)}</b>${text ? `<span>${esc(text)}</span>` : ""}`;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add("out"), 3200);
  setTimeout(() => t.remove(), 3700);
}
function openStats(back = null){
  const done = STATS.achievements.length;
  const row = (label, v) => `<tr><td>${label}</td><td>${v}</td></tr>`;
  openModal(`<div class="chead"><h2>Succès et statistiques</h2><button class="btn" id="stBack">Fermer</button></div>
    <table class="ledger statsgrid">
      ${row("Parties jouées", STATS.runs)}${row("Parties gagnées", STATS.wins)}${row("Meilleure ante", STATS.bestAnte)}
      ${row("Mains gagnées", STATS.handsWon)}${row("Plus gros coup", STATS.bestHit.toLocaleString("fr-FR"))}${row("Dégâts infligés au total", STATS.totalDmg.toLocaleString("fr-FR"))}
      ${row("Patrons battus", `${STATS.bosses.length} / ${BOSSES.length}`)}${row("Charmes obtenus", `${STATS.charms.length} / ${Object.keys(CHARMS).length}`)}
    </table>
    <h3>Succès (${done} / ${ACHIEVEMENTS.length})</h3>
    <div class="achs">${ACHIEVEMENTS.map(a => { const ok = STATS.achievements.includes(a.id);
      return `<div class="ach${ok ? " on" : ""}"><span class="aico" aria-hidden="true">${ok ? a.ico : "🔒"}</span><span><b>${a.name}</b><em>${a.desc}</em></span></div>`; }).join("")}</div>`, "stats");
  $("stBack").onclick = () => back ? back() : closeModal();
}
