"use strict";
// Contenu du jeu : cartes spéciales, améliorations, éditions, charmes, adversaires.

/* ======================================================================
   Contenu
   ====================================================================== */
const rankOf = c => c.code[0], suitOf = c => c.code[1];
const isFace = c => "JQK".includes(rankOf(c));
const ROMAN = ["", "I", "II", "III", "IV", "V"];
// val : nombre fixe, "wild" (s'adapte au mieux) ou "mirror" (copie la carte d'avant)
const SPECIALS = {
  cameleon:{ico:"🦎", name:"Le Caméléon", val:"wild", desc:"Vaut ce qui t'arrange, de 1 à 11."},
  fantome: {ico:"👻", name:"Le Fantôme", val:0, desc:"Vaut 0. +30 jetons dans une main gagnante.", score:{chips:30}},
  miroir:  {ico:"🪞", name:"Le Miroir", val:"mirror", desc:"Copie la valeur de la carte juste avant lui."},
  petard:  {ico:"🧨", name:"Le Pétard", val:5, desc:"Vaut 5. ×2 mult dans une main gagnante, mais te coûte 3 PV quand il sort.", score:{xmult:2}, draw:{hurt:3}},
  pie:     {ico:"🐦", name:"La Pie", val:4, desc:"Vaut 4. +2 or quand elle sort pour toi.", draw:{gold:2}},
  sangsue: {ico:"🩸", name:"La Sangsue", val:3, desc:"Vaut 3. Soigne 6 PV si elle est dans une main gagnante.", score:{heal:6}},
};
for(let n = 1; n <= 5; n++) SPECIALS["clou" + n] = {ico:"⚰️", nail:n, name:`Clou du cercueil ${ROMAN[n]}`, val:2,
  desc:"Vaut 2. Plante les cinq clous différents à une même table : le cercueil se referme sur ton adversaire."};
const isSp = c => !!(c && c.sp && SPECIALS[c.sp]);
const pts = c => {
  if(isSp(c)){ const v = SPECIALS[c.sp].val; return typeof v === "number" ? v : 0; }
  const r = rankOf(c);
  // Carte négative : retire sa valeur au total (un As négatif vaut −1).
  if(c.neg) return -(r === "A" ? 1 : "0JQK".includes(r) ? 10 : +r);
  return r === "A" ? 11 : "0JQK".includes(r) ? 10 : +r;
};
const rankLabel = r => ({"0":"10", J:"V", Q:"D", K:"R"})[r] || r;
const cardName = c => isSp(c) ? SPECIALS[c.sp].name
  : `${c.neg ? "−" : ""}${rankLabel(rankOf(c))}${suitOf(c) === NOTHING ? " Nothing" : GLYPH[suitOf(c)]}`;

const ENH = {
  grave:{name:"Gravée", desc:"+15 jetons"},
  rouge:{name:"Rubis", desc:"+4 mult"},
  or:   {name:"Dorée", desc:"+2 or si elle est dans une main gagnante"},
  verre:{name:"Verre", desc:"×1,5 mult, 1 chance sur 4 de se briser"},
};
const EDS = {
  foil:{name:"Foil", desc:"+25 jetons"},
  holo:{name:"Holographique", short:"Holo", desc:"+6 mult"},
  poly:{name:"Polychrome", short:"Poly", desc:"×1,5 mult"},
};

// trig : moment où le charme se déclenche en dehors du calcul d'une main gagnante.
// score(cards, ctx, st) agit pendant le calcul ; on<Événement>(st, ...) agit au moment de l'action.
const CHARMS = {
  pince:    {ico:"🤏", name:"Petites mains", cost:4, desc:"+25 jetons si tu gagnes avec 2 cartes.", score:c => c.length === 2 ? {chips:25} : null},
  frime:    {ico:"🕶️", name:"Frime", cost:6, desc:"+1 mult par carte dans la main gagnante.", score:c => ({mult:c.length})},
  coeur:    {ico:"❤️", name:"Cœur d'artichaut", cost:5, desc:"+2 mult par ♥ dans la main.", score:c => { const n = c.filter(k => suitOf(k) === "H").length; return n ? {mult:2*n} : null; }},
  pique:    {ico:"🗡️", name:"Pique-assiette", cost:5, desc:"+15 jetons par ♠ dans la main.", score:c => { const n = c.filter(k => suitOf(k) === "S").length; return n ? {chips:15*n} : null; }},
  trefle:   {ico:"🍀", name:"Trèfle à quatre", cost:5, desc:"+8 jetons et +1 mult par ♣.", score:c => { const n = c.filter(k => suitOf(k) === "C").length; return n ? {chips:8*n, mult:n} : null; }},
  gueules:  {ico:"👑", name:"Gueules", cost:5, desc:"+12 jetons par figure (V, D, R).", score:c => { const n = c.filter(isFace).length; return n ? {chips:12*n} : null; }},
  as:       {ico:"🂡", name:"As dans la manche", cost:7, desc:"×2 mult si la main contient un As.", score:c => c.some(k => rankOf(k) === "A") ? {xmult:2} : null},
  pile:     {ico:"🎯", name:"Pile poil", cost:8, desc:"×3 mult si tu gagnes avec exactement 21.", score:(c,x) => x.total === 21 ? {xmult:3} : null},
  petit:    {ico:"🐭", name:"Petit joueur", cost:6, desc:"×2 mult si tu gagnes avec 17 ou moins.", score:(c,x) => x.total <= 17 ? {xmult:2} : null},
  rapace:   {ico:"🦅", name:"Rapace", cost:6, desc:"×2 mult quand ton adversaire saute.", score:(c,x) => x.foeBust ? {xmult:2} : null},
  pyramide: {ico:"🔺", name:"Pyramide", cost:7, desc:"+1 mult par main déjà gagnée à cette table.", score:() => T.wins ? {mult:T.wins} : null},
  editeur:  {ico:"✨", name:"Collectionneur", cost:7, desc:"+3 mult par carte foil, holo ou poly dans la main.", score:c => { const n = c.filter(k => k.ed).length; return n ? {mult:3*n} : null; }},
  // sauts
  kamikaze: {ico:"💥", name:"Kamikaze", cost:6, trig:"Saut", desc:"Quand tu sautes, inflige quand même (total − 21) × 8 dégâts.", onBust:(st,h,t) => ({dmg:(t - 21) * 8})},
  cassecou: {ico:"🤕", name:"Casse-cou", cost:6, trig:"Saut", desc:"+1 mult permanent à chaque saut. Actuellement +{n}.", onBust:st => { st.n++; return {note:"+1 mult"}; }, score:(c,x,st) => st.n ? {mult:st.n} : null},
  parachute:{ico:"🪂", name:"Parachute doré", cost:4, trig:"Saut", desc:"+3 or quand tu sautes.", onBust:() => ({gold:3})},
  // doubles
  culot:    {ico:"😤", name:"Culot", cost:5, trig:"Double", desc:"+40 jetons sur une main doublée gagnante.", score:(c,x) => x.doubled ? {chips:40} : null},
  fanfaron: {ico:"🎺", name:"Fanfaron", cost:5, trig:"Double", desc:"+2 or chaque fois que tu doubles.", onDouble:() => ({gold:2})},
  adrenaline:{ico:"💉", name:"Adrénaline", cost:5, trig:"Double", desc:"+5 PV chaque fois que tu doubles.", onDouble:() => ({heal:5})},
  doubleur: {ico:"🎲", name:"Quitte ou double", cost:6, trig:"Double", desc:"Doubler donne ×3 mult au lieu de ×2."},
  // splits
  jumeaux:  {ico:"👯", name:"Jumeaux", cost:7, trig:"Split", desc:"×2 mult sur les mains issues d'un split.", score:(c,x) => x.split ? {xmult:2} : null},
  siamois:  {ico:"🪢", name:"Siamois", cost:5, trig:"Split", desc:"+20 jetons et +2 mult sur les mains issues d'un split.", score:(c,x) => x.split ? {chips:20, mult:2} : null},
  ricochet: {ico:"🪃", name:"Ricochet", cost:4, trig:"Split", desc:"+1 brûlage chaque fois que tu sépares.", onSplit:() => ({burn:1})},
  scission: {ico:"✂️", name:"Scission", cost:6, trig:"Split", desc:"Tu peux séparer n'importe quelles deux cartes."},
  // défaites et égalités
  rancune:  {ico:"😠", name:"Rancune", cost:5, trig:"Défaite", desc:"+2 mult par main perdue, remis à zéro quand tu gagnes. Actuellement +{n}.",
             onLose:st => { st.n += 2; }, score:(c,x,st) => st.n ? {mult:st.n} : null, afterWin:st => { st.n = 0; }},
  diplomate:{ico:"🤝", name:"Diplomate", cost:4, trig:"Égalité", desc:"+2 or à chaque égalité.", onPush:() => ({gold:2})},
  // règles et survie
  filet:    {ico:"🥅", name:"Filet de sécurité", cost:6, desc:"Ton premier saut à chaque table devient une égalité."},
  voyeur:   {ico:"👁️", name:"Voyeur", cost:5, desc:"Tu vois les cartes cachées d'en face."},
  devin:    {ico:"🔮", name:"Devin", cost:7, desc:"Tu vois la prochaine carte du sabot."},
  elastique:{ico:"🪀", name:"Élastique", cost:12, desc:"Tu ne sautes qu'au-delà de 22."},
  contrepoids:{ico:"⚖️", name:"Contrepoids", cost:8, trig:"Saut", desc:"Une fois par table, quand tu sautes, crée la carte négative qui te ramène pile à 21 et la joue aussitôt. Elle rejoint ton deck."},
  ouroboros:{ico:"🐍", name:"Ouroboros", cost:12, desc:"×1 mult, et +0,25 à chaque main gagnée, pour toute la partie. Actuellement ×{x}.",
             score:(c,x,st) => st.n ? {xmult: 1 + st.n / 4} : null, afterWin:st => { st.n++; }},
  vampire:  {ico:"🦇", name:"Vampire", cost:5, desc:"+4 PV à chaque main gagnée."},
  carapace: {ico:"🐢", name:"Carapace", cost:5, desc:"−3 dégâts subis (minimum 1)."},
  banquier: {ico:"💰", name:"Banquier", cost:5, desc:"+1 or par main gagnée."},
  allumette:{ico:"🔥", name:"Allumettes", cost:4, desc:"+1 brûlage par table."},
  // manche et cartes spéciales
  manchelarge:{ico:"🧥", name:"Manche large", cost:5, trig:"Manche", desc:"+1 place dans ta manche."},
  passepasse:{ico:"🎩", name:"Passe-passe", cost:6, trig:"Manche", desc:"×2 mult si la main gagnante contient une carte ressortie de ta manche.", score:c => c.some(k => k.fromSleeve) ? {xmult:2} : null},
  pickpocket:{ico:"🧤", name:"Pickpocket", cost:4, trig:"Manche", desc:"+1 or chaque fois que tu caches une carte.", onHide:() => ({gold:1})},
  fossoyeur:{ico:"🪦", name:"Fossoyeur", cost:5, desc:"+12 jetons par clou déjà planté à cette table.", score:() => T.nails && T.nails.size ? {chips:12 * T.nails.size} : null},
  zen:      {ico:"🧘", name:"Zen", cost:6, desc:"×1,5 mult par carte Nothing dans la main gagnante.", score:c => { const n = c.filter(k => !isSp(k) && suitOf(k) === NOTHING).length; return n ? {xmult: Math.round(1.5 ** n * 100) / 100} : null; }},
  antimatiere:{ico:"🌀", name:"Antimatière", cost:5, desc:"+20 jetons et +2 mult par carte négative dans la main gagnante.", score:c => { const n = c.filter(k => k.neg).length; return n ? {chips:20*n, mult:2*n} : null; }},
  bouffon:  {ico:"🃏", name:"Bouffon", cost:6, desc:"+3 mult par carte spéciale dans la main gagnante.", score:c => { const n = c.filter(isSp).length; return n ? {mult:3*n} : null; }},
};
// Rareté : poids d'apparition en boutique et couleur (bleu, vert, rouge, violet, comme les classiques du genre).
const RARITY = {
  commun:     {name:"Commun",     color:"#5ea4dc", weight:60},
  peucommun:  {name:"Peu commun", color:"#5fbf7a", weight:28},
  rare:       {name:"Rare",       color:"#e25b4a", weight:10},
  legendaire: {name:"Légendaire", color:"#b58cff", weight:2},
};
const RARITY_OF = {
  commun: ["pince","coeur","pique","trefle","gueules","parachute","fanfaron","adrenaline","ricochet","diplomate","vampire","carapace","banquier","allumette","pickpocket","manchelarge"],
  peucommun: ["frime","petit","rapace","pyramide","culot","siamois","cassecou","rancune","filet","voyeur","fossoyeur","bouffon","antimatiere","kamikaze","scission","editeur"],
  rare: ["as","pile","jumeaux","doubleur","devin","passepasse","zen","contrepoids"],
  legendaire: ["elastique","ouroboros"],
};
for(const [r, ids] of Object.entries(RARITY_OF)) for(const id of ids) CHARMS[id].rarity = r;
for(const id of Object.keys(CHARMS)) CHARMS[id].rarity ||= "commun";
const STARTERS = ["pince","gueules","vampire","allumette","pique","carapace","parachute","fanfaron","pickpocket","manchelarge"];

const FOES = ["Lulu la Pince","Le Comptable","Madame Zéro","Gégé les Dés","Tonton Flambeur","La Mouette","Nono Cinq-Doigts","Le Notaire","Tata Jetons","Bébert"];
const BOSSES = [
  {name:"Le Baron", mod:"fer", text:"Main de fer : le croupier tire jusqu'à 18."},
  {name:"La Veuve", mod:"gorge", text:"Coupe-gorge : les dégâts que tu subis sont doublés."},
  {name:"Monsieur Brume", mod:"brume", text:"Brouillard : ta première carte reste face cachée."},
  {name:"L'Archiduc", mod:"bavure", text:"Sans bavure : impossible de brûler ou de séparer."},
  {name:"Le Cardinal", mod:"suit", suit:"H", text:"Cœurs désactivés : tes ♥ comptent dans le total mais ne rapportent rien."},
  {name:"Le Joaillier", mod:"suit", suit:"D", text:"Carreaux désactivés : tes ♦ comptent dans le total mais ne rapportent rien."},
  {name:"Le Corbeau", mod:"suit", suit:"S", text:"Piques désactivés : tes ♠ comptent dans le total mais ne rapportent rien."},
  {name:"Le Jardinier", mod:"suit", suit:"C", text:"Trèfles désactivés : tes ♣ comptent dans le total mais ne rapportent rien."},
  {name:"La Fouineuse", mod:"fouille", text:"Fouille au corps : impossible de cacher ou de ressortir une carte de ta manche."},
];
const TABLE_HP = [45, 70, 110], ANTE_X = [1, 2, 3.6];
const TABLE_NAME = ["Petite table", "Grande table", "Table du patron"], TABLE_GOLD = [3, 4, 6];
const DUEL_HP = 100, SET_ROUNDS = 3;

// Decks : chacun a son dos de carte et, sauf le classique, un bonus pour toute la partie.
const DECKS = {
  classique:{name:"Deck classique", desc:"Aucun bonus : le blackjack pur, comme au casino."},
  rouge:    {name:"Deck rouge", desc:"+1 brûlage à chaque table.", burns:1},
  or:       {name:"Deck d'or", desc:"+10 or au départ, et +2 or à chaque table gagnée.", gold:10, tableGold:2},
  azur:     {name:"Deck azur", desc:"+10 jetons sur chaque main gagnée.", chips:10},
  braise:   {name:"Deck braise", desc:"+2 mult sur chaque main gagnée, mais 10 PV de moins.", mult:2, hp:-10},
  emeraude: {name:"Deck émeraude", desc:"+1 place dans ta manche, et renouveler le rayon coûte 1 or de moins.", sleeve:1, reroll:-1},
  neant:    {name:"Deck du néant", desc:"Les 13 Nothing rejoignent ton deck, et tu commences avec le charme Zen.", nothings:true, charm:"zen"},
  abysse:   {name:"Deck abyssal", desc:"+1 emplacement de charme, mais pas de charme de départ.", slots:1, noStarter:true},
  prisme:   {name:"Deck prisme", desc:"8 cartes au hasard commencent foil, holo ou poly.", editions:8},
};
// Éditions de charme : leur bonus s'ajoute au moment où le charme passe, qu'il se déclenche ou non.
// « Négatif » ne rapporte rien au calcul mais n'occupe pas d'emplacement.
const CHARM_EDS = {
  foil:{name:"Foil", desc:"+25 jetons", cost:2, chance:.06},
  holo:{name:"Holo", desc:"+6 mult", cost:3, chance:.05},
  poly:{name:"Poly", desc:"×1,5 mult", cost:5, chance:.03},
  neg: {name:"Négatif", desc:"+1 emplacement de charme", cost:5, chance:.03},
};
const charmPrice = (id, ed) => CHARMS[id].cost + (ed ? CHARM_EDS[ed].cost : 0);
// Fonds des tables de patron : un décor par règle (voir styles.css, body[data-theme])
const BOSS_THEME = b => b.mod === "suit" ? "suit-" + b.suit : b.mod;
