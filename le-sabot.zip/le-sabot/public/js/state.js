"use strict";
// État de la partie et règles de calcul des mains.

/* ======================================================================
   État
   ====================================================================== */
let MODE = "solo";        // "solo" | "duel"
let S, T, H, busy = false;
let O = null;             // adversaires en JcJ : {id: {name, hp, maxHp, charms, live, out, place}}
let uidSeq = 0;
const inst = (code, enh = null, ed = null, sp = null, neg = false) => ({uid: ++uidSeq, code, enh, ed, sp, neg});
const spInst = (sp, ed = null) => inst("X1", null, ed, sp);
// Réglages mémorisés dans le navigateur : deck choisi, contraste élevé, animations réduites
const SETTINGS = (() => {
  let s = {};
  try{ s = JSON.parse(localStorage.getItem("sabot:settings") || "{}"); }catch(e){}
  return {deck: DECKS[s.deck] ? s.deck : "classique", highContrast: !!s.highContrast, calm: !!s.calm};
})();
function saveSettings(){ try{ localStorage.setItem("sabot:settings", JSON.stringify(SETTINGS)); }catch(e){} }
const deckDef = () => DECKS[(S && S.deckId) || SETTINGS.deck] || DECKS.classique;

function newRun(){
  S = {hp:50, maxHp:50, gold:4, ante:1, table:0, deck: FULL.map(c => inst(c)), charms:[], usedFoes:[], sleeve:[], deckId: SETTINGS.deck};
  if(MODE === "duel"){ S.hp = S.maxHp = DUEL_HP; }
  const d = deckDef();
  if(d.hp){ S.maxHp += d.hp; S.hp = S.maxHp; }
  if(d.gold) S.gold += d.gold;
  if(d.nothings) S.deck.push(...NOTHINGS.map(c => inst(c)));
  if(d.charm) S.charms.push({id: d.charm, n:0, ed:null});
  if(d.editions) for(const c of shuffled(S.deck).slice(0, d.editions)) c.ed = pickOne(["foil", "foil", "holo", "holo", "poly"]);
}
// Emplacements de charme : 5, +1 pour le deck abyssal. Un charme négatif n'en occupe aucun.
const charmSlots = () => 5 + (deckDef().slots || 0);
const slotsUsed = () => S.charms.filter(c => c.ed !== "neg").length;
const has = id => S.charms.some(c => c.id === id);
const limit = () => has("elastique") ? 22 : 21;
function handTotal(cards, lim){
  let t = 0, a = 0, wild = 0;
  cards.forEach((c, i) => {
    let src = c;
    if(isSp(c) && SPECIALS[c.sp].val === "mirror"){ src = cards[i - 1]; if(!src) return; }
    if(isSp(src) && SPECIALS[src.sp].val === "wild"){ wild++; return; }
    if(isSp(src) && SPECIALS[src.sp].val === "mirror") return;
    t += pts(src); if(!isSp(src) && !src.neg && rankOf(src) === "A") a++;
  });
  while(t > lim && a){ t -= 10; a--; }
  for(let k = 0; k < wild; k++) t += Math.max(1, Math.min(11, lim - t - (wild - k - 1)));
  return t;
}
function cardValues(cards, lim){
  const vals = cards.map(() => 0), aces = [], wilds = [];
  let t = 0;
  cards.forEach((c, i) => {
    let src = c;
    if(isSp(c) && SPECIALS[c.sp].val === "mirror"){ src = cards[i - 1]; if(!src) return; }
    if(isSp(src) && SPECIALS[src.sp].val === "wild"){ wilds.push(i); return; }
    if(isSp(src) && SPECIALS[src.sp].val === "mirror") return;
    vals[i] = pts(src); t += vals[i];
    if(!isSp(src) && !src.neg && rankOf(src) === "A") aces.push(i);
  });
  for(const i of aces){ if(t <= lim) break; vals[i] -= 10; t -= 10; }
  wilds.forEach((i, k) => { const v = Math.max(1, Math.min(11, lim - t - (wilds.length - k - 1))); vals[i] = v; t += v; });
  return vals;
}
const newHand = (cards = [], fromSplit = false) => ({cards, fromSplit, doubled:false, burned:0, tricked:false, state:"play", result:null, kami:0});
const sleeveCap = () => 1 + (has("manchelarge") ? 1 : 0) + (deckDef().sleeve || 0);
const sleeveLocked = () => MODE === "solo" && T.foe && T.foe.mod === "fouille";
const hTotal = h => handTotal(h.cards, limit());
const isNatural = h => H.hands.length === 1 && !h.fromSplit && !h.burned && !h.tricked && h.cards.length === 2 && handTotal(h.cards, 21) === 21;
const dTotal = () => handTotal(H.d, 21);
const dNatural = () => H.d.length === 2 && dTotal() === 21;
const cur = () => H.hands[H.cur];
// Carte désactivée par le patron : elle compte dans le total, mais ne rapporte ni jetons,
// ni amélioration, ni édition, et les charmes l'ignorent. Les cartes spéciales et les Nothing
// n'ont pas de couleur : elles ne sont jamais désactivées.
const disabled = c => MODE === "solo" && !!T && !!T.foe && T.foe.mod === "suit" && !isSp(c) && suitOf(c) === T.foe.suit;
const pub = c => ({code:c.code, enh:c.enh || null, ed:c.ed || null, sp:c.sp || null, neg:!!c.neg});
