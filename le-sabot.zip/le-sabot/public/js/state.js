"use strict";
// État de la partie et règles de calcul des mains.

/* ======================================================================
   État
   ====================================================================== */
let MODE = "solo";        // "solo" | "duel"
let S, T, H, busy = false;
let O = null;             // adversaires en JcJ : {id: {name, hp, maxHp, charms, live, out, place}}
let uidSeq = 0;
const inst = (code, enh = null, ed = null, sp = null, neg = false, num = false) => ({uid: ++uidSeq, code, enh, ed, sp, neg, num});
const spInst = (sp, ed = null) => inst("X1", null, ed, sp);
// Réglages mémorisés dans le navigateur : deck choisi, contraste élevé, animations réduites
const SETTINGS = (() => {
  let s = {};
  try{ s = JSON.parse(localStorage.getItem("sabot:settings") || "{}"); }catch(e){}
  return {deck: DECKS[s.deck] ? s.deck : "classique", highContrast: !!s.highContrast, calm: !!s.calm, volume: typeof s.volume === "number" ? s.volume : .6};
})();
function saveSettings(){ try{ localStorage.setItem("sabot:settings", JSON.stringify(SETTINGS)); }catch(e){} }
const deckDef = () => DECKS[(S && S.deckId) || SETTINGS.deck] || DECKS.classique;

function newRun(deckId = SETTINGS.deck){
  S = {hp:50, maxHp:50, gold:4, ante:1, table:0, deck: FULL.map(c => inst(c)), charms:[], usedFoes:[], sleeve:[], deckId, tickets:[], dmgTotal:0, tablesWon:0};
  if(MODE === "duel"){ S.hp = S.maxHp = DUEL_HP; }
  const d = deckDef();
  if(d.hp){ S.maxHp += d.hp; S.hp = S.maxHp; }
  if(d.gold) S.gold += d.gold;
  if(d.nothings) S.deck.push(...NOTHINGS.map(c => inst(c)));
  if(d.charm) S.charms.push({id: d.charm, n:0, ed:null});
  if(d.editions) for(const c of shuffled(S.deck).slice(0, d.editions)) c.ed = pickOne(["foil", "foil", "holo", "holo", "poly"]);
  // Enseignes de valeur : à la place des As à 10 classiques, ou en plus d'eux
  const numCards = () => SUITS.flatMap(s => NUM_RANKS.map(r => inst(r + s, null, null, null, false, true)));
  if(d.numDeck === "replace") S.deck = [...S.deck.filter(c => "JQK".includes(rankOf(c))), ...numCards()];
  if(d.numDeck === "add") S.deck.push(...numCards());
  if(d.glass) for(const c of shuffled(S.deck.filter(c => !c.enh)).slice(0, d.glass)) c.enh = "verre";
  if(d.negLow) for(const c of S.deck) if("2345".includes(rankOf(c)) && !c.num) c.neg = true;
  if(d.specials){
    for(const id of shuffled(Object.keys(SPECIALS).filter(k => !SPECIALS[k].nail)).slice(0, d.specials)) S.deck.push(spInst(id));
    S.deck.push(spInst("clou" + (1 + rnd(5))));
  }
}
// Emplacements de charme : 5, +1 pour le deck abyssal. Un charme négatif n'en occupe aucun.
const charmSlots = () => 5 + (deckDef().slots || 0) + (has("mecene") ? 1 : 0);
const slotsUsed = () => S.charms.filter(c => c.ed !== "neg").length;
const has = id => S.charms.some(c => c.id === id);
// Limite de saut : 22 avec Élastique, une de moins à la table de La Faucheuse
const limit = () => (has("elastique") ? 22 : 21) - (MODE === "solo" && T && T.foe && T.foe.mod === "faucheuse" ? 1 : 0);
function handTotal(cards, lim){
  let t = 0, a = 0, wild = 0;
  cards.forEach((c, i) => {
    let src = c;
    if(isSp(c) && SPECIALS[c.sp].val === "mirror"){ src = cards[i - 1]; if(!src) return; }
    if(isSp(src) && SPECIALS[src.sp].val === "wild"){ wild++; return; }
    if(isSp(src) && SPECIALS[src.sp].val === "mirror") return;
    t += pts(src); if(!isSp(src) && !src.neg && rankOf(src) === "A") a++;
  });
  while(t > lim && a){ t -= 10; a--; }
  for(let k = 0; k < wild; k++) t += Math.max(1, Math.min(11, lim - t - (wild - k - 1)));
  return t;
}
function cardValues(cards, lim){
  const vals = cards.map(() => 0), aces = [], wilds = [];
  let t = 0;
  cards.forEach((c, i) => {
    let src = c;
    if(isSp(c) && SPECIALS[c.sp].val === "mirror"){ src = cards[i - 1]; if(!src) return; }
    if(isSp(src) && SPECIALS[src.sp].val === "wild"){ wilds.push(i); return; }
    if(isSp(src) && SPECIALS[src.sp].val === "mirror") return;
    vals[i] = pts(src); t += vals[i];
    if(!isSp(src) && !src.neg && rankOf(src) === "A") aces.push(i);
  });
  for(const i of aces){ if(t <= lim) break; vals[i] -= 10; t -= 10; }
  wilds.forEach((i, k) => { const v = Math.max(1, Math.min(11, lim - t - (wilds.length - k - 1))); vals[i] = v; t += v; });
  return vals;
}
const newHand = (cards = [], fromSplit = false) => ({cards, fromSplit, doubled:false, burned:0, tricked:false, state:"play", result:null, kami:0});
const sleeveCap = () => 1 + (has("manchelarge") ? 1 : 0) + (deckDef().sleeve || 0);
const sleeveLocked = () => MODE === "solo" && T.foe && T.foe.mod === "fouille";
const hTotal = h => handTotal(h.cards, limit());
const isNatural = h => H.hands.length === 1 && !h.fromSplit && !h.burned && !h.tricked && h.cards.length === 2 && handTotal(h.cards, 21) === 21;
const dTotal = () => handTotal(H.d, 21);
const dNatural = () => H.d.length === 2 && dTotal() === 21;
const cur = () => H.hands[H.cur];
// Carte désactivée par le patron : elle compte dans le total, mais ne rapporte ni jetons,
// ni amélioration, ni édition, et les charmes l'ignorent. Les cartes spéciales et les Nothing
// n'ont pas de couleur : elles ne sont jamais désactivées.
// D'autres patrons désactivent les figures, les cartes impaires, ou tout ce qui sort du jeu classique.
function disabled(c){
  if(MODE !== "solo" || !T || !T.foe) return false;
  const m = T.foe.mod, r = isSp(c) ? null : rankOf(c);
  if(m === "suit") return !isSp(c) && suitOf(c) === T.foe.suit;
  if(m === "figures") return !!r && "JQK".includes(r);
  if(m === "impairs") return !!r && "A3579".includes(r);
  if(m === "exorcisme") return isSp(c) || suitOf(c) === NOTHING || !!c.neg || !!c.num;
  return false;
}
// Le Mime fait taire ton premier charme
const charmMuted = i => i === 0 && MODE === "solo" && !!T && !!T.foe && T.foe.mod === "mime";
const pub = c => ({code:c.code, enh:c.enh || null, ed:c.ed || null, sp:c.sp || null, neg:!!c.neg, num:!!c.num});
